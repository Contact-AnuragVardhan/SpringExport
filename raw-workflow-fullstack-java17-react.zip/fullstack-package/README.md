# Raw Workflow Engine Full Stack

- `backend/`: Maven Spring Boot application, Java 17, SQL Server scripts under `dbscripts/`
- `frontend/`: React + TypeScript + Vite application

Run the backend first on port 8080, then run `npm install && npm run dev` inside `frontend/`.

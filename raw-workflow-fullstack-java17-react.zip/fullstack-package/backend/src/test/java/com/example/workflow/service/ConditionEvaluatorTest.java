package com.example.workflow.service;

import com.example.workflow.util.JsonSupport;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConditionEvaluatorTest {

    private final ConditionEvaluator evaluator =
        new ConditionEvaluator(new JsonSupport(new ObjectMapper()));

    @Test
    void evaluatesCompoundCondition() {
        String condition = """
            {
              "all": [
                {"field": "ytdTotal", "operator": "GT", "value": 300},
                {"field": "politicalPerson", "operator": "EQ", "value": false}
              ]
            }
            """;

        assertTrue(evaluator.evaluate(condition, Map.of(
            "ytdTotal", 350,
            "politicalPerson", false
        )));

        assertFalse(evaluator.evaluate(condition, Map.of(
            "ytdTotal", 250,
            "politicalPerson", false
        )));
    }

    @Test
    void evaluatesInOperator() {
        String condition = """
            {"field": "country", "operator": "IN", "value": ["US", "CA"]}
            """;

        assertTrue(evaluator.evaluate(condition, Map.of("country", "US")));
        assertFalse(evaluator.evaluate(condition, Map.of("country", "GB")));
    }
}

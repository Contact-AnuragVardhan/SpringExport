package com.example.workflow.service;

import com.example.workflow.dto.StartWorkflowRequest;
import com.example.workflow.dto.WorkflowStartedResponse;
import com.example.workflow.enumtype.AuditEventType;
import com.example.workflow.enumtype.StepType;
import com.example.workflow.exception.NotFoundException;
import com.example.workflow.exception.WorkflowValidationException;
import com.example.workflow.model.AuditRecord;
import com.example.workflow.model.WorkflowGraph;
import com.example.workflow.model.WorkflowInstance;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.model.WorkflowToken;
import com.example.workflow.model.WorkflowVersion;
import com.example.workflow.repository.WorkflowAuditRepository;
import com.example.workflow.repository.WorkflowDefinitionRepository;
import com.example.workflow.repository.WorkflowRuntimeRepository;
import com.example.workflow.repository.WorkflowVariableRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service
public class WorkflowRuntimeService {
    private final WorkflowDefinitionRepository definitionRepository;
    private final WorkflowRuntimeRepository runtimeRepository;
    private final WorkflowVariableRepository variableRepository;
    private final WorkflowAuditRepository auditRepository;
    private final WorkflowEngine workflowEngine;

    public WorkflowRuntimeService(
        WorkflowDefinitionRepository definitionRepository,
        WorkflowRuntimeRepository runtimeRepository,
        WorkflowVariableRepository variableRepository,
        WorkflowAuditRepository auditRepository,
        WorkflowEngine workflowEngine
    ) {
        this.definitionRepository = definitionRepository;
        this.runtimeRepository = runtimeRepository;
        this.variableRepository = variableRepository;
        this.auditRepository = auditRepository;
        this.workflowEngine = workflowEngine;
    }

    @Transactional
    public WorkflowStartedResponse start(StartWorkflowRequest request, String startedBy) {
        WorkflowVersion version = definitionRepository.findLatestPublishedByWorkflowKey(request.workflowKey())
            .orElseThrow(() -> new NotFoundException(
                "No published workflow exists for key: " + request.workflowKey()));
        WorkflowGraph graph = definitionRepository.loadGraph(version.id());
        WorkflowStep startStep = graph.steps().stream()
            .filter(step -> step.stepType() == StepType.START)
            .findFirst()
            .orElseThrow(() -> new WorkflowValidationException("Published workflow has no START step"));

        WorkflowInstance instance = runtimeRepository.createInstance(
            version.id(), request.businessType(), request.businessId(), request.requesterUserId(),
            request.requesterEmployeeId(), startedBy);
        variableRepository.upsertAll(instance.id(), request.variables());
        WorkflowToken token = runtimeRepository.createToken(instance.id(), startStep.id(), null, null, null);

        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, null, startStep.id(),
            AuditEventType.INSTANCE_STARTED, null, startedBy, null, null,
            Map.of("workflowKey", request.workflowKey(), "versionNumber", version.versionNumber(),
                "businessType", request.businessType(), "businessId", request.businessId())));
        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, null, startStep.id(),
            AuditEventType.TOKEN_CREATED, null, startedBy, null, null, null));
        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, null, startStep.id(),
            AuditEventType.STEP_ENTERED, null, startedBy, null, null, null));

        workflowEngine.process(token.id());
        return new WorkflowStartedResponse(instance.id());
    }
}

package com.example.workflow.dto;

import com.example.workflow.enumtype.AssignmentType;
import com.example.workflow.enumtype.EndStatus;
import com.example.workflow.enumtype.StepType;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public record StepInput(
    @NotBlank String stepKey,
    @NotBlank String stepName,
    @NotNull StepType stepType,
    @NotNull AssignmentType assignmentType,
    String assignmentGroupId,
    String assignmentUserId,
    Boolean allowRequestInformation,
    String parallelJoinStepKey,
    EndStatus endStatus,
    JsonNode configuration,
    BigDecimal displayX,
    BigDecimal displayY,
    BigDecimal displayWidth,
    BigDecimal displayHeight,
    String laneKey,
    Integer sortOrder
) {}

package com.example.workflow.model;

import java.time.Instant;
import java.util.UUID;

public record WorkflowDefinition(
    UUID id,
    String workflowKey,
    String workflowName,
    String description,
    boolean active,
    String createdBy,
    Instant createdAt,
    String updatedBy,
    Instant updatedAt
) {}

package com.example.workflow.dto;

import java.util.UUID;

public record WorkflowCreatedResponse(UUID workflowDefinitionId, UUID draftVersionId, int draftVersionNumber) {}

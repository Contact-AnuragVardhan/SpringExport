package com.example.workflow.enumtype;

public enum TokenStatus { ACTIVE, WAITING_FOR_TASK, WAITING_AT_JOIN, COMPLETED, CANCELLED, FAILED }

package com.example.workflow.model;

import com.example.workflow.enumtype.TokenStatus;
import java.time.Instant;
import java.util.UUID;

public record WorkflowToken(
    UUID id,
    UUID workflowInstanceId,
    UUID currentStepId,
    TokenStatus status,
    UUID parentTokenId,
    UUID parallelScopeId,
    String branchKey,
    Instant createdAt,
    Instant completedAt
) {}

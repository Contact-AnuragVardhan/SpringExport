package com.example.workflow.service;

import com.example.workflow.exception.WorkflowValidationException;
import com.example.workflow.model.ResolvedAssignment;
import com.example.workflow.model.WorkflowInstance;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.repository.EmployeeHierarchyRepository;
import org.springframework.stereotype.Component;

@Component
public class AssignmentResolver {
    private final EmployeeHierarchyRepository employeeHierarchyRepository;

    public AssignmentResolver(EmployeeHierarchyRepository employeeHierarchyRepository) {
        this.employeeHierarchyRepository = employeeHierarchyRepository;
    }

    public ResolvedAssignment resolve(WorkflowStep step, WorkflowInstance instance) {
        return switch (step.assignmentType()) {
            case REQUESTER -> ResolvedAssignment.user(instance.requesterUserId());
            case REQUESTER_SUPERVISOR -> ResolvedAssignment.user(
                employeeHierarchyRepository.findSupervisorUserId(instance.requesterEmployeeId())
                    .orElseThrow(() -> new WorkflowValidationException(
                        "No active supervisor is configured for employee " + instance.requesterEmployeeId()))
            );
            case GROUP -> ResolvedAssignment.group(step.assignmentGroupId());
            case SPECIFIC_USER -> ResolvedAssignment.user(step.assignmentUserId());
            case NONE -> throw new WorkflowValidationException(
                "Approval step has no assignment: " + step.stepKey());
        };
    }
}

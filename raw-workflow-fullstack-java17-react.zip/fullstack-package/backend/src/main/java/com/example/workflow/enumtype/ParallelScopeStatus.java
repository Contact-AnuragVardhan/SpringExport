package com.example.workflow.enumtype;

public enum ParallelScopeStatus { OPEN, COMPLETED, CANCELLED }

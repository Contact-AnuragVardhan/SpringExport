package com.example.workflow.model;

import com.example.workflow.enumtype.AuditEventType;
import java.util.Map;
import java.util.UUID;

public record AuditRecord(
    UUID workflowInstanceId,
    UUID workflowTokenId,
    UUID workflowTaskId,
    UUID fromStepId,
    UUID toStepId,
    AuditEventType eventType,
    String outcome,
    String performedByUserId,
    String performedForGroupId,
    String comments,
    Map<String, Object> eventData
) {}

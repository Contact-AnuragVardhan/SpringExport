package com.example.workflow.dto;

import java.util.UUID;

public record WorkflowPublishedResponse(
    UUID workflowDefinitionId,
    UUID publishedVersionId,
    int publishedVersionNumber,
    UUID nextDraftVersionId,
    int nextDraftVersionNumber
) {}

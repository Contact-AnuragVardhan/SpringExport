package com.example.workflow.dto;

public record TaskCommentRequest(String comments) {}

package com.example.workflow.controller;

import com.example.workflow.dto.CreateWorkflowRequest;
import com.example.workflow.dto.SaveWorkflowDraftRequest;
import com.example.workflow.dto.ValidationResponse;
import com.example.workflow.dto.WorkflowCreatedResponse;
import com.example.workflow.dto.WorkflowGraphResponse;
import com.example.workflow.dto.WorkflowPublishedResponse;
import com.example.workflow.model.WorkflowVersion;
import com.example.workflow.service.CurrentUserService;
import com.example.workflow.service.WorkflowDefinitionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/workflows")
public class WorkflowDefinitionController {
    private final WorkflowDefinitionService workflowDefinitionService;
    private final CurrentUserService currentUserService;

    public WorkflowDefinitionController(
        WorkflowDefinitionService workflowDefinitionService,
        CurrentUserService currentUserService
    ) {
        this.workflowDefinitionService = workflowDefinitionService;
        this.currentUserService = currentUserService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public WorkflowCreatedResponse create(
        @Valid @RequestBody CreateWorkflowRequest request,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        return workflowDefinitionService.create(request, currentUserService.requireUserId(userHeader));
    }

    @PutMapping("/{workflowDefinitionId}/draft")
    public WorkflowGraphResponse saveDraft(
        @PathVariable UUID workflowDefinitionId,
        @Valid @RequestBody SaveWorkflowDraftRequest request,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        return workflowDefinitionService.saveDraft(
            workflowDefinitionId, request, currentUserService.requireUserId(userHeader));
    }

    @GetMapping("/{workflowDefinitionId}/draft")
    public WorkflowGraphResponse getDraft(@PathVariable UUID workflowDefinitionId) {
        return workflowDefinitionService.getDraft(workflowDefinitionId);
    }

    @PostMapping("/{workflowDefinitionId}/validate")
    public ValidationResponse validate(@PathVariable UUID workflowDefinitionId) {
        return workflowDefinitionService.validateDraft(workflowDefinitionId);
    }

    @PostMapping("/{workflowDefinitionId}/publish")
    public WorkflowPublishedResponse publish(
        @PathVariable UUID workflowDefinitionId,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        return workflowDefinitionService.publish(
            workflowDefinitionId, currentUserService.requireUserId(userHeader));
    }

    @GetMapping("/{workflowDefinitionId}/versions")
    public List<WorkflowVersion> versions(@PathVariable UUID workflowDefinitionId) {
        return workflowDefinitionService.listVersions(workflowDefinitionId);
    }
}

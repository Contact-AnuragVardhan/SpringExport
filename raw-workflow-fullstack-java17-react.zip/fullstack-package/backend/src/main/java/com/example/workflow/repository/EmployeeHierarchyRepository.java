package com.example.workflow.repository;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class EmployeeHierarchyRepository {
    private final NamedParameterJdbcTemplate jdbc;

    public EmployeeHierarchyRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Optional<String> findSupervisorUserId(String employeeId) {
        if (employeeId == null || employeeId.isBlank()) {
            return Optional.empty();
        }
        return jdbc.query("""
            SELECT supervisor_user_id
            FROM workflow.employee_supervisor
            WHERE employee_id = :employeeId AND active = 1
            """, new MapSqlParameterSource("employeeId", employeeId),
            (rs, rowNum) -> rs.getString("supervisor_user_id")).stream().findFirst();
    }
}

package com.example.workflow.model;

import java.util.UUID;

public record WorkflowLane(
    UUID id,
    UUID workflowVersionId,
    String laneKey,
    String laneName,
    int sortOrder
) {}

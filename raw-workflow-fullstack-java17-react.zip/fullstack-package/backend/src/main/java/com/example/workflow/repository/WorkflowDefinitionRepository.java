package com.example.workflow.repository;

import com.example.workflow.enumtype.AssignmentType;
import com.example.workflow.enumtype.EndStatus;
import com.example.workflow.enumtype.StepType;
import com.example.workflow.enumtype.TransitionType;
import com.example.workflow.enumtype.WorkflowVersionStatus;
import com.example.workflow.model.WorkflowDefinition;
import com.example.workflow.model.WorkflowGraph;
import com.example.workflow.model.WorkflowLane;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.model.WorkflowTransition;
import com.example.workflow.model.WorkflowVersion;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class WorkflowDefinitionRepository {
    private final NamedParameterJdbcTemplate jdbc;

    public WorkflowDefinitionRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public WorkflowDefinition createDefinition(
        String workflowKey,
        String workflowName,
        String description,
        String userId
    ) {
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO workflow.workflow_definition
            (
                workflow_definition_id, workflow_key, workflow_name, description,
                active, created_by, created_at, updated_by, updated_at
            )
            VALUES
            (
                :id, :workflowKey, :workflowName, :description,
                1, :userId, SYSUTCDATETIME(), :userId, SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("id", id)
            .addValue("workflowKey", workflowKey)
            .addValue("workflowName", workflowName)
            .addValue("description", description)
            .addValue("userId", userId));
        return findDefinitionById(id).orElseThrow();
    }

    public void updateDefinitionMetadata(UUID definitionId, String workflowName, String description, String userId) {
        jdbc.update("""
            UPDATE workflow.workflow_definition
            SET workflow_name = :workflowName,
                description = :description,
                updated_by = :userId,
                updated_at = SYSUTCDATETIME()
            WHERE workflow_definition_id = :definitionId
            """, new MapSqlParameterSource()
            .addValue("definitionId", definitionId)
            .addValue("workflowName", workflowName)
            .addValue("description", description)
            .addValue("userId", userId));
    }

    public Optional<WorkflowDefinition> findDefinitionById(UUID id) {
        return first(jdbc.query("""
            SELECT workflow_definition_id, workflow_key, workflow_name, description, active,
                   created_by, created_at, updated_by, updated_at
            FROM workflow.workflow_definition
            WHERE workflow_definition_id = :id
            """, new MapSqlParameterSource("id", id), definitionRowMapper()));
    }

    public Optional<WorkflowDefinition> findDefinitionByKey(String workflowKey) {
        return first(jdbc.query("""
            SELECT workflow_definition_id, workflow_key, workflow_name, description, active,
                   created_by, created_at, updated_by, updated_at
            FROM workflow.workflow_definition
            WHERE workflow_key = :workflowKey
            """, new MapSqlParameterSource("workflowKey", workflowKey), definitionRowMapper()));
    }

    public WorkflowVersion createVersion(
        UUID definitionId,
        int versionNumber,
        WorkflowVersionStatus status,
        String layoutJson,
        String userId
    ) {
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO workflow.workflow_version
            (
                workflow_version_id, workflow_definition_id, version_number,
                version_status, layout_json, created_by, created_at
            )
            VALUES
            (
                :id, :definitionId, :versionNumber,
                :status, :layoutJson, :userId, SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("id", id)
            .addValue("definitionId", definitionId)
            .addValue("versionNumber", versionNumber)
            .addValue("status", status.name())
            .addValue("layoutJson", layoutJson)
            .addValue("userId", userId));
        return findVersionById(id).orElseThrow();
    }

    public void updateDraftLayout(UUID versionId, String layoutJson) {
        jdbc.update("""
            UPDATE workflow.workflow_version
            SET layout_json = :layoutJson
            WHERE workflow_version_id = :versionId
              AND version_status = 'DRAFT'
            """, new MapSqlParameterSource()
            .addValue("versionId", versionId)
            .addValue("layoutJson", layoutJson));
    }

    public Optional<WorkflowVersion> findVersionById(UUID id) {
        return first(jdbc.query("""
            SELECT workflow_version_id, workflow_definition_id, version_number, version_status,
                   layout_json, created_by, created_at, published_by, published_at
            FROM workflow.workflow_version
            WHERE workflow_version_id = :id
            """, new MapSqlParameterSource("id", id), versionRowMapper()));
    }

    public Optional<WorkflowVersion> findDraftForUpdate(UUID definitionId) {
        return first(jdbc.query("""
            SELECT workflow_version_id, workflow_definition_id, version_number, version_status,
                   layout_json, created_by, created_at, published_by, published_at
            FROM workflow.workflow_version WITH (UPDLOCK, HOLDLOCK)
            WHERE workflow_definition_id = :definitionId
              AND version_status = 'DRAFT'
            """, new MapSqlParameterSource("definitionId", definitionId), versionRowMapper()));
    }

    public Optional<WorkflowVersion> findDraft(UUID definitionId) {
        return first(jdbc.query("""
            SELECT workflow_version_id, workflow_definition_id, version_number, version_status,
                   layout_json, created_by, created_at, published_by, published_at
            FROM workflow.workflow_version
            WHERE workflow_definition_id = :definitionId
              AND version_status = 'DRAFT'
            """, new MapSqlParameterSource("definitionId", definitionId), versionRowMapper()));
    }

    public Optional<WorkflowVersion> findLatestPublishedByWorkflowKey(String workflowKey) {
        return first(jdbc.query("""
            SELECT TOP (1)
                   V.workflow_version_id, V.workflow_definition_id, V.version_number, V.version_status,
                   V.layout_json, V.created_by, V.created_at, V.published_by, V.published_at
            FROM workflow.workflow_version V
            INNER JOIN workflow.workflow_definition D
                ON D.workflow_definition_id = V.workflow_definition_id
            WHERE D.workflow_key = :workflowKey
              AND D.active = 1
              AND V.version_status = 'PUBLISHED'
            ORDER BY V.version_number DESC
            """, new MapSqlParameterSource("workflowKey", workflowKey), versionRowMapper()));
    }

    public List<WorkflowVersion> listVersions(UUID definitionId) {
        return jdbc.query("""
            SELECT workflow_version_id, workflow_definition_id, version_number, version_status,
                   layout_json, created_by, created_at, published_by, published_at
            FROM workflow.workflow_version
            WHERE workflow_definition_id = :definitionId
            ORDER BY version_number DESC
            """, new MapSqlParameterSource("definitionId", definitionId), versionRowMapper());
    }

    public void markPublished(UUID versionId, String userId) {
        int updated = jdbc.update("""
            UPDATE workflow.workflow_version
            SET version_status = 'PUBLISHED',
                published_by = :userId,
                published_at = SYSUTCDATETIME()
            WHERE workflow_version_id = :versionId
              AND version_status = 'DRAFT'
            """, new MapSqlParameterSource()
            .addValue("versionId", versionId)
            .addValue("userId", userId));
        if (updated != 1) {
            throw new IllegalStateException("Draft workflow version could not be published");
        }
    }

    public void replaceGraph(WorkflowGraph graph) {
        UUID versionId = graph.version().id();
        jdbc.update("DELETE FROM workflow.workflow_transition WHERE workflow_version_id = :versionId",
            new MapSqlParameterSource("versionId", versionId));
        jdbc.update("DELETE FROM workflow.workflow_step WHERE workflow_version_id = :versionId",
            new MapSqlParameterSource("versionId", versionId));
        jdbc.update("DELETE FROM workflow.workflow_lane WHERE workflow_version_id = :versionId",
            new MapSqlParameterSource("versionId", versionId));
        insertGraph(graph);
    }

    public void insertGraph(WorkflowGraph graph) {
        if (!graph.lanes().isEmpty()) {
            SqlParameterSource[] laneParams = graph.lanes().stream().map(lane -> new MapSqlParameterSource()
                .addValue("id", lane.id())
                .addValue("versionId", lane.workflowVersionId())
                .addValue("laneKey", lane.laneKey())
                .addValue("laneName", lane.laneName())
                .addValue("sortOrder", lane.sortOrder())).toArray(SqlParameterSource[]::new);
            jdbc.batchUpdate("""
                INSERT INTO workflow.workflow_lane
                (workflow_lane_id, workflow_version_id, lane_key, lane_name, sort_order)
                VALUES (:id, :versionId, :laneKey, :laneName, :sortOrder)
                """, laneParams);
        }

        SqlParameterSource[] stepParams = graph.steps().stream().map(step -> new MapSqlParameterSource()
            .addValue("id", step.id())
            .addValue("versionId", step.workflowVersionId())
            .addValue("stepKey", step.stepKey())
            .addValue("stepName", step.stepName())
            .addValue("stepType", step.stepType().name())
            .addValue("assignmentType", step.assignmentType().name())
            .addValue("assignmentGroupId", step.assignmentGroupId())
            .addValue("assignmentUserId", step.assignmentUserId())
            .addValue("allowRequestInformation", step.allowRequestInformation())
            .addValue("parallelJoinStepKey", step.parallelJoinStepKey())
            .addValue("endStatus", step.endStatus() == null ? null : step.endStatus().name())
            .addValue("configurationJson", step.configurationJson())
            .addValue("displayX", step.displayX())
            .addValue("displayY", step.displayY())
            .addValue("displayWidth", step.displayWidth())
            .addValue("displayHeight", step.displayHeight())
            .addValue("laneKey", step.laneKey())
            .addValue("sortOrder", step.sortOrder())).toArray(SqlParameterSource[]::new);
        jdbc.batchUpdate("""
            INSERT INTO workflow.workflow_step
            (
                workflow_step_id, workflow_version_id, step_key, step_name, step_type,
                assignment_type, assignment_group_id, assignment_user_id, allow_request_information,
                parallel_join_step_key, end_status, configuration_json,
                display_x, display_y, display_width, display_height, lane_key, sort_order
            )
            VALUES
            (
                :id, :versionId, :stepKey, :stepName, :stepType,
                :assignmentType, :assignmentGroupId, :assignmentUserId, :allowRequestInformation,
                :parallelJoinStepKey, :endStatus, :configurationJson,
                :displayX, :displayY, :displayWidth, :displayHeight, :laneKey, :sortOrder
            )
            """, stepParams);

        SqlParameterSource[] transitionParams = graph.transitions().stream().map(transition -> new MapSqlParameterSource()
            .addValue("id", transition.id())
            .addValue("versionId", transition.workflowVersionId())
            .addValue("transitionKey", transition.transitionKey())
            .addValue("transitionName", transition.transitionName())
            .addValue("sourceStepId", transition.sourceStepId())
            .addValue("targetStepId", transition.targetStepId())
            .addValue("transitionType", transition.transitionType().name())
            .addValue("conditionJson", transition.conditionJson())
            .addValue("branchKey", transition.branchKey())
            .addValue("sortOrder", transition.sortOrder())).toArray(SqlParameterSource[]::new);
        jdbc.batchUpdate("""
            INSERT INTO workflow.workflow_transition
            (
                workflow_transition_id, workflow_version_id, transition_key, transition_name,
                source_step_id, target_step_id, transition_type, condition_json, branch_key, sort_order
            )
            VALUES
            (
                :id, :versionId, :transitionKey, :transitionName,
                :sourceStepId, :targetStepId, :transitionType, :conditionJson, :branchKey, :sortOrder
            )
            """, transitionParams);
    }

    public WorkflowGraph loadGraph(UUID versionId) {
        WorkflowVersion version = findVersionById(versionId).orElseThrow();
        WorkflowDefinition definition = findDefinitionById(version.workflowDefinitionId()).orElseThrow();
        List<WorkflowLane> lanes = jdbc.query("""
            SELECT workflow_lane_id, workflow_version_id, lane_key, lane_name, sort_order
            FROM workflow.workflow_lane
            WHERE workflow_version_id = :versionId
            ORDER BY sort_order, lane_key
            """, new MapSqlParameterSource("versionId", versionId), laneRowMapper());
        List<WorkflowStep> steps = jdbc.query("""
            SELECT workflow_step_id, workflow_version_id, step_key, step_name, step_type,
                   assignment_type, assignment_group_id, assignment_user_id, allow_request_information,
                   parallel_join_step_key, end_status, configuration_json,
                   display_x, display_y, display_width, display_height, lane_key, sort_order
            FROM workflow.workflow_step
            WHERE workflow_version_id = :versionId
            ORDER BY sort_order, step_key
            """, new MapSqlParameterSource("versionId", versionId), stepRowMapper());
        List<WorkflowTransition> transitions = jdbc.query("""
            SELECT workflow_transition_id, workflow_version_id, transition_key, transition_name,
                   source_step_id, target_step_id, transition_type, condition_json, branch_key, sort_order
            FROM workflow.workflow_transition
            WHERE workflow_version_id = :versionId
            ORDER BY sort_order, transition_key
            """, new MapSqlParameterSource("versionId", versionId), transitionRowMapper());
        return new WorkflowGraph(definition, version, lanes, steps, transitions);
    }

    public Optional<WorkflowStep> findStepById(UUID stepId) {
        return first(jdbc.query("""
            SELECT workflow_step_id, workflow_version_id, step_key, step_name, step_type,
                   assignment_type, assignment_group_id, assignment_user_id, allow_request_information,
                   parallel_join_step_key, end_status, configuration_json,
                   display_x, display_y, display_width, display_height, lane_key, sort_order
            FROM workflow.workflow_step
            WHERE workflow_step_id = :stepId
            """, new MapSqlParameterSource("stepId", stepId), stepRowMapper()));
    }

    public Optional<WorkflowStep> findStepByKey(UUID versionId, String stepKey) {
        return first(jdbc.query("""
            SELECT workflow_step_id, workflow_version_id, step_key, step_name, step_type,
                   assignment_type, assignment_group_id, assignment_user_id, allow_request_information,
                   parallel_join_step_key, end_status, configuration_json,
                   display_x, display_y, display_width, display_height, lane_key, sort_order
            FROM workflow.workflow_step
            WHERE workflow_version_id = :versionId AND step_key = :stepKey
            """, new MapSqlParameterSource()
            .addValue("versionId", versionId)
            .addValue("stepKey", stepKey), stepRowMapper()));
    }

    public List<WorkflowTransition> findOutgoingTransitions(UUID sourceStepId) {
        return jdbc.query("""
            SELECT workflow_transition_id, workflow_version_id, transition_key, transition_name,
                   source_step_id, target_step_id, transition_type, condition_json, branch_key, sort_order
            FROM workflow.workflow_transition
            WHERE source_step_id = :sourceStepId
            ORDER BY sort_order, transition_key
            """, new MapSqlParameterSource("sourceStepId", sourceStepId), transitionRowMapper());
    }

    public Optional<WorkflowTransition> findTransition(UUID sourceStepId, TransitionType type) {
        return first(jdbc.query("""
            SELECT workflow_transition_id, workflow_version_id, transition_key, transition_name,
                   source_step_id, target_step_id, transition_type, condition_json, branch_key, sort_order
            FROM workflow.workflow_transition
            WHERE source_step_id = :sourceStepId AND transition_type = :type
            ORDER BY sort_order, transition_key
            """, new MapSqlParameterSource()
            .addValue("sourceStepId", sourceStepId)
            .addValue("type", type.name()), transitionRowMapper()));
    }

    private RowMapper<WorkflowDefinition> definitionRowMapper() {
        return (rs, rowNum) -> new WorkflowDefinition(
            rs.getObject("workflow_definition_id", UUID.class),
            rs.getString("workflow_key"),
            rs.getString("workflow_name"),
            rs.getString("description"),
            rs.getBoolean("active"),
            rs.getString("created_by"),
            instant(rs, "created_at"),
            rs.getString("updated_by"),
            instant(rs, "updated_at")
        );
    }

    private RowMapper<WorkflowVersion> versionRowMapper() {
        return (rs, rowNum) -> new WorkflowVersion(
            rs.getObject("workflow_version_id", UUID.class),
            rs.getObject("workflow_definition_id", UUID.class),
            rs.getInt("version_number"),
            WorkflowVersionStatus.valueOf(rs.getString("version_status")),
            rs.getString("layout_json"),
            rs.getString("created_by"),
            instant(rs, "created_at"),
            rs.getString("published_by"),
            instant(rs, "published_at")
        );
    }

    private RowMapper<WorkflowLane> laneRowMapper() {
        return (rs, rowNum) -> new WorkflowLane(
            rs.getObject("workflow_lane_id", UUID.class),
            rs.getObject("workflow_version_id", UUID.class),
            rs.getString("lane_key"),
            rs.getString("lane_name"),
            rs.getInt("sort_order")
        );
    }

    private RowMapper<WorkflowStep> stepRowMapper() {
        return (rs, rowNum) -> new WorkflowStep(
            rs.getObject("workflow_step_id", UUID.class),
            rs.getObject("workflow_version_id", UUID.class),
            rs.getString("step_key"),
            rs.getString("step_name"),
            StepType.valueOf(rs.getString("step_type")),
            AssignmentType.valueOf(rs.getString("assignment_type")),
            rs.getString("assignment_group_id"),
            rs.getString("assignment_user_id"),
            rs.getBoolean("allow_request_information"),
            rs.getString("parallel_join_step_key"),
            enumOrNull(EndStatus.class, rs.getString("end_status")),
            rs.getString("configuration_json"),
            rs.getBigDecimal("display_x"),
            rs.getBigDecimal("display_y"),
            rs.getBigDecimal("display_width"),
            rs.getBigDecimal("display_height"),
            rs.getString("lane_key"),
            rs.getInt("sort_order")
        );
    }

    private RowMapper<WorkflowTransition> transitionRowMapper() {
        return (rs, rowNum) -> new WorkflowTransition(
            rs.getObject("workflow_transition_id", UUID.class),
            rs.getObject("workflow_version_id", UUID.class),
            rs.getString("transition_key"),
            rs.getString("transition_name"),
            rs.getObject("source_step_id", UUID.class),
            rs.getObject("target_step_id", UUID.class),
            TransitionType.valueOf(rs.getString("transition_type")),
            rs.getString("condition_json"),
            rs.getString("branch_key"),
            rs.getInt("sort_order")
        );
    }

    private static Instant instant(ResultSet rs, String column) throws SQLException {
        var timestamp = rs.getTimestamp(column);
        return timestamp == null ? null : timestamp.toInstant();
    }

    private static <E extends Enum<E>> E enumOrNull(Class<E> type, String value) {
        return value == null ? null : Enum.valueOf(type, value);
    }

    private static <T> Optional<T> first(List<T> values) {
        return values.stream().findFirst();
    }
}

package com.example.workflow.service;

import com.example.workflow.dto.CreateWorkflowRequest;
import com.example.workflow.dto.SaveWorkflowDraftRequest;
import com.example.workflow.dto.ValidationResponse;
import com.example.workflow.dto.WorkflowCreatedResponse;
import com.example.workflow.dto.WorkflowGraphResponse;
import com.example.workflow.dto.WorkflowPublishedResponse;
import com.example.workflow.enumtype.WorkflowVersionStatus;
import com.example.workflow.exception.NotFoundException;
import com.example.workflow.exception.WorkflowConflictException;
import com.example.workflow.model.WorkflowDefinition;
import com.example.workflow.model.WorkflowGraph;
import com.example.workflow.model.WorkflowVersion;
import com.example.workflow.repository.WorkflowDefinitionRepository;
import com.example.workflow.util.JsonSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class WorkflowDefinitionService {
    private final WorkflowDefinitionRepository repository;
    private final WorkflowGraphFactory graphFactory;
    private final WorkflowGraphValidator validator;
    private final WorkflowResponseMapper responseMapper;
    private final JsonSupport jsonSupport;

    public WorkflowDefinitionService(
        WorkflowDefinitionRepository repository,
        WorkflowGraphFactory graphFactory,
        WorkflowGraphValidator validator,
        WorkflowResponseMapper responseMapper,
        JsonSupport jsonSupport
    ) {
        this.repository = repository;
        this.graphFactory = graphFactory;
        this.validator = validator;
        this.responseMapper = responseMapper;
        this.jsonSupport = jsonSupport;
    }

    @Transactional
    public WorkflowCreatedResponse create(CreateWorkflowRequest request, String userId) {
        if (repository.findDefinitionByKey(request.workflowKey().trim()).isPresent()) {
            throw new WorkflowConflictException("Workflow key already exists: " + request.workflowKey());
        }

        WorkflowDefinition definition = repository.createDefinition(
            request.workflowKey().trim(),
            request.workflowName().trim(),
            request.description(),
            userId
        );
        WorkflowVersion draft = repository.createVersion(
            definition.id(),
            1,
            WorkflowVersionStatus.DRAFT,
            jsonSupport.write(request.layout()),
            userId
        );
        WorkflowGraph graph = graphFactory.create(
            definition, draft, request.lanes(), request.steps(), request.transitions()
        );
        repository.insertGraph(graph);
        return new WorkflowCreatedResponse(definition.id(), draft.id(), draft.versionNumber());
    }

    @Transactional
    public WorkflowGraphResponse saveDraft(
        UUID workflowDefinitionId,
        SaveWorkflowDraftRequest request,
        String userId
    ) {
        WorkflowDefinition definition = repository.findDefinitionById(workflowDefinitionId)
            .orElseThrow(() -> new NotFoundException("Workflow definition not found: " + workflowDefinitionId));
        WorkflowVersion draft = repository.findDraftForUpdate(workflowDefinitionId)
            .orElseThrow(() -> new NotFoundException("Draft workflow version not found"));

        repository.updateDefinitionMetadata(
            workflowDefinitionId,
            request.workflowName().trim(),
            request.description(),
            userId
        );
        repository.updateDraftLayout(draft.id(), jsonSupport.write(request.layout()));

        WorkflowDefinition updatedDefinition = repository.findDefinitionById(workflowDefinitionId).orElseThrow();
        WorkflowVersion updatedDraft = repository.findVersionById(draft.id()).orElseThrow();
        WorkflowGraph graph = graphFactory.create(
            updatedDefinition, updatedDraft, request.lanes(), request.steps(), request.transitions()
        );
        repository.replaceGraph(graph);
        return responseMapper.toResponse(repository.loadGraph(draft.id()));
    }

    @Transactional(readOnly = true)
    public WorkflowGraphResponse getDraft(UUID workflowDefinitionId) {
        WorkflowVersion draft = repository.findDraft(workflowDefinitionId)
            .orElseThrow(() -> new NotFoundException("Draft workflow version not found"));
        return responseMapper.toResponse(repository.loadGraph(draft.id()));
    }

    @Transactional(readOnly = true)
    public ValidationResponse validateDraft(UUID workflowDefinitionId) {
        WorkflowVersion draft = repository.findDraft(workflowDefinitionId)
            .orElseThrow(() -> new NotFoundException("Draft workflow version not found"));
        List<String> errors = validator.validate(repository.loadGraph(draft.id()));
        return errors.isEmpty() ? ValidationResponse.success() : ValidationResponse.failure(errors);
    }

    @Transactional
    public WorkflowPublishedResponse publish(UUID workflowDefinitionId, String userId) {
        WorkflowVersion draft = repository.findDraftForUpdate(workflowDefinitionId)
            .orElseThrow(() -> new NotFoundException("Draft workflow version not found"));
        WorkflowGraph draftGraph = repository.loadGraph(draft.id());
        validator.validateOrThrow(draftGraph);

        repository.markPublished(draft.id(), userId);
        WorkflowVersion published = repository.findVersionById(draft.id()).orElseThrow();

        WorkflowVersion nextDraft = repository.createVersion(
            workflowDefinitionId,
            published.versionNumber() + 1,
            WorkflowVersionStatus.DRAFT,
            published.layoutJson(),
            userId
        );
        WorkflowGraph nextDraftGraph = graphFactory.copyToVersion(draftGraph, nextDraft);
        repository.insertGraph(nextDraftGraph);

        return new WorkflowPublishedResponse(
            workflowDefinitionId,
            published.id(),
            published.versionNumber(),
            nextDraft.id(),
            nextDraft.versionNumber()
        );
    }

    @Transactional(readOnly = true)
    public List<WorkflowVersion> listVersions(UUID workflowDefinitionId) {
        if (repository.findDefinitionById(workflowDefinitionId).isEmpty()) {
            throw new NotFoundException("Workflow definition not found: " + workflowDefinitionId);
        }
        return repository.listVersions(workflowDefinitionId);
    }
}

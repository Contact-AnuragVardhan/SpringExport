package com.example.workflow.dto;

import com.example.workflow.enumtype.TransitionType;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.UUID;

public record TransitionView(
    UUID id,
    String transitionKey,
    String transitionName,
    String sourceStepKey,
    String targetStepKey,
    TransitionType transitionType,
    JsonNode condition,
    String branchKey,
    int sortOrder
) {}

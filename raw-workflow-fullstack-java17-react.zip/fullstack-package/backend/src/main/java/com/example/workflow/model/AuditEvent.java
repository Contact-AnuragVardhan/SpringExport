package com.example.workflow.model;

import com.example.workflow.enumtype.AuditEventType;
import java.time.Instant;
import java.util.UUID;

public record AuditEvent(
    long id,
    UUID workflowInstanceId,
    UUID workflowTokenId,
    UUID workflowTaskId,
    UUID fromStepId,
    UUID toStepId,
    AuditEventType eventType,
    String outcome,
    String performedByUserId,
    String performedForGroupId,
    String comments,
    String eventDataJson,
    Instant createdAt
) {}

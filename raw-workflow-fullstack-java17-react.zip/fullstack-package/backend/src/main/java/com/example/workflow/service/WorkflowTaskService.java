package com.example.workflow.service;

import com.example.workflow.dto.InformationTaskCreatedResponse;
import com.example.workflow.enumtype.AuditEventType;
import com.example.workflow.enumtype.ParallelScopeStatus;
import com.example.workflow.enumtype.TaskOutcome;
import com.example.workflow.enumtype.TaskType;
import com.example.workflow.enumtype.TokenStatus;
import com.example.workflow.enumtype.TransitionType;
import com.example.workflow.exception.NotFoundException;
import com.example.workflow.exception.WorkflowConflictException;
import com.example.workflow.exception.WorkflowValidationException;
import com.example.workflow.model.AuditRecord;
import com.example.workflow.model.ParallelScope;
import com.example.workflow.model.WorkflowInstance;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.model.WorkflowTask;
import com.example.workflow.model.WorkflowToken;
import com.example.workflow.model.WorkflowTransition;
import com.example.workflow.repository.WorkflowAuditRepository;
import com.example.workflow.repository.WorkflowDefinitionRepository;
import com.example.workflow.repository.WorkflowRuntimeRepository;
import com.example.workflow.repository.WorkflowTaskRepository;
import com.example.workflow.repository.WorkflowVariableRepository;
import com.example.workflow.util.JsonSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class WorkflowTaskService {
    private final WorkflowTaskRepository taskRepository;
    private final WorkflowRuntimeRepository runtimeRepository;
    private final WorkflowDefinitionRepository definitionRepository;
    private final WorkflowVariableRepository variableRepository;
    private final WorkflowAuditRepository auditRepository;
    private final WorkflowAuthorizationService authorizationService;
    private final WorkflowEngine workflowEngine;
    private final JsonSupport jsonSupport;

    public WorkflowTaskService(
        WorkflowTaskRepository taskRepository,
        WorkflowRuntimeRepository runtimeRepository,
        WorkflowDefinitionRepository definitionRepository,
        WorkflowVariableRepository variableRepository,
        WorkflowAuditRepository auditRepository,
        WorkflowAuthorizationService authorizationService,
        WorkflowEngine workflowEngine,
        JsonSupport jsonSupport
    ) {
        this.taskRepository = taskRepository;
        this.runtimeRepository = runtimeRepository;
        this.definitionRepository = definitionRepository;
        this.variableRepository = variableRepository;
        this.auditRepository = auditRepository;
        this.authorizationService = authorizationService;
        this.workflowEngine = workflowEngine;
        this.jsonSupport = jsonSupport;
    }

    @Transactional(readOnly = true)
    public List<WorkflowTask> findAvailableTasks(String userId) {
        return taskRepository.findAvailableTasks(userId);
    }

    @Transactional
    public void approve(UUID taskId, String userId, String comments) {
        WorkflowTask task = requireApprovalTaskForUpdate(taskId);
        authorizationService.verifyCanAct(task, userId);
        if (!taskRepository.completeOpenTask(taskId, userId, TaskOutcome.APPROVED)) {
            throw new WorkflowConflictException("Another user already completed this task");
        }

        WorkflowTransition transition = definitionRepository.findTransition(
                task.workflowStepId(), TransitionType.APPROVE)
            .orElseThrow(() -> new WorkflowValidationException("Approval step has no APPROVE transition"));
        WorkflowToken token = runtimeRepository.findTokenForUpdate(task.workflowTokenId())
            .orElseThrow(() -> new NotFoundException("Workflow token not found"));
        runtimeRepository.moveToken(token.id(), transition.targetStepId());

        auditRepository.record(new AuditRecord(
            task.workflowInstanceId(), token.id(), task.id(), task.workflowStepId(), transition.targetStepId(),
            AuditEventType.TASK_APPROVED, "APPROVED", userId, task.candidateGroupId(), comments, null));
        auditRepository.record(new AuditRecord(
            task.workflowInstanceId(), token.id(), task.id(), task.workflowStepId(), transition.targetStepId(),
            AuditEventType.STEP_COMPLETED, "APPROVED", userId, task.candidateGroupId(), comments, null));
        auditRepository.record(new AuditRecord(
            task.workflowInstanceId(), token.id(), task.id(), task.workflowStepId(), transition.targetStepId(),
            AuditEventType.STEP_ENTERED, null, userId, task.candidateGroupId(), null, null));

        workflowEngine.process(token.id());
    }

    @Transactional
    public void reject(UUID taskId, String userId, String comments) {
        WorkflowTask task = requireApprovalTaskForUpdate(taskId);
        authorizationService.verifyCanAct(task, userId);
        if (!taskRepository.completeOpenTask(taskId, userId, TaskOutcome.REJECTED)) {
            throw new WorkflowConflictException("Another user already completed this task");
        }

        WorkflowToken token = runtimeRepository.findTokenForUpdate(task.workflowTokenId())
            .orElseThrow(() -> new NotFoundException("Workflow token not found"));

        auditRepository.record(new AuditRecord(
            task.workflowInstanceId(), token.id(), task.id(), task.workflowStepId(), null,
            AuditEventType.TASK_REJECTED, "REJECTED", userId, task.candidateGroupId(), comments, null));

        if (token.parallelScopeId() != null) {
            cancelParallelSiblings(token, task, userId);
        }

        WorkflowTransition transition = definitionRepository.findTransition(
                task.workflowStepId(), TransitionType.REJECT)
            .orElseThrow(() -> new WorkflowValidationException("Approval step has no REJECT transition"));
        runtimeRepository.moveToken(token.id(), transition.targetStepId());
        auditRepository.record(new AuditRecord(
            task.workflowInstanceId(), token.id(), task.id(), task.workflowStepId(), transition.targetStepId(),
            AuditEventType.STEP_COMPLETED, "REJECTED", userId, task.candidateGroupId(), comments, null));
        auditRepository.record(new AuditRecord(
            task.workflowInstanceId(), token.id(), task.id(), task.workflowStepId(), transition.targetStepId(),
            AuditEventType.STEP_ENTERED, null, userId, task.candidateGroupId(), null, null));

        workflowEngine.process(token.id());
    }

    @Transactional
    public InformationTaskCreatedResponse requestInformation(
        UUID approvalTaskId,
        String userId,
        String comments
    ) {
        if (comments == null || comments.isBlank()) {
            throw new WorkflowValidationException("Comments are required when requesting more information");
        }
        WorkflowTask approvalTask = requireApprovalTaskForUpdate(approvalTaskId);
        authorizationService.verifyCanAct(approvalTask, userId);
        WorkflowStep step = definitionRepository.findStepById(approvalTask.workflowStepId())
            .orElseThrow(() -> new NotFoundException("Workflow step not found"));
        if (!step.allowRequestInformation()) {
            throw new WorkflowValidationException("This approval step does not allow information requests");
        }
        if (!taskRepository.moveToWaitingForInformation(approvalTaskId)) {
            throw new WorkflowConflictException("Another user already acted on this task");
        }

        WorkflowInstance instance = runtimeRepository.findInstanceForUpdate(approvalTask.workflowInstanceId())
            .orElseThrow(() -> new NotFoundException("Workflow instance not found"));
        int roundNumber = taskRepository.nextInformationRoundNumber(approvalTaskId);
        WorkflowTask informationTask = taskRepository.createInformationTask(
            instance.id(), approvalTask.workflowTokenId(), approvalTask.workflowStepId(),
            approvalTask.id(), instance.requesterUserId(), roundNumber,
            jsonSupport.writeObject(Map.of("question", comments, "roundNumber", roundNumber)));

        auditRepository.record(new AuditRecord(
            instance.id(), approvalTask.workflowTokenId(), approvalTask.id(),
            approvalTask.workflowStepId(), approvalTask.workflowStepId(),
            AuditEventType.INFORMATION_REQUESTED, "INFORMATION_REQUESTED", userId,
            approvalTask.candidateGroupId(), comments,
            Map.of("informationTaskId", informationTask.id(), "roundNumber", roundNumber)));
        auditRepository.record(new AuditRecord(
            instance.id(), approvalTask.workflowTokenId(), informationTask.id(),
            approvalTask.workflowStepId(), approvalTask.workflowStepId(),
            AuditEventType.TASK_CREATED, null, userId, null, null,
            Map.of("taskType", "EMPLOYEE_INFORMATION", "roundNumber", roundNumber,
                "assigneeUserId", instance.requesterUserId())));

        return new InformationTaskCreatedResponse(informationTask.id(), roundNumber);
    }

    @Transactional
    public void submitInformation(
        UUID informationTaskId,
        String userId,
        String comments,
        Map<String, Object> updatedRequestValues
    ) {
        WorkflowTask informationTask = taskRepository.findForUpdate(informationTaskId)
            .orElseThrow(() -> new NotFoundException("Information task not found: " + informationTaskId));
        if (informationTask.taskType() != TaskType.EMPLOYEE_INFORMATION) {
            throw new WorkflowValidationException("Task is not an employee information task");
        }
        authorizationService.verifyCanAct(informationTask, userId);
        if (informationTask.parentTaskId() == null) {
            throw new WorkflowValidationException("Information task has no parent approval task");
        }
        if (!taskRepository.completeInformationTask(informationTaskId, userId)) {
            throw new WorkflowConflictException("Information task is no longer open");
        }
        if (updatedRequestValues != null && !updatedRequestValues.isEmpty()) {
            variableRepository.upsertAll(informationTask.workflowInstanceId(), updatedRequestValues);
        }
        WorkflowTask parentTask = taskRepository.findForUpdate(informationTask.parentTaskId())
            .orElseThrow(() -> new NotFoundException("Parent approval task not found"));
        if (!taskRepository.reopenApprovalTask(parentTask.id())) {
            throw new WorkflowConflictException("Parent approval task cannot be reopened");
        }

        auditRepository.record(new AuditRecord(
            informationTask.workflowInstanceId(), informationTask.workflowTokenId(), informationTask.id(),
            informationTask.workflowStepId(), informationTask.workflowStepId(),
            AuditEventType.INFORMATION_SUBMITTED, "INFORMATION_SUBMITTED", userId,
            null, comments,
            Map.of("approvalTaskId", parentTask.id(), "roundNumber", informationTask.informationRoundNumber())));
        auditRepository.record(new AuditRecord(
            informationTask.workflowInstanceId(), informationTask.workflowTokenId(), parentTask.id(),
            informationTask.workflowStepId(), informationTask.workflowStepId(),
            AuditEventType.APPROVAL_REOPENED, null, userId,
            parentTask.candidateGroupId(), "Approval reopened for the original user/group", 
            Map.of("informationTaskId", informationTask.id(), "roundNumber", informationTask.informationRoundNumber())));
    }

    private WorkflowTask requireApprovalTaskForUpdate(UUID taskId) {
        WorkflowTask task = taskRepository.findForUpdate(taskId)
            .orElseThrow(() -> new NotFoundException("Workflow task not found: " + taskId));
        if (task.taskType() != TaskType.APPROVAL) {
            throw new WorkflowValidationException("Task is not an approval task");
        }
        return task;
    }

    private void cancelParallelSiblings(WorkflowToken rejectingToken, WorkflowTask rejectingTask, String userId) {
        ParallelScope scope = runtimeRepository.findParallelScopeForUpdate(rejectingToken.parallelScopeId())
            .orElseThrow(() -> new NotFoundException("Parallel scope not found"));
        if (scope.status() != ParallelScopeStatus.OPEN) {
            return;
        }

        List<WorkflowTask> siblingTasks = taskRepository.findCancellableTasksByScope(scope.id(), rejectingTask.id());
        List<WorkflowToken> siblingTokens = runtimeRepository.findCancellableSiblingTokens(scope.id(), rejectingToken.id());
        taskRepository.cancelTasksByScope(scope.id(), rejectingTask.id());
        runtimeRepository.cancelSiblingTokens(scope.id(), rejectingToken.id());
        runtimeRepository.cancelParallelScope(scope.id());

        for (WorkflowTask sibling : siblingTasks) {
            auditRepository.record(new AuditRecord(
                sibling.workflowInstanceId(), sibling.workflowTokenId(), sibling.id(), sibling.workflowStepId(), null,
                AuditEventType.TASK_CANCELLED, "CANCELLED", userId, sibling.candidateGroupId(),
                "Cancelled because another parallel approval was rejected",
                Map.of("rejectingTaskId", rejectingTask.id(), "parallelScopeId", scope.id())));
        }
        for (WorkflowToken siblingToken : siblingTokens) {
            auditRepository.record(new AuditRecord(
                siblingToken.workflowInstanceId(), siblingToken.id(), null, siblingToken.currentStepId(), null,
                AuditEventType.PARALLEL_BRANCH_CANCELLED, "CANCELLED", userId, null,
                "Cancelled because another parallel approval was rejected",
                Map.of("rejectingTaskId", rejectingTask.id(), "parallelScopeId", scope.id())));
        }
        auditRepository.record(new AuditRecord(
            rejectingTask.workflowInstanceId(), rejectingToken.id(), rejectingTask.id(),
            rejectingTask.workflowStepId(), null,
            AuditEventType.PARALLEL_SCOPE_CANCELLED, "REJECTED", userId,
            rejectingTask.candidateGroupId(), "Parallel scope cancelled after rejection",
            Map.of("parallelScopeId", scope.id(), "cancelledTaskCount", siblingTasks.size())));
    }
}

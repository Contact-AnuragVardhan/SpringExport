package com.example.workflow.repository;

import com.example.workflow.enumtype.VariableType;
import com.example.workflow.util.JsonSupport;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Repository
public class WorkflowVariableRepository {
    private final NamedParameterJdbcTemplate jdbc;
    private final JsonSupport jsonSupport;

    public WorkflowVariableRepository(NamedParameterJdbcTemplate jdbc, JsonSupport jsonSupport) {
        this.jdbc = jdbc;
        this.jsonSupport = jsonSupport;
    }

    public void upsertAll(UUID instanceId, Map<String, Object> variables) {
        variables.forEach((name, value) -> upsert(instanceId, name, value));
    }

    public void upsert(UUID instanceId, String name, Object value) {
        StoredVariable variable = StoredVariable.from(value, jsonSupport);
        jdbc.update("""
            MERGE workflow.workflow_variable AS TARGET
            USING (SELECT :instanceId AS workflow_instance_id, :name AS variable_name) AS SOURCE
              ON TARGET.workflow_instance_id = SOURCE.workflow_instance_id
             AND TARGET.variable_name = SOURCE.variable_name
            WHEN MATCHED THEN
              UPDATE SET variable_type = :type,
                         string_value = :stringValue,
                         number_value = :numberValue,
                         date_value = :dateValue,
                         boolean_value = :booleanValue,
                         json_value = :jsonValue,
                         updated_at = SYSUTCDATETIME()
            WHEN NOT MATCHED THEN
              INSERT
              (
                  workflow_instance_id, variable_name, variable_type,
                  string_value, number_value, date_value, boolean_value, json_value, updated_at
              )
              VALUES
              (
                  :instanceId, :name, :type,
                  :stringValue, :numberValue, :dateValue, :booleanValue, :jsonValue, SYSUTCDATETIME()
              );
            """, new MapSqlParameterSource()
            .addValue("instanceId", instanceId)
            .addValue("name", name)
            .addValue("type", variable.type().name())
            .addValue("stringValue", variable.stringValue())
            .addValue("numberValue", variable.numberValue())
            .addValue("dateValue", variable.dateValue())
            .addValue("booleanValue", variable.booleanValue())
            .addValue("jsonValue", variable.jsonValue()));
    }

    public Map<String, Object> loadVariables(UUID instanceId) {
        List<Map.Entry<String, Object>> entries = jdbc.query("""
            SELECT variable_name, variable_type, string_value, number_value,
                   date_value, boolean_value, json_value
            FROM workflow.workflow_variable
            WHERE workflow_instance_id = :instanceId
            """, new MapSqlParameterSource("instanceId", instanceId), (rs, rowNum) -> {
                String name = rs.getString("variable_name");
                VariableType type = VariableType.valueOf(rs.getString("variable_type"));
                Object value = switch (type) {
                    case STRING -> rs.getString("string_value");
                    case NUMBER -> rs.getBigDecimal("number_value");
                    case DATE -> {
                        Timestamp timestamp = rs.getTimestamp("date_value");
                        yield timestamp == null ? null : timestamp.toInstant();
                    }
                    case BOOLEAN -> rs.getObject("boolean_value") == null ? null : rs.getBoolean("boolean_value");
                    case JSON -> jsonSupport.readTree(rs.getString("json_value"));
                    case NULL -> null;
                };
                return Map.entry(name, value == null ? NullValue.INSTANCE : value);
            });

        Map<String, Object> result = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : entries) {
            result.put(entry.getKey(), entry.getValue() == NullValue.INSTANCE ? null : entry.getValue());
        }
        return result;
    }

    private enum NullValue { INSTANCE }

    private record StoredVariable(
        VariableType type,
        String stringValue,
        BigDecimal numberValue,
        Timestamp dateValue,
        Boolean booleanValue,
        String jsonValue
    ) {
        static StoredVariable from(Object value, JsonSupport jsonSupport) {
            if (value == null) {
                return new StoredVariable(VariableType.NULL, null, null, null, null, null);
            }
            if (value instanceof Boolean bool) {
                return new StoredVariable(VariableType.BOOLEAN, null, null, null, bool, null);
            }
            if (value instanceof Number number) {
                return new StoredVariable(VariableType.NUMBER, null, new BigDecimal(number.toString()), null, null, null);
            }
            if (value instanceof Instant instant) {
                return new StoredVariable(VariableType.DATE, null, null, Timestamp.from(instant), null, null);
            }
            if (value instanceof OffsetDateTime offsetDateTime) {
                return new StoredVariable(VariableType.DATE, null, null, Timestamp.from(offsetDateTime.toInstant()), null, null);
            }
            if (value instanceof LocalDateTime localDateTime) {
                return new StoredVariable(VariableType.DATE, null, null, Timestamp.valueOf(localDateTime), null, null);
            }
            if (value instanceof LocalDate localDate) {
                return new StoredVariable(VariableType.DATE, null, null, Timestamp.valueOf(localDate.atStartOfDay()), null, null);
            }
            if (value instanceof Map<?, ?> || value instanceof Iterable<?> || value.getClass().isArray()) {
                return new StoredVariable(VariableType.JSON, null, null, null, null, jsonSupport.writeObject(value));
            }
            return new StoredVariable(VariableType.STRING, String.valueOf(value), null, null, null, null);
        }
    }
}

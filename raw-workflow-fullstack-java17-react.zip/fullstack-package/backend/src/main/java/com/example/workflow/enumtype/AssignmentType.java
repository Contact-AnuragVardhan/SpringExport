package com.example.workflow.enumtype;

public enum AssignmentType { NONE, REQUESTER, REQUESTER_SUPERVISOR, GROUP, SPECIFIC_USER }

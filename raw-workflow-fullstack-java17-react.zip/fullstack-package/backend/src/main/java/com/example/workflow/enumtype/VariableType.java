package com.example.workflow.enumtype;

public enum VariableType { STRING, NUMBER, DATE, BOOLEAN, JSON, NULL }

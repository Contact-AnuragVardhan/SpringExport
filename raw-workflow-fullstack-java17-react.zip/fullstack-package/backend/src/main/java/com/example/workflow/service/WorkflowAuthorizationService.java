package com.example.workflow.service;

import com.example.workflow.enumtype.TaskStatus;
import com.example.workflow.exception.WorkflowAccessDeniedException;
import com.example.workflow.exception.WorkflowConflictException;
import com.example.workflow.model.WorkflowTask;
import com.example.workflow.repository.GroupMembershipRepository;
import org.springframework.stereotype.Service;

@Service
public class WorkflowAuthorizationService {
    private final GroupMembershipRepository groupMembershipRepository;

    public WorkflowAuthorizationService(GroupMembershipRepository groupMembershipRepository) {
        this.groupMembershipRepository = groupMembershipRepository;
    }

    public void verifyCanAct(WorkflowTask task, String userId) {
        if (task.status() != TaskStatus.OPEN) {
            throw new WorkflowConflictException("Task is no longer open");
        }
        if (task.assigneeUserId() != null) {
            if (!task.assigneeUserId().equals(userId)) {
                throw new WorkflowAccessDeniedException("Task is assigned to another user");
            }
            return;
        }
        if (task.candidateGroupId() == null
            || !groupMembershipRepository.isActiveMember(task.candidateGroupId(), userId)) {
            throw new WorkflowAccessDeniedException("User is not an active member of the assigned group");
        }
    }
}

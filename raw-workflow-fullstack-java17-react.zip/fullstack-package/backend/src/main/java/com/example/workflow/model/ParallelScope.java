package com.example.workflow.model;

import com.example.workflow.enumtype.ParallelScopeStatus;
import java.time.Instant;
import java.util.UUID;

public record ParallelScope(
    UUID id,
    UUID workflowInstanceId,
    UUID splitStepId,
    UUID joinStepId,
    UUID parentParallelScopeId,
    String parentBranchKey,
    int expectedBranchCount,
    int arrivedBranchCount,
    ParallelScopeStatus status,
    Instant createdAt,
    Instant completedAt
) {}

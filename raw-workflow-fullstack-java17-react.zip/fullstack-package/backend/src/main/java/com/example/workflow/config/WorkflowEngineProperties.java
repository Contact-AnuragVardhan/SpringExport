package com.example.workflow.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "workflow.engine")
public record WorkflowEngineProperties(int maxAutomaticSteps) {
    public WorkflowEngineProperties {
        if (maxAutomaticSteps <= 0) {
            maxAutomaticSteps = 500;
        }
    }
}

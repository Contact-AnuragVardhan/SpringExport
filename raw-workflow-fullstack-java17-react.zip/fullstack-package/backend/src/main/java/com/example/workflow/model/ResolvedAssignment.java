package com.example.workflow.model;

public record ResolvedAssignment(String assigneeUserId, String candidateGroupId) {
    public static ResolvedAssignment user(String userId) {
        return new ResolvedAssignment(userId, null);
    }

    public static ResolvedAssignment group(String groupId) {
        return new ResolvedAssignment(null, groupId);
    }
}

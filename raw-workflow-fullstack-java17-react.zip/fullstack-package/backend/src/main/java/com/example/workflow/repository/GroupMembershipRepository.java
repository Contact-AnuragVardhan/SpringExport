package com.example.workflow.repository;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class GroupMembershipRepository {
    private final NamedParameterJdbcTemplate jdbc;

    public GroupMembershipRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public boolean groupExists(String groupId) {
        Integer count = jdbc.queryForObject("""
            SELECT COUNT(1) FROM dbo.NM_GROUP WHERE GROUP_ID = :groupId
            """, new MapSqlParameterSource("groupId", groupId), Integer.class);
        return count != null && count > 0;
    }

    public boolean hasActiveMembers(String groupId) {
        Integer count = jdbc.queryForObject("""
            SELECT COUNT(1)
            FROM dbo.NM_GROUP_MEMBERS
            WHERE GROUP_ID = :groupId AND IS_ACTIVE = 1
            """, new MapSqlParameterSource("groupId", groupId), Integer.class);
        return count != null && count > 0;
    }

    public boolean isActiveMember(String groupId, String userId) {
        Integer count = jdbc.queryForObject("""
            SELECT COUNT(1)
            FROM dbo.NM_GROUP_MEMBERS
            WHERE GROUP_ID = :groupId
              AND USER_ID = :userId
              AND IS_ACTIVE = 1
            """, new MapSqlParameterSource()
            .addValue("groupId", groupId)
            .addValue("userId", userId), Integer.class);
        return count != null && count > 0;
    }
}

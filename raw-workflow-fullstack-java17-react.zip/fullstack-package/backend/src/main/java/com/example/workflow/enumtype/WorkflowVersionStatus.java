package com.example.workflow.enumtype;

public enum WorkflowVersionStatus { DRAFT, PUBLISHED, ARCHIVED }

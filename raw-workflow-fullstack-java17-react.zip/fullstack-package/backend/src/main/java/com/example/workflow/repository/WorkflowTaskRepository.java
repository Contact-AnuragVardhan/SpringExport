package com.example.workflow.repository;

import com.example.workflow.enumtype.TaskOutcome;
import com.example.workflow.enumtype.TaskStatus;
import com.example.workflow.enumtype.TaskType;
import com.example.workflow.model.WorkflowTask;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class WorkflowTaskRepository {
    private final NamedParameterJdbcTemplate jdbc;

    public WorkflowTaskRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public boolean hasActiveApprovalTask(UUID tokenId, UUID stepId) {
        Integer count = jdbc.queryForObject("""
            SELECT COUNT(1)
            FROM workflow.workflow_task
            WHERE workflow_token_id = :tokenId
              AND workflow_step_id = :stepId
              AND task_type = 'APPROVAL'
              AND task_status IN ('OPEN','WAITING_FOR_INFORMATION')
            """, new MapSqlParameterSource()
            .addValue("tokenId", tokenId)
            .addValue("stepId", stepId), Integer.class);
        return count != null && count > 0;
    }

    public WorkflowTask createApprovalTask(
        UUID instanceId,
        UUID tokenId,
        UUID stepId,
        String assigneeUserId,
        String candidateGroupId
    ) {
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO workflow.workflow_task
            (
                workflow_task_id, workflow_instance_id, workflow_token_id, workflow_step_id,
                task_type, task_status, assignee_user_id, candidate_group_id, created_at
            )
            VALUES
            (
                :id, :instanceId, :tokenId, :stepId,
                'APPROVAL', 'OPEN', :assigneeUserId, :candidateGroupId, SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("id", id)
            .addValue("instanceId", instanceId)
            .addValue("tokenId", tokenId)
            .addValue("stepId", stepId)
            .addValue("assigneeUserId", assigneeUserId)
            .addValue("candidateGroupId", candidateGroupId));
        return findById(id).orElseThrow();
    }

    public WorkflowTask createInformationTask(
        UUID instanceId,
        UUID tokenId,
        UUID stepId,
        UUID parentTaskId,
        String requesterUserId,
        int roundNumber,
        String payloadJson
    ) {
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO workflow.workflow_task
            (
                workflow_task_id, workflow_instance_id, workflow_token_id, workflow_step_id,
                parent_task_id, task_type, task_status, assignee_user_id,
                information_round_number, task_payload_json, created_at
            )
            VALUES
            (
                :id, :instanceId, :tokenId, :stepId,
                :parentTaskId, 'EMPLOYEE_INFORMATION', 'OPEN', :requesterUserId,
                :roundNumber, :payloadJson, SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("id", id)
            .addValue("instanceId", instanceId)
            .addValue("tokenId", tokenId)
            .addValue("stepId", stepId)
            .addValue("parentTaskId", parentTaskId)
            .addValue("requesterUserId", requesterUserId)
            .addValue("roundNumber", roundNumber)
            .addValue("payloadJson", payloadJson));
        return findById(id).orElseThrow();
    }

    public Optional<WorkflowTask> findById(UUID id) {
        return first(jdbc.query(taskSelect() + " WHERE T.workflow_task_id = :id",
            new MapSqlParameterSource("id", id), taskRowMapper()));
    }

    public Optional<WorkflowTask> findForUpdate(UUID id) {
        return first(jdbc.query("""
            SELECT T.workflow_task_id, T.workflow_instance_id, T.workflow_token_id,
                   T.workflow_step_id, T.parent_task_id, T.task_type, T.task_status,
                   T.assignee_user_id, T.candidate_group_id, T.information_round_number,
                   T.outcome, T.task_payload_json, T.created_at,
                   T.completed_by_user_id, T.completed_at
            FROM workflow.workflow_task T WITH (UPDLOCK, HOLDLOCK)
            WHERE T.workflow_task_id = :id
            """, new MapSqlParameterSource("id", id), taskRowMapper()));
    }

    public boolean completeOpenTask(UUID taskId, String userId, TaskOutcome outcome) {
        int updated = jdbc.update("""
            UPDATE workflow.workflow_task
            SET task_status = 'COMPLETED',
                outcome = :outcome,
                completed_by_user_id = :userId,
                completed_at = SYSUTCDATETIME()
            WHERE workflow_task_id = :taskId
              AND task_status = 'OPEN'
            """, new MapSqlParameterSource()
            .addValue("taskId", taskId)
            .addValue("userId", userId)
            .addValue("outcome", outcome.name()));
        return updated == 1;
    }

    public boolean moveToWaitingForInformation(UUID taskId) {
        int updated = jdbc.update("""
            UPDATE workflow.workflow_task
            SET task_status = 'WAITING_FOR_INFORMATION',
                outcome = 'INFORMATION_REQUESTED'
            WHERE workflow_task_id = :taskId
              AND task_status = 'OPEN'
              AND task_type = 'APPROVAL'
            """, new MapSqlParameterSource("taskId", taskId));
        return updated == 1;
    }

    public int nextInformationRoundNumber(UUID approvalTaskId) {
        Integer round = jdbc.queryForObject("""
            SELECT ISNULL(MAX(information_round_number), 0) + 1
            FROM workflow.workflow_task
            WHERE parent_task_id = :approvalTaskId
              AND task_type = 'EMPLOYEE_INFORMATION'
            """, new MapSqlParameterSource("approvalTaskId", approvalTaskId), Integer.class);
        return round == null ? 1 : round;
    }

    public boolean completeInformationTask(UUID taskId, String userId) {
        int updated = jdbc.update("""
            UPDATE workflow.workflow_task
            SET task_status = 'COMPLETED',
                outcome = 'INFORMATION_SUBMITTED',
                completed_by_user_id = :userId,
                completed_at = SYSUTCDATETIME()
            WHERE workflow_task_id = :taskId
              AND task_status = 'OPEN'
              AND task_type = 'EMPLOYEE_INFORMATION'
            """, new MapSqlParameterSource()
            .addValue("taskId", taskId)
            .addValue("userId", userId));
        return updated == 1;
    }

    public boolean reopenApprovalTask(UUID taskId) {
        int updated = jdbc.update("""
            UPDATE workflow.workflow_task
            SET task_status = 'OPEN',
                outcome = NULL,
                completed_by_user_id = NULL,
                completed_at = NULL
            WHERE workflow_task_id = :taskId
              AND task_status = 'WAITING_FOR_INFORMATION'
              AND task_type = 'APPROVAL'
            """, new MapSqlParameterSource("taskId", taskId));
        return updated == 1;
    }

    public List<WorkflowTask> findAvailableTasks(String userId) {
        return jdbc.query(taskSelect() + """
            WHERE T.task_status = 'OPEN'
              AND
              (
                  T.assignee_user_id = :userId
                  OR EXISTS
                  (
                      SELECT 1
                      FROM dbo.NM_GROUP_MEMBERS GM
                      WHERE GM.GROUP_ID = T.candidate_group_id
                        AND GM.USER_ID = :userId
                        AND GM.IS_ACTIVE = 1
                  )
              )
            ORDER BY T.created_at
            """, new MapSqlParameterSource("userId", userId), taskRowMapper());
    }

    public List<WorkflowTask> findByInstance(UUID instanceId) {
        return jdbc.query(taskSelect() + " WHERE T.workflow_instance_id = :instanceId ORDER BY T.created_at",
            new MapSqlParameterSource("instanceId", instanceId), taskRowMapper());
    }

    public List<WorkflowTask> findCancellableTasksByScope(UUID scopeId, UUID excludingTaskId) {
        return jdbc.query(taskSelect() + """
            INNER JOIN workflow.workflow_token WT
                ON WT.workflow_token_id = T.workflow_token_id
            WHERE WT.parallel_scope_id = :scopeId
              AND (:excludingTaskId IS NULL OR T.workflow_task_id <> :excludingTaskId)
              AND T.task_status IN ('OPEN','WAITING_FOR_INFORMATION')
            ORDER BY T.created_at
            """, new MapSqlParameterSource()
            .addValue("scopeId", scopeId)
            .addValue("excludingTaskId", excludingTaskId), taskRowMapper());
    }

    public void cancelTasksByScope(UUID scopeId, UUID excludingTaskId) {
        jdbc.update("""
            UPDATE T
            SET T.task_status = 'CANCELLED',
                T.outcome = 'CANCELLED',
                T.completed_at = SYSUTCDATETIME()
            FROM workflow.workflow_task T
            INNER JOIN workflow.workflow_token WT
                ON WT.workflow_token_id = T.workflow_token_id
            WHERE WT.parallel_scope_id = :scopeId
              AND (:excludingTaskId IS NULL OR T.workflow_task_id <> :excludingTaskId)
              AND T.task_status IN ('OPEN','WAITING_FOR_INFORMATION')
            """, new MapSqlParameterSource()
            .addValue("scopeId", scopeId)
            .addValue("excludingTaskId", excludingTaskId));
    }

    public List<WorkflowTask> findCancellableTasksByInstance(UUID instanceId, UUID excludingTaskId) {
        return jdbc.query(taskSelect() + """
            WHERE T.workflow_instance_id = :instanceId
              AND (:excludingTaskId IS NULL OR T.workflow_task_id <> :excludingTaskId)
              AND T.task_status IN ('OPEN','WAITING_FOR_INFORMATION')
            ORDER BY T.created_at
            """, new MapSqlParameterSource()
            .addValue("instanceId", instanceId)
            .addValue("excludingTaskId", excludingTaskId), taskRowMapper());
    }

    public void cancelTasksByInstance(UUID instanceId, UUID excludingTaskId) {
        jdbc.update("""
            UPDATE workflow.workflow_task
            SET task_status = 'CANCELLED',
                outcome = 'CANCELLED',
                completed_at = SYSUTCDATETIME()
            WHERE workflow_instance_id = :instanceId
              AND (:excludingTaskId IS NULL OR workflow_task_id <> :excludingTaskId)
              AND task_status IN ('OPEN','WAITING_FOR_INFORMATION')
            """, new MapSqlParameterSource()
            .addValue("instanceId", instanceId)
            .addValue("excludingTaskId", excludingTaskId));
    }

    private String taskSelect() {
        return """
            SELECT T.workflow_task_id, T.workflow_instance_id, T.workflow_token_id,
                   T.workflow_step_id, T.parent_task_id, T.task_type, T.task_status,
                   T.assignee_user_id, T.candidate_group_id, T.information_round_number,
                   T.outcome, T.task_payload_json, T.created_at,
                   T.completed_by_user_id, T.completed_at
            FROM workflow.workflow_task T
            """;
    }

    private RowMapper<WorkflowTask> taskRowMapper() {
        return (rs, rowNum) -> new WorkflowTask(
            rs.getObject("workflow_task_id", UUID.class),
            rs.getObject("workflow_instance_id", UUID.class),
            rs.getObject("workflow_token_id", UUID.class),
            rs.getObject("workflow_step_id", UUID.class),
            rs.getObject("parent_task_id", UUID.class),
            TaskType.valueOf(rs.getString("task_type")),
            TaskStatus.valueOf(rs.getString("task_status")),
            rs.getString("assignee_user_id"),
            rs.getString("candidate_group_id"),
            (Integer) rs.getObject("information_round_number"),
            enumOrNull(TaskOutcome.class, rs.getString("outcome")),
            rs.getString("task_payload_json"),
            instant(rs, "created_at"),
            rs.getString("completed_by_user_id"),
            instant(rs, "completed_at")
        );
    }

    private static Instant instant(ResultSet rs, String column) throws SQLException {
        var timestamp = rs.getTimestamp(column);
        return timestamp == null ? null : timestamp.toInstant();
    }

    private static <E extends Enum<E>> E enumOrNull(Class<E> type, String value) {
        return value == null ? null : Enum.valueOf(type, value);
    }

    private static <T> Optional<T> first(List<T> values) {
        return values.stream().findFirst();
    }
}

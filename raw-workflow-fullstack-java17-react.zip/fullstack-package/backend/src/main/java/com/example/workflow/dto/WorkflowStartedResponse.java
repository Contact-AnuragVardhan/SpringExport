package com.example.workflow.dto;

import java.util.UUID;

public record WorkflowStartedResponse(UUID workflowInstanceId) {}

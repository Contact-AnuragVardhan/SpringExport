package com.example.workflow.service;

import com.example.workflow.dto.LaneInput;
import com.example.workflow.dto.StepInput;
import com.example.workflow.dto.TransitionInput;
import com.example.workflow.exception.WorkflowValidationException;
import com.example.workflow.model.WorkflowDefinition;
import com.example.workflow.model.WorkflowGraph;
import com.example.workflow.model.WorkflowLane;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.model.WorkflowTransition;
import com.example.workflow.model.WorkflowVersion;
import com.example.workflow.util.JsonSupport;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Component
public class WorkflowGraphFactory {
    private final JsonSupport jsonSupport;

    public WorkflowGraphFactory(JsonSupport jsonSupport) {
        this.jsonSupport = jsonSupport;
    }

    public WorkflowGraph create(
        WorkflowDefinition definition,
        WorkflowVersion version,
        List<LaneInput> laneInputs,
        List<StepInput> stepInputs,
        List<TransitionInput> transitionInputs
    ) {
        Map<String, WorkflowLane> lanesByKey = new LinkedHashMap<>();
        for (LaneInput input : laneInputs) {
            String key = input.laneKey().trim();
            if (lanesByKey.containsKey(key)) {
                throw new WorkflowValidationException("Duplicate lane key: " + key);
            }
            lanesByKey.put(key, new WorkflowLane(
                UUID.randomUUID(), version.id(), key, input.laneName().trim(), valueOrZero(input.sortOrder())
            ));
        }

        Map<String, WorkflowStep> stepsByKey = new LinkedHashMap<>();
        for (StepInput input : stepInputs) {
            String key = input.stepKey().trim();
            if (stepsByKey.containsKey(key)) {
                throw new WorkflowValidationException("Duplicate step key: " + key);
            }
            if (input.laneKey() != null && !input.laneKey().isBlank() && !lanesByKey.containsKey(input.laneKey())) {
                throw new WorkflowValidationException("Unknown lane key '" + input.laneKey() + "' for step " + key);
            }
            stepsByKey.put(key, new WorkflowStep(
                UUID.randomUUID(),
                version.id(),
                key,
                input.stepName().trim(),
                input.stepType(),
                input.assignmentType(),
                blankToNull(input.assignmentGroupId()),
                blankToNull(input.assignmentUserId()),
                Boolean.TRUE.equals(input.allowRequestInformation()),
                blankToNull(input.parallelJoinStepKey()),
                input.endStatus(),
                jsonSupport.write(input.configuration()),
                input.displayX(), input.displayY(), input.displayWidth(), input.displayHeight(),
                blankToNull(input.laneKey()),
                valueOrZero(input.sortOrder())
            ));
        }

        List<WorkflowTransition> transitions = new ArrayList<>();
        Map<String, Boolean> transitionKeys = new HashMap<>();
        for (TransitionInput input : transitionInputs) {
            String key = input.transitionKey().trim();
            if (transitionKeys.putIfAbsent(key, Boolean.TRUE) != null) {
                throw new WorkflowValidationException("Duplicate transition key: " + key);
            }
            WorkflowStep source = stepsByKey.get(input.sourceStepKey());
            WorkflowStep target = stepsByKey.get(input.targetStepKey());
            if (source == null) {
                throw new WorkflowValidationException("Unknown transition source step: " + input.sourceStepKey());
            }
            if (target == null) {
                throw new WorkflowValidationException("Unknown transition target step: " + input.targetStepKey());
            }
            transitions.add(new WorkflowTransition(
                UUID.randomUUID(),
                version.id(),
                key,
                blankToNull(input.transitionName()),
                source.id(),
                target.id(),
                input.transitionType(),
                jsonSupport.write(input.condition()),
                blankToNull(input.branchKey()),
                valueOrZero(input.sortOrder())
            ));
        }

        return new WorkflowGraph(
            definition,
            version,
            new ArrayList<>(lanesByKey.values()),
            new ArrayList<>(stepsByKey.values()),
            transitions
        );
    }

    public WorkflowGraph copyToVersion(WorkflowGraph source, WorkflowVersion targetVersion) {
        List<WorkflowLane> lanes = source.lanes().stream()
            .map(lane -> new WorkflowLane(UUID.randomUUID(), targetVersion.id(), lane.laneKey(), lane.laneName(), lane.sortOrder()))
            .toList();

        Map<UUID, UUID> stepIdMap = new HashMap<>();
        List<WorkflowStep> steps = source.steps().stream().map(step -> {
            UUID newId = UUID.randomUUID();
            stepIdMap.put(step.id(), newId);
            return new WorkflowStep(
                newId, targetVersion.id(), step.stepKey(), step.stepName(), step.stepType(), step.assignmentType(),
                step.assignmentGroupId(), step.assignmentUserId(), step.allowRequestInformation(),
                step.parallelJoinStepKey(), step.endStatus(), step.configurationJson(),
                step.displayX(), step.displayY(), step.displayWidth(), step.displayHeight(), step.laneKey(), step.sortOrder()
            );
        }).toList();

        List<WorkflowTransition> transitions = source.transitions().stream()
            .map(transition -> new WorkflowTransition(
                UUID.randomUUID(), targetVersion.id(), transition.transitionKey(), transition.transitionName(),
                stepIdMap.get(transition.sourceStepId()), stepIdMap.get(transition.targetStepId()),
                transition.transitionType(), transition.conditionJson(), transition.branchKey(), transition.sortOrder()
            ))
            .toList();

        return new WorkflowGraph(source.definition(), targetVersion, lanes, steps, transitions);
    }

    private int valueOrZero(Integer value) {
        return value == null ? 0 : value;
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}

package com.example.workflow.dto;

import jakarta.validation.constraints.NotBlank;
import java.util.Map;

public record StartWorkflowRequest(
    @NotBlank String workflowKey,
    @NotBlank String businessType,
    @NotBlank String businessId,
    @NotBlank String requesterUserId,
    String requesterEmployeeId,
    Map<String, Object> variables
) {
    public StartWorkflowRequest {
        variables = variables == null ? Map.of() : Map.copyOf(variables);
    }
}

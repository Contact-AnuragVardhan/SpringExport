package com.example.workflow.dto;

import java.util.UUID;

public record InformationTaskCreatedResponse(UUID informationTaskId, int roundNumber) {}

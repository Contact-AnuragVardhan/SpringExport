package com.example.workflow.repository;

import com.example.workflow.enumtype.InstanceStatus;
import com.example.workflow.enumtype.ParallelScopeStatus;
import com.example.workflow.enumtype.TokenStatus;
import com.example.workflow.model.ParallelScope;
import com.example.workflow.model.WorkflowInstance;
import com.example.workflow.model.WorkflowToken;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class WorkflowRuntimeRepository {
    private final NamedParameterJdbcTemplate jdbc;

    public WorkflowRuntimeRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public WorkflowInstance createInstance(
        UUID versionId,
        String businessType,
        String businessId,
        String requesterUserId,
        String requesterEmployeeId,
        String startedBy
    ) {
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO workflow.workflow_instance
            (
                workflow_instance_id, workflow_version_id, business_type, business_id,
                requester_user_id, requester_employee_id, instance_status,
                started_by, started_at
            )
            VALUES
            (
                :id, :versionId, :businessType, :businessId,
                :requesterUserId, :requesterEmployeeId, 'RUNNING',
                :startedBy, SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("id", id)
            .addValue("versionId", versionId)
            .addValue("businessType", businessType)
            .addValue("businessId", businessId)
            .addValue("requesterUserId", requesterUserId)
            .addValue("requesterEmployeeId", requesterEmployeeId)
            .addValue("startedBy", startedBy));
        return findInstance(id).orElseThrow();
    }

    public Optional<WorkflowInstance> findInstance(UUID id) {
        return first(jdbc.query("""
            SELECT workflow_instance_id, workflow_version_id, business_type, business_id,
                   requester_user_id, requester_employee_id, instance_status,
                   started_by, started_at, completed_at
            FROM workflow.workflow_instance
            WHERE workflow_instance_id = :id
            """, new MapSqlParameterSource("id", id), instanceRowMapper()));
    }

    public Optional<WorkflowInstance> findInstanceForUpdate(UUID id) {
        return first(jdbc.query("""
            SELECT workflow_instance_id, workflow_version_id, business_type, business_id,
                   requester_user_id, requester_employee_id, instance_status,
                   started_by, started_at, completed_at
            FROM workflow.workflow_instance WITH (UPDLOCK, HOLDLOCK)
            WHERE workflow_instance_id = :id
            """, new MapSqlParameterSource("id", id), instanceRowMapper()));
    }

    public WorkflowToken createToken(
        UUID instanceId,
        UUID stepId,
        UUID parentTokenId,
        UUID parallelScopeId,
        String branchKey
    ) {
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO workflow.workflow_token
            (
                workflow_token_id, workflow_instance_id, current_step_id, token_status,
                parent_token_id, parallel_scope_id, branch_key, created_at
            )
            VALUES
            (
                :id, :instanceId, :stepId, 'ACTIVE',
                :parentTokenId, :parallelScopeId, :branchKey, SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("id", id)
            .addValue("instanceId", instanceId)
            .addValue("stepId", stepId)
            .addValue("parentTokenId", parentTokenId)
            .addValue("parallelScopeId", parallelScopeId)
            .addValue("branchKey", branchKey));
        return findToken(id).orElseThrow();
    }

    public Optional<WorkflowToken> findToken(UUID id) {
        return first(jdbc.query(tokenSelect() + " WHERE workflow_token_id = :id",
            new MapSqlParameterSource("id", id), tokenRowMapper()));
    }

    public Optional<WorkflowToken> findTokenForUpdate(UUID id) {
        return first(jdbc.query("""
            SELECT workflow_token_id, workflow_instance_id, current_step_id, token_status,
                   parent_token_id, parallel_scope_id, branch_key, created_at, completed_at
            FROM workflow.workflow_token WITH (UPDLOCK, HOLDLOCK)
            WHERE workflow_token_id = :id
            """, new MapSqlParameterSource("id", id), tokenRowMapper()));
    }

    public void moveToken(UUID tokenId, UUID targetStepId) {
        int updated = jdbc.update("""
            UPDATE workflow.workflow_token
            SET current_step_id = :targetStepId,
                token_status = 'ACTIVE',
                completed_at = NULL
            WHERE workflow_token_id = :tokenId
              AND token_status IN ('ACTIVE','WAITING_FOR_TASK')
            """, new MapSqlParameterSource()
            .addValue("tokenId", tokenId)
            .addValue("targetStepId", targetStepId));
        if (updated != 1) {
            throw new IllegalStateException("Token could not be moved: " + tokenId);
        }
    }

    public void setTokenStatus(UUID tokenId, TokenStatus status) {
        jdbc.update("""
            UPDATE workflow.workflow_token
            SET token_status = :status,
                completed_at = CASE WHEN :terminal = 1 THEN SYSUTCDATETIME() ELSE completed_at END
            WHERE workflow_token_id = :tokenId
            """, new MapSqlParameterSource()
            .addValue("tokenId", tokenId)
            .addValue("status", status.name())
            .addValue("terminal", isTerminal(status) ? 1 : 0));
    }

    public void completeToken(UUID tokenId) {
        setTokenStatus(tokenId, TokenStatus.COMPLETED);
    }

    public ParallelScope createParallelScope(
        UUID instanceId,
        UUID splitStepId,
        UUID joinStepId,
        UUID parentParallelScopeId,
        String parentBranchKey,
        int expectedBranches
    ) {
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO workflow.parallel_scope
            (
                parallel_scope_id, workflow_instance_id, split_step_id, join_step_id,
                parent_parallel_scope_id, parent_branch_key,
                expected_branch_count, arrived_branch_count, scope_status, created_at
            )
            VALUES
            (
                :id, :instanceId, :splitStepId, :joinStepId,
                :parentScopeId, :parentBranchKey,
                :expectedBranches, 0, 'OPEN', SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("id", id)
            .addValue("instanceId", instanceId)
            .addValue("splitStepId", splitStepId)
            .addValue("joinStepId", joinStepId)
            .addValue("parentScopeId", parentParallelScopeId)
            .addValue("parentBranchKey", parentBranchKey)
            .addValue("expectedBranches", expectedBranches));
        return findParallelScope(id).orElseThrow();
    }

    public Optional<ParallelScope> findParallelScope(UUID id) {
        return first(jdbc.query(scopeSelect() + " WHERE parallel_scope_id = :id",
            new MapSqlParameterSource("id", id), scopeRowMapper()));
    }

    public Optional<ParallelScope> findParallelScopeForUpdate(UUID id) {
        return first(jdbc.query("""
            SELECT parallel_scope_id, workflow_instance_id, split_step_id, join_step_id,
                   parent_parallel_scope_id, parent_branch_key,
                   expected_branch_count, arrived_branch_count, scope_status,
                   created_at, completed_at
            FROM workflow.parallel_scope WITH (UPDLOCK, HOLDLOCK)
            WHERE parallel_scope_id = :id
            """, new MapSqlParameterSource("id", id), scopeRowMapper()));
    }

    public int incrementArrivedCount(UUID scopeId) {
        jdbc.update("""
            UPDATE workflow.parallel_scope
            SET arrived_branch_count = arrived_branch_count + 1
            WHERE parallel_scope_id = :scopeId AND scope_status = 'OPEN'
            """, new MapSqlParameterSource("scopeId", scopeId));
        Integer count = jdbc.queryForObject("""
            SELECT arrived_branch_count
            FROM workflow.parallel_scope
            WHERE parallel_scope_id = :scopeId
            """, new MapSqlParameterSource("scopeId", scopeId), Integer.class);
        return count == null ? 0 : count;
    }

    public void completeParallelScope(UUID scopeId) {
        jdbc.update("""
            UPDATE workflow.parallel_scope
            SET scope_status = 'COMPLETED', completed_at = SYSUTCDATETIME()
            WHERE parallel_scope_id = :scopeId AND scope_status = 'OPEN'
            """, new MapSqlParameterSource("scopeId", scopeId));
    }

    public void cancelParallelScope(UUID scopeId) {
        jdbc.update("""
            UPDATE workflow.parallel_scope
            SET scope_status = 'CANCELLED', completed_at = SYSUTCDATETIME()
            WHERE parallel_scope_id = :scopeId AND scope_status = 'OPEN'
            """, new MapSqlParameterSource("scopeId", scopeId));
    }

    public void completeWaitingTokensAtJoin(UUID scopeId, UUID joinStepId) {
        jdbc.update("""
            UPDATE workflow.workflow_token
            SET token_status = 'COMPLETED', completed_at = SYSUTCDATETIME()
            WHERE parallel_scope_id = :scopeId
              AND current_step_id = :joinStepId
              AND token_status = 'WAITING_AT_JOIN'
            """, new MapSqlParameterSource()
            .addValue("scopeId", scopeId)
            .addValue("joinStepId", joinStepId));
    }

    public List<WorkflowToken> findCancellableSiblingTokens(UUID scopeId, UUID excludingTokenId) {
        return jdbc.query(tokenSelect() + """
            WHERE parallel_scope_id = :scopeId
              AND workflow_token_id <> :excludingTokenId
              AND token_status IN ('ACTIVE','WAITING_FOR_TASK','WAITING_AT_JOIN')
            """, new MapSqlParameterSource()
            .addValue("scopeId", scopeId)
            .addValue("excludingTokenId", excludingTokenId), tokenRowMapper());
    }

    public void cancelSiblingTokens(UUID scopeId, UUID excludingTokenId) {
        jdbc.update("""
            UPDATE workflow.workflow_token
            SET token_status = 'CANCELLED', completed_at = SYSUTCDATETIME()
            WHERE parallel_scope_id = :scopeId
              AND workflow_token_id <> :excludingTokenId
              AND token_status IN ('ACTIVE','WAITING_FOR_TASK','WAITING_AT_JOIN')
            """, new MapSqlParameterSource()
            .addValue("scopeId", scopeId)
            .addValue("excludingTokenId", excludingTokenId));
    }

    public void cancelOtherTokensInInstance(UUID instanceId, UUID excludingTokenId) {
        jdbc.update("""
            UPDATE workflow.workflow_token
            SET token_status = 'CANCELLED', completed_at = SYSUTCDATETIME()
            WHERE workflow_instance_id = :instanceId
              AND workflow_token_id <> :excludingTokenId
              AND token_status IN ('ACTIVE','WAITING_FOR_TASK','WAITING_AT_JOIN')
            """, new MapSqlParameterSource()
            .addValue("instanceId", instanceId)
            .addValue("excludingTokenId", excludingTokenId));
    }

    public long countNonTerminalTokens(UUID instanceId, UUID excludingTokenId) {
        Long count = jdbc.queryForObject("""
            SELECT COUNT_BIG(1)
            FROM workflow.workflow_token
            WHERE workflow_instance_id = :instanceId
              AND workflow_token_id <> :excludingTokenId
              AND token_status IN ('ACTIVE','WAITING_FOR_TASK','WAITING_AT_JOIN')
            """, new MapSqlParameterSource()
            .addValue("instanceId", instanceId)
            .addValue("excludingTokenId", excludingTokenId), Long.class);
        return count == null ? 0 : count;
    }

    public void completeInstance(UUID instanceId, InstanceStatus status) {
        jdbc.update("""
            UPDATE workflow.workflow_instance
            SET instance_status = :status,
                completed_at = SYSUTCDATETIME()
            WHERE workflow_instance_id = :instanceId
              AND instance_status = 'RUNNING'
            """, new MapSqlParameterSource()
            .addValue("instanceId", instanceId)
            .addValue("status", status.name()));
    }

    public List<WorkflowToken> findTokensByInstance(UUID instanceId) {
        return jdbc.query(tokenSelect() + " WHERE workflow_instance_id = :instanceId ORDER BY created_at",
            new MapSqlParameterSource("instanceId", instanceId), tokenRowMapper());
    }

    private String tokenSelect() {
        return """
            SELECT workflow_token_id, workflow_instance_id, current_step_id, token_status,
                   parent_token_id, parallel_scope_id, branch_key, created_at, completed_at
            FROM workflow.workflow_token
            """;
    }

    private String scopeSelect() {
        return """
            SELECT parallel_scope_id, workflow_instance_id, split_step_id, join_step_id,
                   parent_parallel_scope_id, parent_branch_key,
                   expected_branch_count, arrived_branch_count, scope_status,
                   created_at, completed_at
            FROM workflow.parallel_scope
            """;
    }

    private RowMapper<WorkflowInstance> instanceRowMapper() {
        return (rs, rowNum) -> new WorkflowInstance(
            rs.getObject("workflow_instance_id", UUID.class),
            rs.getObject("workflow_version_id", UUID.class),
            rs.getString("business_type"),
            rs.getString("business_id"),
            rs.getString("requester_user_id"),
            rs.getString("requester_employee_id"),
            InstanceStatus.valueOf(rs.getString("instance_status")),
            rs.getString("started_by"),
            instant(rs, "started_at"),
            instant(rs, "completed_at")
        );
    }

    private RowMapper<WorkflowToken> tokenRowMapper() {
        return (rs, rowNum) -> new WorkflowToken(
            rs.getObject("workflow_token_id", UUID.class),
            rs.getObject("workflow_instance_id", UUID.class),
            rs.getObject("current_step_id", UUID.class),
            TokenStatus.valueOf(rs.getString("token_status")),
            rs.getObject("parent_token_id", UUID.class),
            rs.getObject("parallel_scope_id", UUID.class),
            rs.getString("branch_key"),
            instant(rs, "created_at"),
            instant(rs, "completed_at")
        );
    }

    private RowMapper<ParallelScope> scopeRowMapper() {
        return (rs, rowNum) -> new ParallelScope(
            rs.getObject("parallel_scope_id", UUID.class),
            rs.getObject("workflow_instance_id", UUID.class),
            rs.getObject("split_step_id", UUID.class),
            rs.getObject("join_step_id", UUID.class),
            rs.getObject("parent_parallel_scope_id", UUID.class),
            rs.getString("parent_branch_key"),
            rs.getInt("expected_branch_count"),
            rs.getInt("arrived_branch_count"),
            ParallelScopeStatus.valueOf(rs.getString("scope_status")),
            instant(rs, "created_at"),
            instant(rs, "completed_at")
        );
    }

    private static boolean isTerminal(TokenStatus status) {
        return status == TokenStatus.COMPLETED || status == TokenStatus.CANCELLED || status == TokenStatus.FAILED;
    }

    private static Instant instant(ResultSet rs, String column) throws SQLException {
        var timestamp = rs.getTimestamp(column);
        return timestamp == null ? null : timestamp.toInstant();
    }

    private static <T> Optional<T> first(List<T> values) {
        return values.stream().findFirst();
    }
}

package com.example.workflow.controller;

import com.example.workflow.dto.RuntimeGraphResponse;
import com.example.workflow.dto.StartWorkflowRequest;
import com.example.workflow.dto.WorkflowStartedResponse;
import com.example.workflow.model.AuditEvent;
import com.example.workflow.model.WorkflowInstance;
import com.example.workflow.service.CurrentUserService;
import com.example.workflow.service.WorkflowQueryService;
import com.example.workflow.service.WorkflowRuntimeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/workflow-instances")
public class WorkflowInstanceController {
    private final WorkflowRuntimeService runtimeService;
    private final WorkflowQueryService queryService;
    private final CurrentUserService currentUserService;

    public WorkflowInstanceController(
        WorkflowRuntimeService runtimeService,
        WorkflowQueryService queryService,
        CurrentUserService currentUserService
    ) {
        this.runtimeService = runtimeService;
        this.queryService = queryService;
        this.currentUserService = currentUserService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public WorkflowStartedResponse start(
        @Valid @RequestBody StartWorkflowRequest request,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        return runtimeService.start(request, currentUserService.requireUserId(userHeader));
    }

    @GetMapping("/{instanceId}")
    public WorkflowInstance get(@PathVariable UUID instanceId) {
        return queryService.getInstance(instanceId);
    }

    @GetMapping("/{instanceId}/graph")
    public RuntimeGraphResponse graph(@PathVariable UUID instanceId) {
        return queryService.getRuntimeGraph(instanceId);
    }

    @GetMapping("/{instanceId}/audit")
    public List<AuditEvent> audit(@PathVariable UUID instanceId) {
        return queryService.getAudit(instanceId);
    }
}

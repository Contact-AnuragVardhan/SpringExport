package com.example.workflow.exception;

import java.util.List;

public class WorkflowValidationException extends RuntimeException {
    private final List<String> errors;

    public WorkflowValidationException(String message) {
        this(List.of(message));
    }

    public WorkflowValidationException(List<String> errors) {
        super(String.join("; ", errors));
        this.errors = List.copyOf(errors);
    }

    public List<String> getErrors() {
        return errors;
    }
}

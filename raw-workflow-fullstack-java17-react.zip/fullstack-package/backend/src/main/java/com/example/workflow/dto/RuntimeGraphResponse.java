package com.example.workflow.dto;

import com.example.workflow.enumtype.InstanceStatus;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public record RuntimeGraphResponse(
    UUID workflowInstanceId,
    InstanceStatus instanceStatus,
    WorkflowGraphResponse graph,
    List<String> activeStepKeys,
    List<String> waitingForInformationStepKeys,
    List<String> completedStepKeys,
    List<String> cancelledStepKeys,
    Map<String, List<String>> activeTaskIdsByStepKey
) {
    public RuntimeGraphResponse {
        activeStepKeys = List.copyOf(activeStepKeys);
        waitingForInformationStepKeys = List.copyOf(waitingForInformationStepKeys);
        completedStepKeys = List.copyOf(completedStepKeys);
        cancelledStepKeys = List.copyOf(cancelledStepKeys);
        activeTaskIdsByStepKey = Map.copyOf(activeTaskIdsByStepKey);
    }
}

package com.example.workflow.controller;

import com.example.workflow.dto.InformationTaskCreatedResponse;
import com.example.workflow.dto.RequestInformationRequest;
import com.example.workflow.dto.SubmitInformationRequest;
import com.example.workflow.dto.TaskCommentRequest;
import com.example.workflow.model.WorkflowTask;
import com.example.workflow.service.CurrentUserService;
import com.example.workflow.service.WorkflowTaskService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/workflow-tasks")
public class WorkflowTaskController {
    private final WorkflowTaskService workflowTaskService;
    private final CurrentUserService currentUserService;

    public WorkflowTaskController(
        WorkflowTaskService workflowTaskService,
        CurrentUserService currentUserService
    ) {
        this.workflowTaskService = workflowTaskService;
        this.currentUserService = currentUserService;
    }

    @GetMapping("/my")
    public List<WorkflowTask> myTasks(
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        return workflowTaskService.findAvailableTasks(currentUserService.requireUserId(userHeader));
    }

    @PostMapping("/{taskId}/approve")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void approve(
        @PathVariable UUID taskId,
        @RequestBody(required = false) TaskCommentRequest request,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        workflowTaskService.approve(
            taskId,
            currentUserService.requireUserId(userHeader),
            request == null ? null : request.comments()
        );
    }

    @PostMapping("/{taskId}/reject")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void reject(
        @PathVariable UUID taskId,
        @RequestBody(required = false) TaskCommentRequest request,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        workflowTaskService.reject(
            taskId,
            currentUserService.requireUserId(userHeader),
            request == null ? null : request.comments()
        );
    }

    @PostMapping("/{taskId}/request-information")
    public InformationTaskCreatedResponse requestInformation(
        @PathVariable UUID taskId,
        @Valid @RequestBody RequestInformationRequest request,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        return workflowTaskService.requestInformation(
            taskId,
            currentUserService.requireUserId(userHeader),
            request.comments()
        );
    }

    @PostMapping("/{taskId}/submit-information")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void submitInformation(
        @PathVariable UUID taskId,
        @Valid @RequestBody SubmitInformationRequest request,
        @RequestHeader(value = "X-User-Id", required = false) String userHeader
    ) {
        workflowTaskService.submitInformation(
            taskId,
            currentUserService.requireUserId(userHeader),
            request.comments(),
            request.updatedRequestValues()
        );
    }
}

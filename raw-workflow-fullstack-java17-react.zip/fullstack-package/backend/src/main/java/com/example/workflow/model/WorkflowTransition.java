package com.example.workflow.model;

import com.example.workflow.enumtype.TransitionType;
import java.util.UUID;

public record WorkflowTransition(
    UUID id,
    UUID workflowVersionId,
    String transitionKey,
    String transitionName,
    UUID sourceStepId,
    UUID targetStepId,
    TransitionType transitionType,
    String conditionJson,
    String branchKey,
    int sortOrder
) {}

package com.example.workflow.enumtype;

public enum TaskType { APPROVAL, EMPLOYEE_INFORMATION }

package com.example.workflow.service;

import com.example.workflow.exception.WorkflowAccessDeniedException;
import org.springframework.stereotype.Component;

@Component
public class CurrentUserService {
    public String requireUserId(String headerValue) {
        if (headerValue == null || headerValue.isBlank()) {
            throw new WorkflowAccessDeniedException("X-User-Id header is required");
        }
        return headerValue.trim();
    }
}

package com.example.workflow.enumtype;

public enum TaskOutcome { APPROVED, REJECTED, INFORMATION_REQUESTED, INFORMATION_SUBMITTED, CANCELLED }

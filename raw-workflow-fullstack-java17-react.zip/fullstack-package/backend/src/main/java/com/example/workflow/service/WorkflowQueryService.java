package com.example.workflow.service;

import com.example.workflow.dto.RuntimeGraphResponse;
import com.example.workflow.enumtype.AuditEventType;
import com.example.workflow.enumtype.TaskStatus;
import com.example.workflow.enumtype.TokenStatus;
import com.example.workflow.exception.NotFoundException;
import com.example.workflow.model.AuditEvent;
import com.example.workflow.model.WorkflowGraph;
import com.example.workflow.model.WorkflowInstance;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.model.WorkflowTask;
import com.example.workflow.model.WorkflowToken;
import com.example.workflow.repository.WorkflowAuditRepository;
import com.example.workflow.repository.WorkflowDefinitionRepository;
import com.example.workflow.repository.WorkflowRuntimeRepository;
import com.example.workflow.repository.WorkflowTaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class WorkflowQueryService {
    private final WorkflowRuntimeRepository runtimeRepository;
    private final WorkflowDefinitionRepository definitionRepository;
    private final WorkflowTaskRepository taskRepository;
    private final WorkflowAuditRepository auditRepository;
    private final WorkflowResponseMapper responseMapper;

    public WorkflowQueryService(
        WorkflowRuntimeRepository runtimeRepository,
        WorkflowDefinitionRepository definitionRepository,
        WorkflowTaskRepository taskRepository,
        WorkflowAuditRepository auditRepository,
        WorkflowResponseMapper responseMapper
    ) {
        this.runtimeRepository = runtimeRepository;
        this.definitionRepository = definitionRepository;
        this.taskRepository = taskRepository;
        this.auditRepository = auditRepository;
        this.responseMapper = responseMapper;
    }

    @Transactional(readOnly = true)
    public WorkflowInstance getInstance(UUID instanceId) {
        return runtimeRepository.findInstance(instanceId)
            .orElseThrow(() -> new NotFoundException("Workflow instance not found: " + instanceId));
    }

    @Transactional(readOnly = true)
    public List<AuditEvent> getAudit(UUID instanceId) {
        getInstance(instanceId);
        return auditRepository.findByInstance(instanceId);
    }

    @Transactional(readOnly = true)
    public RuntimeGraphResponse getRuntimeGraph(UUID instanceId) {
        WorkflowInstance instance = getInstance(instanceId);
        WorkflowGraph graph = definitionRepository.loadGraph(instance.workflowVersionId());
        Map<UUID, WorkflowStep> stepById = graph.steps().stream()
            .collect(Collectors.toMap(WorkflowStep::id, Function.identity()));
        List<WorkflowTask> tasks = taskRepository.findByInstance(instanceId);
        List<WorkflowToken> tokens = runtimeRepository.findTokensByInstance(instanceId);
        List<AuditEvent> events = auditRepository.findByInstance(instanceId);

        Set<String> active = new LinkedHashSet<>();
        Set<String> waiting = new LinkedHashSet<>();
        Set<String> completed = new LinkedHashSet<>();
        Set<String> cancelled = new LinkedHashSet<>();
        Map<String, List<String>> activeTasks = new LinkedHashMap<>();

        for (WorkflowToken token : tokens) {
            if (token.status() == TokenStatus.ACTIVE
                || token.status() == TokenStatus.WAITING_FOR_TASK
                || token.status() == TokenStatus.WAITING_AT_JOIN) {
                WorkflowStep step = stepById.get(token.currentStepId());
                if (step != null) {
                    active.add(step.stepKey());
                }
            }
        }

        for (WorkflowTask task : tasks) {
            WorkflowStep step = stepById.get(task.workflowStepId());
            if (step == null) {
                continue;
            }
            if (task.status() == TaskStatus.WAITING_FOR_INFORMATION) {
                waiting.add(step.stepKey());
            }
            if (task.status() == TaskStatus.OPEN || task.status() == TaskStatus.WAITING_FOR_INFORMATION) {
                activeTasks.computeIfAbsent(step.stepKey(), ignored -> new ArrayList<>())
                    .add(task.id().toString());
            }
        }

        for (AuditEvent event : events) {
            if (event.eventType() == AuditEventType.STEP_COMPLETED && event.fromStepId() != null) {
                WorkflowStep step = stepById.get(event.fromStepId());
                if (step != null) {
                    completed.add(step.stepKey());
                }
            }
            if ((event.eventType() == AuditEventType.TASK_CANCELLED
                || event.eventType() == AuditEventType.PARALLEL_BRANCH_CANCELLED)
                && event.fromStepId() != null) {
                WorkflowStep step = stepById.get(event.fromStepId());
                if (step != null) {
                    cancelled.add(step.stepKey());
                }
            }
        }

        active.removeAll(waiting);
        return new RuntimeGraphResponse(
            instance.id(), instance.status(), responseMapper.toResponse(graph),
            new ArrayList<>(active), new ArrayList<>(waiting),
            new ArrayList<>(completed), new ArrayList<>(cancelled), activeTasks
        );
    }
}

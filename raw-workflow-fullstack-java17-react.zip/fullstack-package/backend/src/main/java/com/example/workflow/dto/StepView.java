package com.example.workflow.dto;

import com.example.workflow.enumtype.AssignmentType;
import com.example.workflow.enumtype.EndStatus;
import com.example.workflow.enumtype.StepType;
import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import java.util.UUID;

public record StepView(
    UUID id,
    String stepKey,
    String stepName,
    StepType stepType,
    AssignmentType assignmentType,
    String assignmentGroupId,
    String assignmentUserId,
    boolean allowRequestInformation,
    String parallelJoinStepKey,
    EndStatus endStatus,
    JsonNode configuration,
    BigDecimal displayX,
    BigDecimal displayY,
    BigDecimal displayWidth,
    BigDecimal displayHeight,
    String laneKey,
    int sortOrder
) {}

package com.example.workflow.dto;

import com.example.workflow.enumtype.TransitionType;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record TransitionInput(
    @NotBlank String transitionKey,
    String transitionName,
    @NotBlank String sourceStepKey,
    @NotBlank String targetStepKey,
    @NotNull TransitionType transitionType,
    JsonNode condition,
    String branchKey,
    Integer sortOrder
) {}

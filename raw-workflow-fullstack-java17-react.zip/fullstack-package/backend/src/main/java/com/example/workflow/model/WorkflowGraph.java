package com.example.workflow.model;

import java.util.List;

public record WorkflowGraph(
    WorkflowDefinition definition,
    WorkflowVersion version,
    List<WorkflowLane> lanes,
    List<WorkflowStep> steps,
    List<WorkflowTransition> transitions
) {
    public WorkflowGraph {
        lanes = List.copyOf(lanes);
        steps = List.copyOf(steps);
        transitions = List.copyOf(transitions);
    }
}

package com.example.workflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class RawWorkflowEngineApplication {
    public static void main(String[] args) {
        SpringApplication.run(RawWorkflowEngineApplication.class, args);
    }
}

package com.example.workflow.model;

import com.example.workflow.enumtype.AssignmentType;
import com.example.workflow.enumtype.EndStatus;
import com.example.workflow.enumtype.StepType;
import java.math.BigDecimal;
import java.util.UUID;

public record WorkflowStep(
    UUID id,
    UUID workflowVersionId,
    String stepKey,
    String stepName,
    StepType stepType,
    AssignmentType assignmentType,
    String assignmentGroupId,
    String assignmentUserId,
    boolean allowRequestInformation,
    String parallelJoinStepKey,
    EndStatus endStatus,
    String configurationJson,
    BigDecimal displayX,
    BigDecimal displayY,
    BigDecimal displayWidth,
    BigDecimal displayHeight,
    String laneKey,
    int sortOrder
) {}

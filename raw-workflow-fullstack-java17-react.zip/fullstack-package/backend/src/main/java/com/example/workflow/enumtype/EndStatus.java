package com.example.workflow.enumtype;

public enum EndStatus { APPROVED, REJECTED, COMPLETED, CANCELLED }

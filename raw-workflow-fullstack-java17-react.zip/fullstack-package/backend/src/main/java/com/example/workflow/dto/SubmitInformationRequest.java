package com.example.workflow.dto;

import jakarta.validation.constraints.NotBlank;
import java.util.Map;

public record SubmitInformationRequest(
    @NotBlank String comments,
    Map<String, Object> updatedRequestValues
) {
    public SubmitInformationRequest {
        updatedRequestValues = updatedRequestValues == null ? Map.of() : Map.copyOf(updatedRequestValues);
    }
}

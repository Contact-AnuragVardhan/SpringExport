package com.example.workflow.dto;

import jakarta.validation.constraints.NotBlank;

public record LaneInput(
    @NotBlank String laneKey,
    @NotBlank String laneName,
    Integer sortOrder
) {}

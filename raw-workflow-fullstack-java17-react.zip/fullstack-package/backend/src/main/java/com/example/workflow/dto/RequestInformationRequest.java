package com.example.workflow.dto;

import jakarta.validation.constraints.NotBlank;

public record RequestInformationRequest(@NotBlank String comments) {}

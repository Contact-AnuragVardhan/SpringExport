package com.example.workflow.service;

import com.example.workflow.config.WorkflowEngineProperties;
import com.example.workflow.enumtype.AuditEventType;
import com.example.workflow.enumtype.EndStatus;
import com.example.workflow.enumtype.InstanceStatus;
import com.example.workflow.enumtype.ParallelScopeStatus;
import com.example.workflow.enumtype.StepType;
import com.example.workflow.enumtype.TokenStatus;
import com.example.workflow.enumtype.TransitionType;
import com.example.workflow.exception.NotFoundException;
import com.example.workflow.exception.WorkflowValidationException;
import com.example.workflow.model.AuditRecord;
import com.example.workflow.model.ParallelScope;
import com.example.workflow.model.ResolvedAssignment;
import com.example.workflow.model.WorkflowInstance;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.model.WorkflowTask;
import com.example.workflow.model.WorkflowToken;
import com.example.workflow.model.WorkflowTransition;
import com.example.workflow.repository.WorkflowAuditRepository;
import com.example.workflow.repository.WorkflowDefinitionRepository;
import com.example.workflow.repository.WorkflowRuntimeRepository;
import com.example.workflow.repository.WorkflowTaskRepository;
import com.example.workflow.repository.WorkflowVariableRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class WorkflowEngine {
    private static final String SYSTEM_USER = "SYSTEM";

    private final WorkflowDefinitionRepository definitionRepository;
    private final WorkflowRuntimeRepository runtimeRepository;
    private final WorkflowTaskRepository taskRepository;
    private final WorkflowVariableRepository variableRepository;
    private final WorkflowAuditRepository auditRepository;
    private final AssignmentResolver assignmentResolver;
    private final ConditionEvaluator conditionEvaluator;
    private final WorkflowEngineProperties properties;

    public WorkflowEngine(
        WorkflowDefinitionRepository definitionRepository,
        WorkflowRuntimeRepository runtimeRepository,
        WorkflowTaskRepository taskRepository,
        WorkflowVariableRepository variableRepository,
        WorkflowAuditRepository auditRepository,
        AssignmentResolver assignmentResolver,
        ConditionEvaluator conditionEvaluator,
        WorkflowEngineProperties properties
    ) {
        this.definitionRepository = definitionRepository;
        this.runtimeRepository = runtimeRepository;
        this.taskRepository = taskRepository;
        this.variableRepository = variableRepository;
        this.auditRepository = auditRepository;
        this.assignmentResolver = assignmentResolver;
        this.conditionEvaluator = conditionEvaluator;
        this.properties = properties;
    }

    @Transactional
    public void process(UUID initialTokenId) {
        Deque<UUID> queue = new ArrayDeque<>();
        queue.add(initialTokenId);
        int automaticSteps = 0;

        while (!queue.isEmpty()) {
            if (++automaticSteps > properties.maxAutomaticSteps()) {
                throw new WorkflowValidationException(
                    "Workflow exceeded the maximum automatic step count of " + properties.maxAutomaticSteps());
            }

            UUID tokenId = queue.removeFirst();
            WorkflowToken token = runtimeRepository.findTokenForUpdate(tokenId)
                .orElseThrow(() -> new NotFoundException("Workflow token not found: " + tokenId));
            if (token.status() != TokenStatus.ACTIVE) {
                continue;
            }

            WorkflowInstance instance = runtimeRepository.findInstanceForUpdate(token.workflowInstanceId())
                .orElseThrow(() -> new NotFoundException("Workflow instance not found: " + token.workflowInstanceId()));
            if (instance.status() != InstanceStatus.RUNNING) {
                runtimeRepository.setTokenStatus(token.id(), TokenStatus.CANCELLED);
                continue;
            }

            WorkflowStep step = definitionRepository.findStepById(token.currentStepId())
                .orElseThrow(() -> new NotFoundException("Workflow step not found: " + token.currentStepId()));

            switch (step.stepType()) {
                case START, AUTOMATIC_ACTION -> moveAlongSingleDefault(token, step, queue);
                case DECISION -> processDecision(token, step, queue);
                case APPROVAL -> createApprovalTask(instance, token, step);
                case PARALLEL_SPLIT -> processParallelSplit(instance, token, step, queue);
                case PARALLEL_JOIN -> processParallelJoin(instance, token, step, queue);
                case END -> processEnd(instance, token, step);
            }
        }
    }

    private void moveAlongSingleDefault(WorkflowToken token, WorkflowStep step, Deque<UUID> queue) {
        List<WorkflowTransition> outgoing = definitionRepository.findOutgoingTransitions(step.id());
        if (outgoing.size() != 1) {
            throw new WorkflowValidationException(
                step.stepType() + " step must have exactly one outgoing transition: " + step.stepKey());
        }
        moveTokenAndAudit(token, step, outgoing.get(0).targetStepId(), SYSTEM_USER, null);
        queue.addLast(token.id());
    }

    private void processDecision(WorkflowToken token, WorkflowStep step, Deque<UUID> queue) {
        List<WorkflowTransition> outgoing = new ArrayList<>(definitionRepository.findOutgoingTransitions(step.id()));
        outgoing.sort(Comparator.comparingInt(WorkflowTransition::sortOrder));
        Map<String, Object> variables = variableRepository.loadVariables(token.workflowInstanceId());

        WorkflowTransition selected = outgoing.stream()
            .filter(transition -> transition.transitionType() == TransitionType.CONDITIONAL)
            .filter(transition -> conditionEvaluator.evaluate(transition.conditionJson(), variables))
            .findFirst()
            .orElseGet(() -> outgoing.stream()
                .filter(transition -> transition.transitionType() == TransitionType.DEFAULT)
                .findFirst()
                .orElseThrow(() -> new WorkflowValidationException(
                    "Decision has no matching or default transition: " + step.stepKey())));

        moveTokenAndAudit(token, step, selected.targetStepId(), SYSTEM_USER, null);
        queue.addLast(token.id());
    }

    private void createApprovalTask(WorkflowInstance instance, WorkflowToken token, WorkflowStep step) {
        if (taskRepository.hasActiveApprovalTask(token.id(), step.id())) {
            runtimeRepository.setTokenStatus(token.id(), TokenStatus.WAITING_FOR_TASK);
            return;
        }

        ResolvedAssignment assignment = assignmentResolver.resolve(step, instance);
        WorkflowTask task = taskRepository.createApprovalTask(
            instance.id(), token.id(), step.id(), assignment.assigneeUserId(), assignment.candidateGroupId());
        runtimeRepository.setTokenStatus(token.id(), TokenStatus.WAITING_FOR_TASK);

        Map<String, Object> eventData = new LinkedHashMap<>();
        if (assignment.assigneeUserId() != null) {
            eventData.put("assigneeUserId", assignment.assigneeUserId());
        }
        if (assignment.candidateGroupId() != null) {
            eventData.put("candidateGroupId", assignment.candidateGroupId());
        }
        eventData.put("stepKey", step.stepKey());

        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), task.id(), null, step.id(),
            AuditEventType.TASK_CREATED, null, SYSTEM_USER,
            assignment.candidateGroupId(), null, eventData));
    }

    private void processParallelSplit(
        WorkflowInstance instance,
        WorkflowToken token,
        WorkflowStep splitStep,
        Deque<UUID> queue
    ) {
        List<WorkflowTransition> branches = definitionRepository.findOutgoingTransitions(splitStep.id());
        WorkflowStep joinStep = definitionRepository.findStepByKey(
                instance.workflowVersionId(), splitStep.parallelJoinStepKey())
            .orElseThrow(() -> new WorkflowValidationException(
                "Parallel join step not found: " + splitStep.parallelJoinStepKey()));

        ParallelScope scope = runtimeRepository.createParallelScope(
            instance.id(), splitStep.id(), joinStep.id(), token.parallelScopeId(), token.branchKey(), branches.size());
        runtimeRepository.completeToken(token.id());

        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, splitStep.id(), null,
            AuditEventType.PARALLEL_SCOPE_STARTED, null, SYSTEM_USER, null, null,
            Map.of("parallelScopeId", scope.id(), "expectedBranchCount", branches.size(),
                "joinStepKey", joinStep.stepKey())));
        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, splitStep.id(), null,
            AuditEventType.STEP_COMPLETED, null, SYSTEM_USER, null, null, null));

        for (WorkflowTransition branch : branches) {
            WorkflowToken child = runtimeRepository.createToken(
                instance.id(), branch.targetStepId(), token.id(), scope.id(), branch.branchKey());
            auditRepository.record(new AuditRecord(
                instance.id(), child.id(), null, splitStep.id(), branch.targetStepId(),
                AuditEventType.PARALLEL_BRANCH_STARTED, null, SYSTEM_USER, null, null,
                Map.of("parallelScopeId", scope.id(), "branchKey", branch.branchKey())));
            auditRepository.record(new AuditRecord(
                instance.id(), child.id(), null, splitStep.id(), branch.targetStepId(),
                AuditEventType.STEP_ENTERED, null, SYSTEM_USER, null, null, null));
            queue.addLast(child.id());
        }
    }

    private void processParallelJoin(
        WorkflowInstance instance,
        WorkflowToken token,
        WorkflowStep joinStep,
        Deque<UUID> queue
    ) {
        if (token.parallelScopeId() == null) {
            throw new WorkflowValidationException(
                "Token reached a parallel join without a parallel scope: " + token.id());
        }
        ParallelScope scope = runtimeRepository.findParallelScopeForUpdate(token.parallelScopeId())
            .orElseThrow(() -> new NotFoundException("Parallel scope not found: " + token.parallelScopeId()));
        if (scope.status() != ParallelScopeStatus.OPEN) {
            runtimeRepository.setTokenStatus(token.id(), TokenStatus.CANCELLED);
            return;
        }
        if (!scope.joinStepId().equals(joinStep.id())) {
            throw new WorkflowValidationException("Token reached the wrong parallel join step");
        }

        runtimeRepository.setTokenStatus(token.id(), TokenStatus.WAITING_AT_JOIN);
        int arrived = runtimeRepository.incrementArrivedCount(scope.id());
        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, joinStep.id(), joinStep.id(),
            AuditEventType.PARALLEL_BRANCH_ARRIVED, null, SYSTEM_USER, null, null,
            Map.of("parallelScopeId", scope.id(), "arrived", arrived,
                "expected", scope.expectedBranchCount())));

        if (arrived < scope.expectedBranchCount()) {
            return;
        }
        if (arrived > scope.expectedBranchCount()) {
            throw new WorkflowValidationException("Parallel join received more branches than expected");
        }

        runtimeRepository.completeWaitingTokensAtJoin(scope.id(), joinStep.id());
        runtimeRepository.completeParallelScope(scope.id());
        List<WorkflowTransition> outgoing = definitionRepository.findOutgoingTransitions(joinStep.id());
        if (outgoing.size() != 1) {
            throw new WorkflowValidationException(
                "Parallel join must have exactly one outgoing transition: " + joinStep.stepKey());
        }

        WorkflowToken merged = runtimeRepository.createToken(
            instance.id(), outgoing.get(0).targetStepId(), token.id(),
            scope.parentParallelScopeId(), scope.parentBranchKey());
        auditRepository.record(new AuditRecord(
            instance.id(), merged.id(), null, joinStep.id(), outgoing.get(0).targetStepId(),
            AuditEventType.PARALLEL_SCOPE_COMPLETED, null, SYSTEM_USER, null, null,
            Map.of("parallelScopeId", scope.id())));
        auditRepository.record(new AuditRecord(
            instance.id(), merged.id(), null, joinStep.id(), outgoing.get(0).targetStepId(),
            AuditEventType.STEP_ENTERED, null, SYSTEM_USER, null, null, null));
        queue.addLast(merged.id());
    }

    private void processEnd(WorkflowInstance instance, WorkflowToken token, WorkflowStep step) {
        runtimeRepository.completeToken(token.id());
        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, step.id(), null,
            AuditEventType.STEP_COMPLETED, step.endStatus().name(), SYSTEM_USER, null, null, null));

        if (step.endStatus() == EndStatus.REJECTED) {
            cancelRemainingInstanceWork(instance.id(), token.id());
            runtimeRepository.completeInstance(instance.id(), InstanceStatus.REJECTED);
            auditRepository.record(new AuditRecord(
                instance.id(), token.id(), null, step.id(), null,
                AuditEventType.INSTANCE_REJECTED, "REJECTED", SYSTEM_USER, null, null, null));
            return;
        }

        if (runtimeRepository.countNonTerminalTokens(instance.id(), token.id()) > 0) {
            return;
        }

        InstanceStatus status = switch (step.endStatus()) {
            case APPROVED -> InstanceStatus.APPROVED;
            case COMPLETED -> InstanceStatus.COMPLETED;
            case CANCELLED -> InstanceStatus.CANCELLED;
            case REJECTED -> InstanceStatus.REJECTED;
        };
        runtimeRepository.completeInstance(instance.id(), status);
        AuditEventType eventType = switch (status) {
            case APPROVED -> AuditEventType.INSTANCE_APPROVED;
            case COMPLETED -> AuditEventType.INSTANCE_COMPLETED;
            case CANCELLED -> AuditEventType.INSTANCE_CANCELLED;
            case REJECTED -> AuditEventType.INSTANCE_REJECTED;
            case RUNNING, FAILED -> throw new IllegalStateException("Unexpected terminal status: " + status);
        };
        auditRepository.record(new AuditRecord(
            instance.id(), token.id(), null, step.id(), null,
            eventType, status.name(), SYSTEM_USER, null, null, null));
    }

    private void cancelRemainingInstanceWork(UUID instanceId, UUID currentTokenId) {
        List<WorkflowTask> tasks = taskRepository.findCancellableTasksByInstance(instanceId, null);
        taskRepository.cancelTasksByInstance(instanceId, null);
        runtimeRepository.cancelOtherTokensInInstance(instanceId, currentTokenId);
        for (WorkflowTask task : tasks) {
            auditRepository.record(new AuditRecord(
                instanceId, task.workflowTokenId(), task.id(), task.workflowStepId(), null,
                AuditEventType.TASK_CANCELLED, "CANCELLED", SYSTEM_USER,
                task.candidateGroupId(), "Cancelled because the workflow was rejected", null));
        }
    }

    private void moveTokenAndAudit(
        WorkflowToken token,
        WorkflowStep sourceStep,
        UUID targetStepId,
        String performedBy,
        String comments
    ) {
        runtimeRepository.moveToken(token.id(), targetStepId);
        auditRepository.record(new AuditRecord(
            token.workflowInstanceId(), token.id(), null, sourceStep.id(), targetStepId,
            AuditEventType.STEP_COMPLETED, null, performedBy, null, comments, null));
        auditRepository.record(new AuditRecord(
            token.workflowInstanceId(), token.id(), null, sourceStep.id(), targetStepId,
            AuditEventType.STEP_ENTERED, null, performedBy, null, null, null));
    }
}

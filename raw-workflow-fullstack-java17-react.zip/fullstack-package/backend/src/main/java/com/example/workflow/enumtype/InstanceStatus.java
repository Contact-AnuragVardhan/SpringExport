package com.example.workflow.enumtype;

public enum InstanceStatus { RUNNING, APPROVED, REJECTED, COMPLETED, CANCELLED, FAILED }

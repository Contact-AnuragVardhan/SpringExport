package com.example.workflow.service;

import com.example.workflow.dto.LaneView;
import com.example.workflow.dto.StepView;
import com.example.workflow.dto.TransitionView;
import com.example.workflow.dto.WorkflowGraphResponse;
import com.example.workflow.model.WorkflowGraph;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.util.JsonSupport;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class WorkflowResponseMapper {
    private final JsonSupport jsonSupport;

    public WorkflowResponseMapper(JsonSupport jsonSupport) {
        this.jsonSupport = jsonSupport;
    }

    public WorkflowGraphResponse toResponse(WorkflowGraph graph) {
        Map<java.util.UUID, WorkflowStep> stepById = graph.steps().stream()
            .collect(Collectors.toMap(WorkflowStep::id, Function.identity()));

        return new WorkflowGraphResponse(
            graph.definition().id(),
            graph.definition().workflowKey(),
            graph.definition().workflowName(),
            graph.definition().description(),
            graph.version().id(),
            graph.version().versionNumber(),
            graph.version().status(),
            jsonSupport.readTree(graph.version().layoutJson()),
            graph.lanes().stream()
                .map(lane -> new LaneView(lane.id(), lane.laneKey(), lane.laneName(), lane.sortOrder()))
                .toList(),
            graph.steps().stream()
                .map(step -> new StepView(
                    step.id(), step.stepKey(), step.stepName(), step.stepType(), step.assignmentType(),
                    step.assignmentGroupId(), step.assignmentUserId(), step.allowRequestInformation(),
                    step.parallelJoinStepKey(), step.endStatus(), jsonSupport.readTree(step.configurationJson()),
                    step.displayX(), step.displayY(), step.displayWidth(), step.displayHeight(), step.laneKey(), step.sortOrder()
                ))
                .toList(),
            graph.transitions().stream()
                .map(transition -> new TransitionView(
                    transition.id(), transition.transitionKey(), transition.transitionName(),
                    stepById.get(transition.sourceStepId()).stepKey(),
                    stepById.get(transition.targetStepId()).stepKey(),
                    transition.transitionType(), jsonSupport.readTree(transition.conditionJson()),
                    transition.branchKey(), transition.sortOrder()
                ))
                .toList()
        );
    }
}

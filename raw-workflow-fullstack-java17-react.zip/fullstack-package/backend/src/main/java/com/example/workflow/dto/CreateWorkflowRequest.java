package com.example.workflow.dto;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public record CreateWorkflowRequest(
    @NotBlank String workflowKey,
    @NotBlank String workflowName,
    String description,
    JsonNode layout,
    List<@Valid LaneInput> lanes,
    @NotEmpty List<@Valid StepInput> steps,
    @NotEmpty List<@Valid TransitionInput> transitions
) {
    public CreateWorkflowRequest {
        lanes = lanes == null ? List.of() : List.copyOf(lanes);
        steps = steps == null ? List.of() : List.copyOf(steps);
        transitions = transitions == null ? List.of() : List.copyOf(transitions);
    }
}

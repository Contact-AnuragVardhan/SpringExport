package com.example.workflow.enumtype;

public enum ComparisonOperator { EQ, NE, GT, GTE, LT, LTE, IN, NOT_IN, IS_NULL, IS_NOT_NULL }

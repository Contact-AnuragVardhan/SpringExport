package com.example.workflow.exception;

public class WorkflowAccessDeniedException extends RuntimeException { public WorkflowAccessDeniedException(String message) { super(message); } }

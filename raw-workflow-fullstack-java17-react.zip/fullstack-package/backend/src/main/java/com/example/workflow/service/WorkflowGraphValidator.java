package com.example.workflow.service;

import com.example.workflow.enumtype.AssignmentType;
import com.example.workflow.enumtype.EndStatus;
import com.example.workflow.enumtype.StepType;
import com.example.workflow.enumtype.TransitionType;
import com.example.workflow.exception.WorkflowValidationException;
import com.example.workflow.model.WorkflowGraph;
import com.example.workflow.model.WorkflowStep;
import com.example.workflow.model.WorkflowTransition;
import com.example.workflow.repository.GroupMembershipRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Component
public class WorkflowGraphValidator {
    private final GroupMembershipRepository groupMembershipRepository;
    private final ConditionEvaluator conditionEvaluator;

    public WorkflowGraphValidator(
        GroupMembershipRepository groupMembershipRepository,
        ConditionEvaluator conditionEvaluator
    ) {
        this.groupMembershipRepository = groupMembershipRepository;
        this.conditionEvaluator = conditionEvaluator;
    }

    public void validateOrThrow(WorkflowGraph graph) {
        List<String> errors = validate(graph);
        if (!errors.isEmpty()) {
            throw new WorkflowValidationException(errors);
        }
    }

    public List<String> validate(WorkflowGraph graph) {
        List<String> errors = new ArrayList<>();
        Map<UUID, WorkflowStep> stepsById = graph.steps().stream()
            .collect(Collectors.toMap(WorkflowStep::id, step -> step));
        Map<String, WorkflowStep> stepsByKey = graph.steps().stream()
            .collect(Collectors.toMap(WorkflowStep::stepKey, step -> step));
        Map<UUID, List<WorkflowTransition>> outgoing = graph.transitions().stream()
            .collect(Collectors.groupingBy(WorkflowTransition::sourceStepId));
        Map<UUID, List<WorkflowTransition>> incoming = graph.transitions().stream()
            .collect(Collectors.groupingBy(WorkflowTransition::targetStepId));

        List<WorkflowStep> starts = graph.steps().stream().filter(step -> step.stepType() == StepType.START).toList();
        List<WorkflowStep> ends = graph.steps().stream().filter(step -> step.stepType() == StepType.END).toList();
        if (starts.size() != 1) {
            errors.add("Workflow must contain exactly one START step");
        }
        if (ends.isEmpty()) {
            errors.add("Workflow must contain at least one END step");
        }

        for (WorkflowTransition transition : graph.transitions()) {
            if (!stepsById.containsKey(transition.sourceStepId())) {
                errors.add("Transition " + transition.transitionKey() + " has an unknown source step");
            }
            if (!stepsById.containsKey(transition.targetStepId())) {
                errors.add("Transition " + transition.transitionKey() + " has an unknown target step");
            }
            if (transition.transitionType() == TransitionType.CONDITIONAL) {
                errors.addAll(conditionEvaluator.validate(transition.conditionJson()).stream()
                    .map(error -> "Transition " + transition.transitionKey() + ": " + error)
                    .toList());
            } else if (transition.conditionJson() != null) {
                errors.add("Only CONDITIONAL transitions may contain condition JSON: " + transition.transitionKey());
            }
        }

        for (WorkflowStep step : graph.steps()) {
            List<WorkflowTransition> stepOutgoing = outgoing.getOrDefault(step.id(), List.of());
            List<WorkflowTransition> stepIncoming = incoming.getOrDefault(step.id(), List.of());

            if (step.stepType() == StepType.START && !stepIncoming.isEmpty()) {
                errors.add("START step cannot have incoming transitions: " + step.stepKey());
            }
            if (step.stepType() == StepType.END && !stepOutgoing.isEmpty()) {
                errors.add("END step cannot have outgoing transitions: " + step.stepKey());
            }
            if (step.stepType() != StepType.START && stepIncoming.isEmpty()) {
                errors.add("Step has no incoming transition: " + step.stepKey());
            }
            if (step.stepType() != StepType.END && stepOutgoing.isEmpty()) {
                errors.add("Step has no outgoing transition: " + step.stepKey());
            }

            validateAssignment(step, errors);

            switch (step.stepType()) {
                case START, AUTOMATIC_ACTION -> {
                    if (stepOutgoing.size() != 1) {
                        errors.add(step.stepType() + " step must have exactly one outgoing transition: " + step.stepKey());
                    }
                }
                case END -> {
                    if (step.endStatus() == null) {
                        errors.add("END step requires endStatus: " + step.stepKey());
                    }
                }
                case APPROVAL -> validateApproval(step, stepOutgoing, stepsById, outgoing, errors);
                case DECISION -> validateDecision(step, stepOutgoing, errors);
                case PARALLEL_SPLIT -> validateParallelSplit(step, stepOutgoing, stepsByKey, stepsById, outgoing, errors);
                case PARALLEL_JOIN -> {
                    if (stepOutgoing.size() != 1) {
                        errors.add("PARALLEL_JOIN must have exactly one outgoing transition: " + step.stepKey());
                    }
                    if (stepIncoming.size() < 2) {
                        errors.add("PARALLEL_JOIN must have at least two incoming transitions: " + step.stepKey());
                    }
                }
            }
        }

        if (starts.size() == 1) {
            Set<UUID> reachable = reachableFrom(starts.get(0).id(), outgoing);
            for (WorkflowStep step : graph.steps()) {
                if (!reachable.contains(step.id())) {
                    errors.add("Unreachable step: " + step.stepKey());
                }
            }
        }

        detectAutomaticCycles(graph.steps(), outgoing, stepsById, errors);
        return errors.stream().distinct().toList();
    }

    private void validateAssignment(WorkflowStep step, List<String> errors) {
        if (step.stepType() != StepType.APPROVAL && step.assignmentType() != AssignmentType.NONE) {
            errors.add("Only APPROVAL steps may have an assignment: " + step.stepKey());
        }
        if (step.stepType() == StepType.APPROVAL && step.assignmentType() == AssignmentType.NONE) {
            errors.add("APPROVAL step requires an assignment: " + step.stepKey());
        }
        if (step.assignmentType() == AssignmentType.GROUP) {
            if (step.assignmentGroupId() == null || step.assignmentGroupId().isBlank()) {
                errors.add("GROUP assignment requires assignmentGroupId: " + step.stepKey());
            } else if (!groupMembershipRepository.groupExists(step.assignmentGroupId())) {
                errors.add("Group does not exist for step " + step.stepKey() + ": " + step.assignmentGroupId());
            } else if (!groupMembershipRepository.hasActiveMembers(step.assignmentGroupId())) {
                errors.add("Group has no active members for step " + step.stepKey() + ": " + step.assignmentGroupId());
            }
        }
        if (step.assignmentType() == AssignmentType.SPECIFIC_USER
            && (step.assignmentUserId() == null || step.assignmentUserId().isBlank())) {
            errors.add("SPECIFIC_USER assignment requires assignmentUserId: " + step.stepKey());
        }
    }

    private void validateApproval(
        WorkflowStep step,
        List<WorkflowTransition> stepOutgoing,
        Map<UUID, WorkflowStep> stepsById,
        Map<UUID, List<WorkflowTransition>> outgoing,
        List<String> errors
    ) {
        long approveCount = stepOutgoing.stream().filter(t -> t.transitionType() == TransitionType.APPROVE).count();
        long rejectCount = stepOutgoing.stream().filter(t -> t.transitionType() == TransitionType.REJECT).count();
        if (approveCount != 1) {
            errors.add("APPROVAL step requires exactly one APPROVE transition: " + step.stepKey());
        }
        if (rejectCount != 1) {
            errors.add("APPROVAL step requires exactly one REJECT transition: " + step.stepKey());
        }
        for (WorkflowTransition reject : stepOutgoing.stream().filter(t -> t.transitionType() == TransitionType.REJECT).toList()) {
            if (!pathExists(reject.targetStepId(), candidate -> candidate.stepType() == StepType.END
                && candidate.endStatus() == EndStatus.REJECTED, stepsById, outgoing, transition -> true)) {
                errors.add("REJECT path must lead to a REJECTED END step: " + step.stepKey());
            }
        }
    }

    private void validateDecision(WorkflowStep step, List<WorkflowTransition> stepOutgoing, List<String> errors) {
        long defaults = stepOutgoing.stream().filter(t -> t.transitionType() == TransitionType.DEFAULT).count();
        long conditional = stepOutgoing.stream().filter(t -> t.transitionType() == TransitionType.CONDITIONAL).count();
        if (defaults != 1) {
            errors.add("DECISION step requires exactly one DEFAULT transition: " + step.stepKey());
        }
        if (conditional < 1) {
            errors.add("DECISION step requires at least one CONDITIONAL transition: " + step.stepKey());
        }
        if (stepOutgoing.stream().anyMatch(t -> t.transitionType() == TransitionType.APPROVE
            || t.transitionType() == TransitionType.REJECT)) {
            errors.add("DECISION step may only use CONDITIONAL and DEFAULT transitions: " + step.stepKey());
        }
    }

    private void validateParallelSplit(
        WorkflowStep step,
        List<WorkflowTransition> stepOutgoing,
        Map<String, WorkflowStep> stepsByKey,
        Map<UUID, WorkflowStep> stepsById,
        Map<UUID, List<WorkflowTransition>> outgoing,
        List<String> errors
    ) {
        if (stepOutgoing.size() < 2) {
            errors.add("PARALLEL_SPLIT requires at least two outgoing transitions: " + step.stepKey());
        }
        if (step.parallelJoinStepKey() == null || step.parallelJoinStepKey().isBlank()) {
            errors.add("PARALLEL_SPLIT requires parallelJoinStepKey: " + step.stepKey());
            return;
        }
        WorkflowStep join = stepsByKey.get(step.parallelJoinStepKey());
        if (join == null || join.stepType() != StepType.PARALLEL_JOIN) {
            errors.add("PARALLEL_SPLIT references an invalid join step: " + step.stepKey());
            return;
        }
        Set<String> branchKeys = new HashSet<>();
        for (WorkflowTransition branch : stepOutgoing) {
            if (branch.branchKey() == null || branch.branchKey().isBlank()) {
                errors.add("Parallel branch requires branchKey: " + branch.transitionKey());
            } else if (!branchKeys.add(branch.branchKey())) {
                errors.add("Duplicate branchKey on parallel split " + step.stepKey() + ": " + branch.branchKey());
            }
            boolean reachesJoin = pathExists(branch.targetStepId(), candidate -> candidate.id().equals(join.id()),
                stepsById, outgoing, transition -> transition.transitionType() != TransitionType.REJECT);
            if (!reachesJoin) {
                errors.add("Parallel branch does not reach join " + join.stepKey() + ": " + branch.transitionKey());
            }
        }
    }

    private Set<UUID> reachableFrom(UUID startId, Map<UUID, List<WorkflowTransition>> outgoing) {
        Set<UUID> visited = new HashSet<>();
        ArrayDeque<UUID> queue = new ArrayDeque<>();
        queue.add(startId);
        while (!queue.isEmpty()) {
            UUID current = queue.removeFirst();
            if (!visited.add(current)) {
                continue;
            }
            outgoing.getOrDefault(current, List.of()).forEach(t -> queue.addLast(t.targetStepId()));
        }
        return visited;
    }

    private boolean pathExists(
        UUID startId,
        Predicate<WorkflowStep> goal,
        Map<UUID, WorkflowStep> stepsById,
        Map<UUID, List<WorkflowTransition>> outgoing,
        Predicate<WorkflowTransition> transitionFilter
    ) {
        Set<UUID> visited = new HashSet<>();
        ArrayDeque<UUID> queue = new ArrayDeque<>();
        queue.add(startId);
        while (!queue.isEmpty()) {
            UUID current = queue.removeFirst();
            if (!visited.add(current)) {
                continue;
            }
            WorkflowStep step = stepsById.get(current);
            if (step != null && goal.test(step)) {
                return true;
            }
            outgoing.getOrDefault(current, List.of()).stream()
                .filter(transitionFilter)
                .forEach(t -> queue.addLast(t.targetStepId()));
        }
        return false;
    }

    private void detectAutomaticCycles(
        List<WorkflowStep> steps,
        Map<UUID, List<WorkflowTransition>> outgoing,
        Map<UUID, WorkflowStep> stepsById,
        List<String> errors
    ) {
        Set<StepType> automaticTypes = Set.of(
            StepType.START, StepType.AUTOMATIC_ACTION, StepType.DECISION,
            StepType.PARALLEL_SPLIT, StepType.PARALLEL_JOIN
        );
        Set<UUID> visited = new HashSet<>();
        Set<UUID> visiting = new HashSet<>();
        for (WorkflowStep step : steps) {
            if (automaticTypes.contains(step.stepType())
                && detectCycle(step.id(), outgoing, stepsById, automaticTypes, visited, visiting)) {
                errors.add("Workflow contains an automatic cycle with no approval/wait step near: " + step.stepKey());
                return;
            }
        }
    }

    private boolean detectCycle(
        UUID current,
        Map<UUID, List<WorkflowTransition>> outgoing,
        Map<UUID, WorkflowStep> stepsById,
        Set<StepType> automaticTypes,
        Set<UUID> visited,
        Set<UUID> visiting
    ) {
        if (visiting.contains(current)) {
            return true;
        }
        if (!visited.add(current)) {
            return false;
        }
        visiting.add(current);
        for (WorkflowTransition transition : outgoing.getOrDefault(current, List.of())) {
            WorkflowStep target = stepsById.get(transition.targetStepId());
            if (target != null && automaticTypes.contains(target.stepType())
                && detectCycle(target.id(), outgoing, stepsById, automaticTypes, visited, visiting)) {
                return true;
            }
        }
        visiting.remove(current);
        return false;
    }
}

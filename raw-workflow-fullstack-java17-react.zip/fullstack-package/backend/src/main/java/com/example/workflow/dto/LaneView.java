package com.example.workflow.dto;

import java.util.UUID;

public record LaneView(UUID id, String laneKey, String laneName, int sortOrder) {}

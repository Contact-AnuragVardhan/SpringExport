package com.example.workflow.service;

import com.example.workflow.enumtype.ComparisonOperator;
import com.example.workflow.exception.WorkflowValidationException;
import com.example.workflow.util.JsonSupport;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
public class ConditionEvaluator {
    private final JsonSupport jsonSupport;

    public ConditionEvaluator(JsonSupport jsonSupport) {
        this.jsonSupport = jsonSupport;
    }

    public boolean evaluate(String conditionJson, Map<String, Object> variables) {
        JsonNode root = jsonSupport.readTree(conditionJson);
        if (root == null) {
            throw new WorkflowValidationException("Conditional transition does not contain a condition");
        }
        return evaluateNode(root, variables);
    }

    public List<String> validate(String conditionJson) {
        List<String> errors = new ArrayList<>();
        JsonNode root;
        try {
            root = jsonSupport.readTree(conditionJson);
        } catch (RuntimeException exception) {
            errors.add(exception.getMessage());
            return errors;
        }
        if (root == null) {
            errors.add("Condition is required");
            return errors;
        }
        validateNode(root, errors, "condition");
        return errors;
    }

    private boolean evaluateNode(JsonNode node, Map<String, Object> variables) {
        if (node.has("all")) {
            for (JsonNode child : node.get("all")) {
                if (!evaluateNode(child, variables)) {
                    return false;
                }
            }
            return true;
        }
        if (node.has("any")) {
            for (JsonNode child : node.get("any")) {
                if (evaluateNode(child, variables)) {
                    return true;
                }
            }
            return false;
        }

        String field = node.path("field").asText(null);
        String operatorText = node.path("operator").asText(null);
        if (field == null || operatorText == null) {
            throw new WorkflowValidationException("Condition requires field and operator");
        }
        ComparisonOperator operator;
        try {
            operator = ComparisonOperator.valueOf(operatorText);
        } catch (IllegalArgumentException exception) {
            throw new WorkflowValidationException("Unsupported condition operator: " + operatorText);
        }

        Object actualValue = variables.get(field);
        JsonNode expectedNode = node.get("value");

        return switch (operator) {
            case EQ -> valuesEqual(actualValue, expectedNode);
            case NE -> !valuesEqual(actualValue, expectedNode);
            case GT -> compare(actualValue, expectedNode) > 0;
            case GTE -> compare(actualValue, expectedNode) >= 0;
            case LT -> compare(actualValue, expectedNode) < 0;
            case LTE -> compare(actualValue, expectedNode) <= 0;
            case IN -> contains(expectedNode, actualValue);
            case NOT_IN -> !contains(expectedNode, actualValue);
            case IS_NULL -> actualValue == null;
            case IS_NOT_NULL -> actualValue != null;
        };
    }

    private void validateNode(JsonNode node, List<String> errors, String path) {
        boolean hasAll = node.has("all");
        boolean hasAny = node.has("any");
        if (hasAll || hasAny) {
            if (hasAll && hasAny) {
                errors.add(path + " cannot contain both 'all' and 'any'");
                return;
            }
            JsonNode children = node.get(hasAll ? "all" : "any");
            if (!children.isArray() || children.isEmpty()) {
                errors.add(path + " must contain a non-empty array");
                return;
            }
            int index = 0;
            for (JsonNode child : children) {
                validateNode(child, errors, path + "[" + index++ + "]");
            }
            return;
        }

        String field = node.path("field").asText(null);
        String operator = node.path("operator").asText(null);
        if (field == null || field.isBlank()) {
            errors.add(path + ".field is required");
        }
        if (operator == null || operator.isBlank()) {
            errors.add(path + ".operator is required");
            return;
        }
        ComparisonOperator parsed;
        try {
            parsed = ComparisonOperator.valueOf(operator);
        } catch (IllegalArgumentException exception) {
            errors.add(path + ".operator is unsupported: " + operator);
            return;
        }
        if (parsed != ComparisonOperator.IS_NULL && parsed != ComparisonOperator.IS_NOT_NULL && !node.has("value")) {
            errors.add(path + ".value is required for operator " + parsed);
        }
        if ((parsed == ComparisonOperator.IN || parsed == ComparisonOperator.NOT_IN)
            && (!node.has("value") || !node.get("value").isArray())) {
            errors.add(path + ".value must be an array for operator " + parsed);
        }
    }

    private boolean valuesEqual(Object actual, JsonNode expected) {
        Object left = normalizeActual(actual);
        Object right = normalizeExpected(expected);
        if (left instanceof BigDecimal leftNumber && right instanceof BigDecimal rightNumber) {
            return leftNumber.compareTo(rightNumber) == 0;
        }
        return Objects.equals(left, right);
    }

    private int compare(Object actual, JsonNode expected) {
        if (actual == null || expected == null || expected.isNull()) {
            throw new WorkflowValidationException("Cannot compare null values");
        }
        Object left = normalizeActual(actual);
        Object right = normalizeExpected(expected);
        if (left instanceof BigDecimal leftNumber && right instanceof BigDecimal rightNumber) {
            return leftNumber.compareTo(rightNumber);
        }
        return String.valueOf(left).compareTo(String.valueOf(right));
    }

    private boolean contains(JsonNode expectedValues, Object actual) {
        if (expectedValues == null || !expectedValues.isArray()) {
            throw new WorkflowValidationException("IN/NOT_IN requires an array value");
        }
        for (JsonNode expected : expectedValues) {
            if (valuesEqual(actual, expected)) {
                return true;
            }
        }
        return false;
    }

    private Object normalizeActual(Object value) {
        if (value instanceof Number number) {
            return new BigDecimal(number.toString());
        }
        if (value instanceof JsonNode node) {
            return normalizeExpected(node);
        }
        return value;
    }

    private Object normalizeExpected(JsonNode node) {
        if (node == null || node.isNull()) {
            return null;
        }
        if (node.isNumber()) {
            return node.decimalValue();
        }
        if (node.isBoolean()) {
            return node.booleanValue();
        }
        if (node.isTextual()) {
            return node.textValue();
        }
        return node.toString();
    }
}

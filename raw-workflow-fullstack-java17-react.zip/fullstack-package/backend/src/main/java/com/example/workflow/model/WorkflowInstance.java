package com.example.workflow.model;

import com.example.workflow.enumtype.InstanceStatus;
import java.time.Instant;
import java.util.UUID;

public record WorkflowInstance(
    UUID id,
    UUID workflowVersionId,
    String businessType,
    String businessId,
    String requesterUserId,
    String requesterEmployeeId,
    InstanceStatus status,
    String startedBy,
    Instant startedAt,
    Instant completedAt
) {}

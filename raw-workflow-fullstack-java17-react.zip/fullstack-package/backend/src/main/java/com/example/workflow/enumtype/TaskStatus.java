package com.example.workflow.enumtype;

public enum TaskStatus { OPEN, WAITING_FOR_INFORMATION, COMPLETED, CANCELLED }

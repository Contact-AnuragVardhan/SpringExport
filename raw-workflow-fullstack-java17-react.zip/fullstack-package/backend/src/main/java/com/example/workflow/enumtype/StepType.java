package com.example.workflow.enumtype;

public enum StepType { START, END, APPROVAL, DECISION, PARALLEL_SPLIT, PARALLEL_JOIN, AUTOMATIC_ACTION }

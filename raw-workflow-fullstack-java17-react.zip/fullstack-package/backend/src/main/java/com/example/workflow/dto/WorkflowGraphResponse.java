package com.example.workflow.dto;

import com.example.workflow.enumtype.WorkflowVersionStatus;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import java.util.UUID;

public record WorkflowGraphResponse(
    UUID workflowDefinitionId,
    String workflowKey,
    String workflowName,
    String description,
    UUID workflowVersionId,
    int versionNumber,
    WorkflowVersionStatus versionStatus,
    JsonNode layout,
    List<LaneView> lanes,
    List<StepView> steps,
    List<TransitionView> transitions
) {
    public WorkflowGraphResponse {
        lanes = List.copyOf(lanes);
        steps = List.copyOf(steps);
        transitions = List.copyOf(transitions);
    }
}

package com.example.workflow.model;

import com.example.workflow.enumtype.WorkflowVersionStatus;
import java.time.Instant;
import java.util.UUID;

public record WorkflowVersion(
    UUID id,
    UUID workflowDefinitionId,
    int versionNumber,
    WorkflowVersionStatus status,
    String layoutJson,
    String createdBy,
    Instant createdAt,
    String publishedBy,
    Instant publishedAt
) {}

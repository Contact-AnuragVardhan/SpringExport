package com.example.workflow.enumtype;

public enum TransitionType { DEFAULT, CONDITIONAL, APPROVE, REJECT }

package com.example.workflow.repository;

import com.example.workflow.enumtype.AuditEventType;
import com.example.workflow.model.AuditEvent;
import com.example.workflow.model.AuditRecord;
import com.example.workflow.util.JsonSupport;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Repository
public class WorkflowAuditRepository {
    private final NamedParameterJdbcTemplate jdbc;
    private final JsonSupport jsonSupport;

    public WorkflowAuditRepository(NamedParameterJdbcTemplate jdbc, JsonSupport jsonSupport) {
        this.jdbc = jdbc;
        this.jsonSupport = jsonSupport;
    }

    public void record(AuditRecord record) {
        jdbc.update("""
            INSERT INTO workflow.workflow_audit_event
            (
                workflow_instance_id, workflow_token_id, workflow_task_id,
                from_step_id, to_step_id, event_type, outcome,
                performed_by_user_id, performed_for_group_id,
                comments, event_data_json, created_at
            )
            VALUES
            (
                :instanceId, :tokenId, :taskId,
                :fromStepId, :toStepId, :eventType, :outcome,
                :performedBy, :performedForGroup,
                :comments, :eventDataJson, SYSUTCDATETIME()
            )
            """, new MapSqlParameterSource()
            .addValue("instanceId", record.workflowInstanceId())
            .addValue("tokenId", record.workflowTokenId())
            .addValue("taskId", record.workflowTaskId())
            .addValue("fromStepId", record.fromStepId())
            .addValue("toStepId", record.toStepId())
            .addValue("eventType", record.eventType().name())
            .addValue("outcome", record.outcome())
            .addValue("performedBy", record.performedByUserId())
            .addValue("performedForGroup", record.performedForGroupId())
            .addValue("comments", record.comments())
            .addValue("eventDataJson", jsonSupport.writeObject(record.eventData())));
    }

    public List<AuditEvent> findByInstance(UUID instanceId) {
        return jdbc.query("""
            SELECT audit_event_id, workflow_instance_id, workflow_token_id, workflow_task_id,
                   from_step_id, to_step_id, event_type, outcome,
                   performed_by_user_id, performed_for_group_id,
                   comments, event_data_json, created_at
            FROM workflow.workflow_audit_event
            WHERE workflow_instance_id = :instanceId
            ORDER BY audit_event_id
            """, new MapSqlParameterSource("instanceId", instanceId), rowMapper());
    }

    private RowMapper<AuditEvent> rowMapper() {
        return (rs, rowNum) -> new AuditEvent(
            rs.getLong("audit_event_id"),
            rs.getObject("workflow_instance_id", UUID.class),
            rs.getObject("workflow_token_id", UUID.class),
            rs.getObject("workflow_task_id", UUID.class),
            rs.getObject("from_step_id", UUID.class),
            rs.getObject("to_step_id", UUID.class),
            AuditEventType.valueOf(rs.getString("event_type")),
            rs.getString("outcome"),
            rs.getString("performed_by_user_id"),
            rs.getString("performed_for_group_id"),
            rs.getString("comments"),
            rs.getString("event_data_json"),
            instant(rs, "created_at")
        );
    }

    private static Instant instant(ResultSet rs, String column) throws SQLException {
        var timestamp = rs.getTimestamp(column);
        return timestamp == null ? null : timestamp.toInstant();
    }
}

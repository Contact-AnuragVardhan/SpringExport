package com.example.workflow.model;

import com.example.workflow.enumtype.TaskOutcome;
import com.example.workflow.enumtype.TaskStatus;
import com.example.workflow.enumtype.TaskType;
import java.time.Instant;
import java.util.UUID;

public record WorkflowTask(
    UUID id,
    UUID workflowInstanceId,
    UUID workflowTokenId,
    UUID workflowStepId,
    UUID parentTaskId,
    TaskType taskType,
    TaskStatus status,
    String assigneeUserId,
    String candidateGroupId,
    Integer informationRoundNumber,
    TaskOutcome outcome,
    String taskPayloadJson,
    Instant createdAt,
    String completedByUserId,
    Instant completedAt
) {}

# Raw Workflow Engine

A Maven-based Spring Boot application that implements a configurable workflow engine from scratch. It does **not** use Flowable, Camunda, Activiti, jBPM, or another workflow library.

## Runtime

- Java 17
- Maven
- Spring Boot
- Spring JDBC
- Microsoft SQL Server
- React-compatible REST APIs

## Supported workflow behavior

- Immutable published workflow versions
- Changes affect only newly started requests
- Sequential steps
- Conditional decision steps
- Parallel split and join steps, including nested parallel scopes
- Dynamic requester-supervisor assignment
- Group assignment through existing `dbo.NM_GROUP` and `dbo.NM_GROUP_MEMBERS`
- Any active group member can act; the first successful action wins
- Approve, reject, and request-more-information actions
- Unlimited request-more-information rounds
- Group task returns to the whole group after the employee responds
- Immediate cancellation of sibling tasks when a branch is rejected
- Full audit history with optional comments
- Diagram coordinates and visual lanes for React rendering

## Important integration points

### Temporary user identity

The starter APIs use the `X-User-Id` HTTP header. Replace `CurrentUserService` with your application's JWT/Spring Security integration.

### Supervisor lookup

The starter queries `workflow.employee_supervisor`. Replace `EmployeeHierarchyRepository` with your existing employee hierarchy query when available.

### Existing groups

The engine uses your existing tables:

- `dbo.NM_GROUP`
- `dbo.NM_GROUP_MEMBERS`

The script `dbscripts/00_existing_group_tables_for_local_demo.sql` creates them only when they do not already exist, so it can be used for a standalone local demo.

## Database setup

Run the scripts in `dbscripts` in numeric order:

1. `00_existing_group_tables_for_local_demo.sql`
2. `01_workflow_schema.sql`
3. `02_workflow_definition_tables.sql`
4. `03_workflow_runtime_tables.sql`
5. `04_indexes.sql`
6. `05_demo_identity_data.sql`

The application intentionally does not auto-create or auto-update database tables.

## Build and run

```bash
mvn clean test
mvn spring-boot:run
```

Or:

```bash
mvn clean package
java -jar target/raw-workflow-engine-0.0.1-SNAPSHOT.jar
```

Environment variables:

```text
DB_URL
DB_USERNAME
DB_PASSWORD
SERVER_PORT
```

## API overview

### Workflow definitions

```text
POST /api/workflows
PUT  /api/workflows/{workflowDefinitionId}/draft
GET  /api/workflows/{workflowDefinitionId}/draft
POST /api/workflows/{workflowDefinitionId}/validate
POST /api/workflows/{workflowDefinitionId}/publish
GET  /api/workflows/{workflowDefinitionId}/versions
```

### Runtime

```text
POST /api/workflow-instances
GET  /api/workflow-instances/{instanceId}
GET  /api/workflow-instances/{instanceId}/graph
GET  /api/workflow-instances/{instanceId}/audit
```

### Tasks

```text
GET  /api/workflow-tasks/my
POST /api/workflow-tasks/{taskId}/approve
POST /api/workflow-tasks/{taskId}/reject
POST /api/workflow-tasks/{taskId}/request-information
POST /api/workflow-tasks/{taskId}/submit-information
```

Sample requests are under `examples/`.

## Workflow editor data model

The React editor sends nodes by stable `stepKey`, not database UUID. The backend generates new UUIDs for every workflow version while preserving the stable keys. Published versions are immutable.

A `PARALLEL_SPLIT` step must identify its matching join with `parallelJoinStepKey`. A rejection path must lead to an `END` step whose `endStatus` is `REJECTED`.

Conditions use controlled JSON instead of JavaScript, SQL, SpEL, or arbitrary executable expressions:

```json
{
  "all": [
    {"field": "ytdTotal", "operator": "GT", "value": 300},
    {"field": "providerPoliticalPerson", "operator": "EQ", "value": false}
  ]
}
```

Supported operators:

```text
EQ, NE, GT, GTE, LT, LTE, IN, NOT_IN, IS_NULL, IS_NOT_NULL
```

## Production changes to make before adoption

- Replace `X-User-Id` with authenticated identity.
- Replace the sample supervisor table lookup.
- Add your business authorization rules for who may edit and publish workflows.
- Add your notification/email implementation as an application-level integration.
- Review indexes and retention for your expected transaction volume.
- Add database backup, observability, and operational retry policies.

# Curl examples

Create the workflow:

```bash
curl -X POST http://localhost:8080/api/workflows \
  -H "Content-Type: application/json" \
  -H "X-User-Id: ADMIN1" \
  --data @gift-workflow-create.json
```

Validate and publish it using the returned `workflowDefinitionId`:

```bash
curl -X POST http://localhost:8080/api/workflows/{workflowDefinitionId}/validate \
  -H "X-User-Id: ADMIN1"

curl -X POST http://localhost:8080/api/workflows/{workflowDefinitionId}/publish \
  -H "X-User-Id: ADMIN1"
```

Start a request:

```bash
curl -X POST http://localhost:8080/api/workflow-instances \
  -H "Content-Type: application/json" \
  -H "X-User-Id: EMPUSER1" \
  --data @start-gift-workflow.json
```

List Supervisor tasks:

```bash
curl http://localhost:8080/api/workflow-tasks/my \
  -H "X-User-Id: SUP001"
```

List Compliance tasks:

```bash
curl http://localhost:8080/api/workflow-tasks/my \
  -H "X-User-Id: COMP001"
```

CREATE INDEX IX_workflow_transition_source
    ON workflow.workflow_transition(source_step_id, sort_order);
GO

CREATE INDEX IX_workflow_transition_target
    ON workflow.workflow_transition(target_step_id);
GO

CREATE INDEX IX_workflow_step_version_type
    ON workflow.workflow_step(workflow_version_id, step_type);
GO

CREATE INDEX IX_workflow_instance_version_status
    ON workflow.workflow_instance(workflow_version_id, instance_status);
GO

CREATE INDEX IX_workflow_token_instance_status
    ON workflow.workflow_token(workflow_instance_id, token_status);
GO

CREATE INDEX IX_workflow_token_scope_status
    ON workflow.workflow_token(parallel_scope_id, token_status);
GO

CREATE INDEX IX_workflow_task_user
    ON workflow.workflow_task(assignee_user_id, task_status, created_at);
GO

CREATE INDEX IX_workflow_task_group
    ON workflow.workflow_task(candidate_group_id, task_status, created_at);
GO

CREATE INDEX IX_workflow_task_instance_status
    ON workflow.workflow_task(workflow_instance_id, task_status);
GO

CREATE INDEX IX_workflow_task_parent
    ON workflow.workflow_task(parent_task_id, information_round_number);
GO

CREATE INDEX IX_workflow_audit_instance
    ON workflow.workflow_audit_event(workflow_instance_id, audit_event_id);
GO

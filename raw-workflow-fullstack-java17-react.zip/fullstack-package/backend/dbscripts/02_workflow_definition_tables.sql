CREATE TABLE workflow.workflow_definition
(
    workflow_definition_id UNIQUEIDENTIFIER NOT NULL,
    workflow_key           VARCHAR(100) NOT NULL,
    workflow_name          VARCHAR(200) NOT NULL,
    description            VARCHAR(1000) NULL,
    active                 BIT NOT NULL CONSTRAINT DF_workflow_definition_active DEFAULT 1,
    created_by             VARCHAR(50) NOT NULL,
    created_at             DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_definition_created_at DEFAULT SYSUTCDATETIME(),
    updated_by             VARCHAR(50) NOT NULL,
    updated_at             DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_definition_updated_at DEFAULT SYSUTCDATETIME(),
    row_version            ROWVERSION NOT NULL,
    CONSTRAINT PK_workflow_definition PRIMARY KEY (workflow_definition_id),
    CONSTRAINT UQ_workflow_definition_key UNIQUE (workflow_key)
);
GO

CREATE TABLE workflow.workflow_version
(
    workflow_version_id    UNIQUEIDENTIFIER NOT NULL,
    workflow_definition_id UNIQUEIDENTIFIER NOT NULL,
    version_number         INT NOT NULL,
    version_status         VARCHAR(20) NOT NULL,
    layout_json            NVARCHAR(MAX) NULL,
    created_by             VARCHAR(50) NOT NULL,
    created_at             DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_version_created_at DEFAULT SYSUTCDATETIME(),
    published_by           VARCHAR(50) NULL,
    published_at           DATETIME2(3) NULL,
    row_version            ROWVERSION NOT NULL,
    CONSTRAINT PK_workflow_version PRIMARY KEY (workflow_version_id),
    CONSTRAINT FK_workflow_version_definition FOREIGN KEY (workflow_definition_id)
        REFERENCES workflow.workflow_definition(workflow_definition_id),
    CONSTRAINT UQ_workflow_version_number UNIQUE (workflow_definition_id, version_number),
    CONSTRAINT CK_workflow_version_status CHECK (version_status IN ('DRAFT', 'PUBLISHED', 'ARCHIVED')),
    CONSTRAINT CK_workflow_version_layout_json CHECK (layout_json IS NULL OR ISJSON(layout_json) = 1)
);
GO

CREATE UNIQUE INDEX UX_workflow_version_one_draft
    ON workflow.workflow_version(workflow_definition_id)
    WHERE version_status = 'DRAFT';
GO

CREATE TABLE workflow.workflow_lane
(
    workflow_lane_id    UNIQUEIDENTIFIER NOT NULL,
    workflow_version_id UNIQUEIDENTIFIER NOT NULL,
    lane_key            VARCHAR(100) NOT NULL,
    lane_name           VARCHAR(200) NOT NULL,
    sort_order          INT NOT NULL CONSTRAINT DF_workflow_lane_sort DEFAULT 0,
    CONSTRAINT PK_workflow_lane PRIMARY KEY (workflow_lane_id),
    CONSTRAINT FK_workflow_lane_version FOREIGN KEY (workflow_version_id)
        REFERENCES workflow.workflow_version(workflow_version_id),
    CONSTRAINT UQ_workflow_lane_key UNIQUE (workflow_version_id, lane_key)
);
GO

CREATE TABLE workflow.workflow_step
(
    workflow_step_id         UNIQUEIDENTIFIER NOT NULL,
    workflow_version_id      UNIQUEIDENTIFIER NOT NULL,
    step_key                 VARCHAR(100) NOT NULL,
    step_name                VARCHAR(200) NOT NULL,
    step_type                VARCHAR(30) NOT NULL,
    assignment_type          VARCHAR(30) NOT NULL CONSTRAINT DF_workflow_step_assignment DEFAULT 'NONE',
    assignment_group_id      VARCHAR(100) NULL,
    assignment_user_id       VARCHAR(50) NULL,
    allow_request_information BIT NOT NULL CONSTRAINT DF_workflow_step_request_info DEFAULT 0,
    parallel_join_step_key   VARCHAR(100) NULL,
    end_status               VARCHAR(20) NULL,
    configuration_json       NVARCHAR(MAX) NULL,
    display_x                DECIMAL(12,2) NULL,
    display_y                DECIMAL(12,2) NULL,
    display_width            DECIMAL(12,2) NULL,
    display_height           DECIMAL(12,2) NULL,
    lane_key                 VARCHAR(100) NULL,
    sort_order               INT NOT NULL CONSTRAINT DF_workflow_step_sort DEFAULT 0,
    CONSTRAINT PK_workflow_step PRIMARY KEY (workflow_step_id),
    CONSTRAINT FK_workflow_step_version FOREIGN KEY (workflow_version_id)
        REFERENCES workflow.workflow_version(workflow_version_id),
    CONSTRAINT FK_workflow_step_group FOREIGN KEY (assignment_group_id)
        REFERENCES dbo.NM_GROUP(GROUP_ID),
    CONSTRAINT FK_workflow_step_lane FOREIGN KEY (workflow_version_id, lane_key)
        REFERENCES workflow.workflow_lane(workflow_version_id, lane_key),
    CONSTRAINT UQ_workflow_step_key UNIQUE (workflow_version_id, step_key),
    CONSTRAINT CK_workflow_step_type CHECK (step_type IN
        ('START','END','APPROVAL','DECISION','PARALLEL_SPLIT','PARALLEL_JOIN','AUTOMATIC_ACTION')),
    CONSTRAINT CK_workflow_step_assignment_type CHECK (assignment_type IN
        ('NONE','REQUESTER','REQUESTER_SUPERVISOR','GROUP','SPECIFIC_USER')),
    CONSTRAINT CK_workflow_step_end_status CHECK (end_status IS NULL OR end_status IN
        ('APPROVED','REJECTED','COMPLETED','CANCELLED')),
    CONSTRAINT CK_workflow_step_configuration_json CHECK
        (configuration_json IS NULL OR ISJSON(configuration_json) = 1),
    CONSTRAINT CK_workflow_step_assignment_values CHECK
    (
        (assignment_type = 'GROUP' AND assignment_group_id IS NOT NULL AND assignment_user_id IS NULL)
        OR
        (assignment_type = 'SPECIFIC_USER' AND assignment_user_id IS NOT NULL AND assignment_group_id IS NULL)
        OR
        (assignment_type IN ('NONE','REQUESTER','REQUESTER_SUPERVISOR')
            AND assignment_group_id IS NULL AND assignment_user_id IS NULL)
    )
);
GO

CREATE TABLE workflow.workflow_transition
(
    workflow_transition_id UNIQUEIDENTIFIER NOT NULL,
    workflow_version_id    UNIQUEIDENTIFIER NOT NULL,
    transition_key         VARCHAR(100) NOT NULL,
    transition_name        VARCHAR(200) NULL,
    source_step_id         UNIQUEIDENTIFIER NOT NULL,
    target_step_id         UNIQUEIDENTIFIER NOT NULL,
    transition_type        VARCHAR(30) NOT NULL CONSTRAINT DF_workflow_transition_type DEFAULT 'DEFAULT',
    condition_json         NVARCHAR(MAX) NULL,
    branch_key             VARCHAR(100) NULL,
    sort_order             INT NOT NULL CONSTRAINT DF_workflow_transition_sort DEFAULT 0,
    CONSTRAINT PK_workflow_transition PRIMARY KEY (workflow_transition_id),
    CONSTRAINT FK_workflow_transition_version FOREIGN KEY (workflow_version_id)
        REFERENCES workflow.workflow_version(workflow_version_id),
    CONSTRAINT FK_workflow_transition_source FOREIGN KEY (source_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT FK_workflow_transition_target FOREIGN KEY (target_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT UQ_workflow_transition_key UNIQUE (workflow_version_id, transition_key),
    CONSTRAINT CK_workflow_transition_type CHECK (transition_type IN
        ('DEFAULT','CONDITIONAL','APPROVE','REJECT')),
    CONSTRAINT CK_workflow_transition_condition_json CHECK
        (condition_json IS NULL OR ISJSON(condition_json) = 1)
);
GO

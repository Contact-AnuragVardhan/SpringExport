IF NOT EXISTS (SELECT 1 FROM dbo.NM_GROUP WHERE GROUP_ID = 'COMPLIANCE')
BEGIN
    INSERT INTO dbo.NM_GROUP
    (
        GROUP_ID, GROUP_NAME, GROUP_EMAIL_ADDRESS,
        CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE
    )
    VALUES
    (
        'COMPLIANCE', 'Compliance', 'compliance@example.com',
        'SYSTEM', GETDATE(), 'SYSTEM', GETDATE()
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1 FROM dbo.NM_GROUP_MEMBERS
    WHERE GROUP_ID = 'COMPLIANCE' AND USER_ID = 'COMP001'
)
BEGIN
    INSERT INTO dbo.NM_GROUP_MEMBERS
    (
        GROUP_ID, USER_ID, CREATED_BY, CREATED_DATE,
        UPDATED_BY, UPDATED_DATE, IS_ACTIVE, COMMENTS
    )
    VALUES
    (
        'COMPLIANCE', 'COMP001', 'SYSTEM', GETDATE(),
        'SYSTEM', GETDATE(), 1, 'Local demo member'
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM workflow.employee_supervisor WHERE employee_id = 'EMP001')
BEGIN
    INSERT INTO workflow.employee_supervisor
    (
        employee_id, employee_user_id, supervisor_user_id, active
    )
    VALUES
    (
        'EMP001', 'EMPUSER1', 'SUP001', 1
    );
END;
GO

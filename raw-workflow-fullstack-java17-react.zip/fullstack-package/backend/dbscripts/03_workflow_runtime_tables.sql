/*
  Replace this sample hierarchy table/repository with the application's existing employee hierarchy.
*/
CREATE TABLE workflow.employee_supervisor
(
    employee_id       VARCHAR(50) NOT NULL,
    employee_user_id  VARCHAR(50) NOT NULL,
    supervisor_user_id VARCHAR(50) NOT NULL,
    active            BIT NOT NULL CONSTRAINT DF_employee_supervisor_active DEFAULT 1,
    updated_at        DATETIME2(3) NOT NULL CONSTRAINT DF_employee_supervisor_updated DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_employee_supervisor PRIMARY KEY (employee_id)
);
GO

CREATE TABLE workflow.workflow_instance
(
    workflow_instance_id UNIQUEIDENTIFIER NOT NULL,
    workflow_version_id  UNIQUEIDENTIFIER NOT NULL,
    business_type        VARCHAR(100) NOT NULL,
    business_id          VARCHAR(100) NOT NULL,
    requester_user_id    VARCHAR(50) NOT NULL,
    requester_employee_id VARCHAR(50) NULL,
    instance_status      VARCHAR(30) NOT NULL,
    started_by           VARCHAR(50) NOT NULL,
    started_at           DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_instance_started DEFAULT SYSUTCDATETIME(),
    completed_at         DATETIME2(3) NULL,
    row_version          ROWVERSION NOT NULL,
    CONSTRAINT PK_workflow_instance PRIMARY KEY (workflow_instance_id),
    CONSTRAINT FK_workflow_instance_version FOREIGN KEY (workflow_version_id)
        REFERENCES workflow.workflow_version(workflow_version_id),
    CONSTRAINT UQ_workflow_instance_business UNIQUE (business_type, business_id),
    CONSTRAINT CK_workflow_instance_status CHECK (instance_status IN
        ('RUNNING','APPROVED','REJECTED','COMPLETED','CANCELLED','FAILED'))
);
GO

CREATE TABLE workflow.workflow_variable
(
    workflow_instance_id UNIQUEIDENTIFIER NOT NULL,
    variable_name        VARCHAR(100) NOT NULL,
    variable_type        VARCHAR(20) NOT NULL,
    string_value         NVARCHAR(MAX) NULL,
    number_value         DECIMAL(38,10) NULL,
    date_value           DATETIME2(3) NULL,
    boolean_value        BIT NULL,
    json_value           NVARCHAR(MAX) NULL,
    updated_at           DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_variable_updated DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_workflow_variable PRIMARY KEY (workflow_instance_id, variable_name),
    CONSTRAINT FK_workflow_variable_instance FOREIGN KEY (workflow_instance_id)
        REFERENCES workflow.workflow_instance(workflow_instance_id),
    CONSTRAINT CK_workflow_variable_type CHECK (variable_type IN
        ('STRING','NUMBER','DATE','BOOLEAN','JSON','NULL')),
    CONSTRAINT CK_workflow_variable_json CHECK (json_value IS NULL OR ISJSON(json_value) = 1)
);
GO

CREATE TABLE workflow.parallel_scope
(
    parallel_scope_id       UNIQUEIDENTIFIER NOT NULL,
    workflow_instance_id    UNIQUEIDENTIFIER NOT NULL,
    split_step_id           UNIQUEIDENTIFIER NOT NULL,
    join_step_id            UNIQUEIDENTIFIER NOT NULL,
    parent_parallel_scope_id UNIQUEIDENTIFIER NULL,
    parent_branch_key       VARCHAR(100) NULL,
    expected_branch_count   INT NOT NULL,
    arrived_branch_count    INT NOT NULL CONSTRAINT DF_parallel_scope_arrived DEFAULT 0,
    scope_status            VARCHAR(20) NOT NULL CONSTRAINT DF_parallel_scope_status DEFAULT 'OPEN',
    created_at              DATETIME2(3) NOT NULL CONSTRAINT DF_parallel_scope_created DEFAULT SYSUTCDATETIME(),
    completed_at            DATETIME2(3) NULL,
    row_version             ROWVERSION NOT NULL,
    CONSTRAINT PK_parallel_scope PRIMARY KEY (parallel_scope_id),
    CONSTRAINT FK_parallel_scope_instance FOREIGN KEY (workflow_instance_id)
        REFERENCES workflow.workflow_instance(workflow_instance_id),
    CONSTRAINT FK_parallel_scope_split FOREIGN KEY (split_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT FK_parallel_scope_join FOREIGN KEY (join_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT FK_parallel_scope_parent FOREIGN KEY (parent_parallel_scope_id)
        REFERENCES workflow.parallel_scope(parallel_scope_id),
    CONSTRAINT CK_parallel_scope_status CHECK (scope_status IN ('OPEN','COMPLETED','CANCELLED')),
    CONSTRAINT CK_parallel_scope_expected CHECK (expected_branch_count > 1),
    CONSTRAINT CK_parallel_scope_arrived CHECK (arrived_branch_count >= 0)
);
GO

CREATE TABLE workflow.workflow_token
(
    workflow_token_id    UNIQUEIDENTIFIER NOT NULL,
    workflow_instance_id UNIQUEIDENTIFIER NOT NULL,
    current_step_id      UNIQUEIDENTIFIER NOT NULL,
    token_status         VARCHAR(30) NOT NULL,
    parent_token_id      UNIQUEIDENTIFIER NULL,
    parallel_scope_id    UNIQUEIDENTIFIER NULL,
    branch_key           VARCHAR(100) NULL,
    created_at           DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_token_created DEFAULT SYSUTCDATETIME(),
    completed_at         DATETIME2(3) NULL,
    row_version          ROWVERSION NOT NULL,
    CONSTRAINT PK_workflow_token PRIMARY KEY (workflow_token_id),
    CONSTRAINT FK_workflow_token_instance FOREIGN KEY (workflow_instance_id)
        REFERENCES workflow.workflow_instance(workflow_instance_id),
    CONSTRAINT FK_workflow_token_step FOREIGN KEY (current_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT FK_workflow_token_parent FOREIGN KEY (parent_token_id)
        REFERENCES workflow.workflow_token(workflow_token_id),
    CONSTRAINT FK_workflow_token_scope FOREIGN KEY (parallel_scope_id)
        REFERENCES workflow.parallel_scope(parallel_scope_id),
    CONSTRAINT CK_workflow_token_status CHECK (token_status IN
        ('ACTIVE','WAITING_FOR_TASK','WAITING_AT_JOIN','COMPLETED','CANCELLED','FAILED'))
);
GO

CREATE TABLE workflow.workflow_task
(
    workflow_task_id       UNIQUEIDENTIFIER NOT NULL,
    workflow_instance_id   UNIQUEIDENTIFIER NOT NULL,
    workflow_token_id      UNIQUEIDENTIFIER NOT NULL,
    workflow_step_id       UNIQUEIDENTIFIER NOT NULL,
    parent_task_id         UNIQUEIDENTIFIER NULL,
    task_type              VARCHAR(30) NOT NULL,
    task_status            VARCHAR(30) NOT NULL,
    assignee_user_id       VARCHAR(50) NULL,
    candidate_group_id     VARCHAR(100) NULL,
    information_round_number INT NULL,
    outcome                VARCHAR(30) NULL,
    task_payload_json      NVARCHAR(MAX) NULL,
    created_at             DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_task_created DEFAULT SYSUTCDATETIME(),
    completed_by_user_id   VARCHAR(50) NULL,
    completed_at           DATETIME2(3) NULL,
    row_version            ROWVERSION NOT NULL,
    CONSTRAINT PK_workflow_task PRIMARY KEY (workflow_task_id),
    CONSTRAINT FK_workflow_task_instance FOREIGN KEY (workflow_instance_id)
        REFERENCES workflow.workflow_instance(workflow_instance_id),
    CONSTRAINT FK_workflow_task_token FOREIGN KEY (workflow_token_id)
        REFERENCES workflow.workflow_token(workflow_token_id),
    CONSTRAINT FK_workflow_task_step FOREIGN KEY (workflow_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT FK_workflow_task_parent FOREIGN KEY (parent_task_id)
        REFERENCES workflow.workflow_task(workflow_task_id),
    CONSTRAINT FK_workflow_task_group FOREIGN KEY (candidate_group_id)
        REFERENCES dbo.NM_GROUP(GROUP_ID),
    CONSTRAINT CK_workflow_task_type CHECK (task_type IN ('APPROVAL','EMPLOYEE_INFORMATION')),
    CONSTRAINT CK_workflow_task_status CHECK (task_status IN
        ('OPEN','WAITING_FOR_INFORMATION','COMPLETED','CANCELLED')),
    CONSTRAINT CK_workflow_task_outcome CHECK (outcome IS NULL OR outcome IN
        ('APPROVED','REJECTED','INFORMATION_REQUESTED','INFORMATION_SUBMITTED','CANCELLED')),
    CONSTRAINT CK_workflow_task_payload_json CHECK (task_payload_json IS NULL OR ISJSON(task_payload_json) = 1),
    CONSTRAINT CK_workflow_task_assignment CHECK
    (
        (assignee_user_id IS NOT NULL AND candidate_group_id IS NULL)
        OR
        (assignee_user_id IS NULL AND candidate_group_id IS NOT NULL)
    )
);
GO

CREATE TABLE workflow.workflow_audit_event
(
    audit_event_id          BIGINT IDENTITY(1,1) NOT NULL,
    workflow_instance_id    UNIQUEIDENTIFIER NOT NULL,
    workflow_token_id       UNIQUEIDENTIFIER NULL,
    workflow_task_id        UNIQUEIDENTIFIER NULL,
    from_step_id            UNIQUEIDENTIFIER NULL,
    to_step_id              UNIQUEIDENTIFIER NULL,
    event_type              VARCHAR(50) NOT NULL,
    outcome                 VARCHAR(30) NULL,
    performed_by_user_id    VARCHAR(50) NULL,
    performed_for_group_id  VARCHAR(100) NULL,
    comments                NVARCHAR(MAX) NULL,
    event_data_json         NVARCHAR(MAX) NULL,
    created_at              DATETIME2(3) NOT NULL CONSTRAINT DF_workflow_audit_created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_workflow_audit_event PRIMARY KEY (audit_event_id),
    CONSTRAINT FK_workflow_audit_instance FOREIGN KEY (workflow_instance_id)
        REFERENCES workflow.workflow_instance(workflow_instance_id),
    CONSTRAINT FK_workflow_audit_token FOREIGN KEY (workflow_token_id)
        REFERENCES workflow.workflow_token(workflow_token_id),
    CONSTRAINT FK_workflow_audit_task FOREIGN KEY (workflow_task_id)
        REFERENCES workflow.workflow_task(workflow_task_id),
    CONSTRAINT FK_workflow_audit_from_step FOREIGN KEY (from_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT FK_workflow_audit_to_step FOREIGN KEY (to_step_id)
        REFERENCES workflow.workflow_step(workflow_step_id),
    CONSTRAINT FK_workflow_audit_group FOREIGN KEY (performed_for_group_id)
        REFERENCES dbo.NM_GROUP(GROUP_ID),
    CONSTRAINT CK_workflow_audit_json CHECK (event_data_json IS NULL OR ISJSON(event_data_json) = 1)
);
GO

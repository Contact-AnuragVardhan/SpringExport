import type { ApiErrorBody } from '../types/workflow'

const configuredBaseUrl = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim()
export const API_BASE_URL = configuredBaseUrl ? configuredBaseUrl.replace(/\/$/, '') : ''

export class ApiError extends Error {
  readonly status: number
  readonly body?: ApiErrorBody

  constructor(message: string, status: number, body?: ApiErrorBody) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.body = body
  }
}

export interface RequestOptions extends Omit<RequestInit, 'body'> {
  userId?: string
  body?: unknown
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers = new Headers(options.headers)
  headers.set('Accept', 'application/json')

  if (options.userId?.trim()) {
    headers.set('X-User-Id', options.userId.trim())
  }

  let body: BodyInit | undefined
  if (options.body !== undefined) {
    headers.set('Content-Type', 'application/json')
    body = JSON.stringify(options.body)
  }

  let response: Response
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers,
      body,
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to reach the workflow API'
    throw new ApiError(message, 0)
  }

  if (!response.ok) {
    let errorBody: ApiErrorBody | undefined
    try {
      errorBody = (await response.json()) as ApiErrorBody
    } catch {
      errorBody = undefined
    }

    const message =
      errorBody?.message ||
      errorBody?.error ||
      `Request failed with HTTP ${response.status}`

    throw new ApiError(message, response.status, errorBody)
  }

  if (response.status === 204) {
    return undefined as T
  }

  const contentType = response.headers.get('content-type') ?? ''
  if (!contentType.includes('application/json')) {
    return (await response.text()) as T
  }

  return (await response.json()) as T
}

export function getErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    const details = error.body?.details
    if (details && details.length > 0) {
      return `${error.message}: ${details.join('; ')}`
    }
    return error.message
  }

  return error instanceof Error ? error.message : 'Unexpected error'
}

import { apiRequest } from './http'
import type {
  AuditEvent,
  CreateWorkflowPayload,
  InformationTaskCreatedResponse,
  RuntimeGraphResponse,
  StartWorkflowPayload,
  ValidationResponse,
  WorkflowCreatedResponse,
  WorkflowDraftPayload,
  WorkflowGraphResponse,
  WorkflowInstance,
  WorkflowPublishedResponse,
  WorkflowStartedResponse,
  WorkflowTask,
  WorkflowVersion,
} from '../types/workflow'

export const workflowApi = {
  createWorkflow(payload: CreateWorkflowPayload, userId: string) {
    return apiRequest<WorkflowCreatedResponse>('/api/workflows', {
      method: 'POST',
      userId,
      body: payload,
    })
  },

  getDraft(workflowDefinitionId: string) {
    return apiRequest<WorkflowGraphResponse>(
      `/api/workflows/${encodeURIComponent(workflowDefinitionId)}/draft`,
    )
  },

  saveDraft(workflowDefinitionId: string, payload: WorkflowDraftPayload, userId: string) {
    return apiRequest<WorkflowGraphResponse>(
      `/api/workflows/${encodeURIComponent(workflowDefinitionId)}/draft`,
      {
        method: 'PUT',
        userId,
        body: payload,
      },
    )
  },

  validateDraft(workflowDefinitionId: string) {
    return apiRequest<ValidationResponse>(
      `/api/workflows/${encodeURIComponent(workflowDefinitionId)}/validate`,
      { method: 'POST' },
    )
  },

  publishWorkflow(workflowDefinitionId: string, userId: string) {
    return apiRequest<WorkflowPublishedResponse>(
      `/api/workflows/${encodeURIComponent(workflowDefinitionId)}/publish`,
      {
        method: 'POST',
        userId,
      },
    )
  },

  getVersions(workflowDefinitionId: string) {
    return apiRequest<WorkflowVersion[]>(
      `/api/workflows/${encodeURIComponent(workflowDefinitionId)}/versions`,
    )
  },

  startWorkflow(payload: StartWorkflowPayload, userId: string) {
    return apiRequest<WorkflowStartedResponse>('/api/workflow-instances', {
      method: 'POST',
      userId,
      body: payload,
    })
  },

  getInstance(instanceId: string) {
    return apiRequest<WorkflowInstance>(
      `/api/workflow-instances/${encodeURIComponent(instanceId)}`,
    )
  },

  getRuntimeGraph(instanceId: string) {
    return apiRequest<RuntimeGraphResponse>(
      `/api/workflow-instances/${encodeURIComponent(instanceId)}/graph`,
    )
  },

  getAudit(instanceId: string) {
    return apiRequest<AuditEvent[]>(
      `/api/workflow-instances/${encodeURIComponent(instanceId)}/audit`,
    )
  },

  getMyTasks(userId: string) {
    return apiRequest<WorkflowTask[]>('/api/workflow-tasks/my', { userId })
  },

  approveTask(taskId: string, userId: string, comments?: string) {
    return apiRequest<void>(`/api/workflow-tasks/${encodeURIComponent(taskId)}/approve`, {
      method: 'POST',
      userId,
      body: { comments: comments || null },
    })
  },

  rejectTask(taskId: string, userId: string, comments: string) {
    return apiRequest<void>(`/api/workflow-tasks/${encodeURIComponent(taskId)}/reject`, {
      method: 'POST',
      userId,
      body: { comments },
    })
  },

  requestInformation(taskId: string, userId: string, comments: string) {
    return apiRequest<InformationTaskCreatedResponse>(
      `/api/workflow-tasks/${encodeURIComponent(taskId)}/request-information`,
      {
        method: 'POST',
        userId,
        body: { comments },
      },
    )
  },

  submitInformation(
    taskId: string,
    userId: string,
    comments: string,
    updatedRequestValues: Record<string, unknown>,
  ) {
    return apiRequest<void>(
      `/api/workflow-tasks/${encodeURIComponent(taskId)}/submit-information`,
      {
        method: 'POST',
        userId,
        body: { comments, updatedRequestValues },
      },
    )
  },
}

import { useMemo, useRef, useState } from 'react'
import type {
  LaneInput,
  RuntimeStepStatus,
  StepInput,
  TransitionInput,
} from '../types/workflow'

interface WorkflowCanvasProps {
  lanes: LaneInput[]
  steps: StepInput[]
  transitions: TransitionInput[]
  editable?: boolean
  selectedStepKey?: string | null
  selectedTransitionKey?: string | null
  runtimeStatuses?: Record<string, RuntimeStepStatus>
  activeTaskIdsByStepKey?: Record<string, string[]>
  onSelectStep?: (stepKey: string) => void
  onSelectTransition?: (transitionKey: string) => void
  onMoveStep?: (stepKey: string, x: number, y: number) => void
}

interface Point {
  x: number
  y: number
}

const DEFAULT_WIDTH = 160
const DEFAULT_HEIGHT = 72
const DIAMOND_SIZE = 94

function getDimensions(step: StepInput) {
  const diamond = ['DECISION', 'PARALLEL_SPLIT', 'PARALLEL_JOIN'].includes(step.stepType)
  return {
    width: step.displayWidth ?? (diamond ? DIAMOND_SIZE : DEFAULT_WIDTH),
    height: step.displayHeight ?? (diamond ? DIAMOND_SIZE : DEFAULT_HEIGHT),
  }
}

function getPosition(step: StepInput, index: number) {
  return {
    x: step.displayX ?? 80 + (index % 5) * 220,
    y: step.displayY ?? 80 + Math.floor(index / 5) * 150,
  }
}

function wrapLabel(label: string, maxChars = 22): string[] {
  const words = label.split(/\s+/).filter(Boolean)
  const lines: string[] = []
  let line = ''
  for (const word of words) {
    const next = line ? `${line} ${word}` : word
    if (next.length > maxChars && line) {
      lines.push(line)
      line = word
    } else {
      line = next
    }
  }
  if (line) lines.push(line)
  return lines.slice(0, 4)
}

function statusClass(status?: RuntimeStepStatus) {
  return status ? ` runtime-${status.toLowerCase().replaceAll('_', '-')}` : ''
}

function transitionLabel(transition: TransitionInput) {
  if (transition.transitionName) return transition.transitionName
  if (transition.transitionType === 'APPROVE') return 'Approve'
  if (transition.transitionType === 'REJECT') return 'Reject'
  if (transition.transitionType === 'CONDITIONAL') return 'Condition'
  return transition.branchKey || ''
}

export function WorkflowCanvas({
  lanes,
  steps,
  transitions,
  editable = false,
  selectedStepKey,
  selectedTransitionKey,
  runtimeStatuses = {},
  activeTaskIdsByStepKey = {},
  onSelectStep,
  onSelectTransition,
  onMoveStep,
}: WorkflowCanvasProps) {
  const svgRef = useRef<SVGSVGElement | null>(null)
  const [dragging, setDragging] = useState<{ stepKey: string; offsetX: number; offsetY: number } | null>(
    null,
  )
  const [zoom, setZoom] = useState(1)

  const positionedSteps = useMemo(
    () =>
      steps.map((step, index) => ({
        step,
        ...getPosition(step, index),
        ...getDimensions(step),
      })),
    [steps],
  )

  const stepMap = useMemo(
    () => new Map(positionedSteps.map((item) => [item.step.stepKey, item])),
    [positionedSteps],
  )

  const contentSize = useMemo(() => {
    const width = Math.max(
      1250,
      ...positionedSteps.map((item) => item.x + item.width + 180),
    )
    const height = Math.max(
      620,
      ...positionedSteps.map((item) => item.y + item.height + 140),
      lanes.length * 170 + 80,
    )
    return { width, height }
  }, [positionedSteps, lanes.length])

  const sortedLanes = useMemo(
    () => [...lanes].sort((a, b) => a.sortOrder - b.sortOrder),
    [lanes],
  )

  function toSvgPoint(clientX: number, clientY: number): Point {
    const svg = svgRef.current
    if (!svg) return { x: clientX, y: clientY }
    const point = svg.createSVGPoint()
    point.x = clientX
    point.y = clientY
    const matrix = svg.getScreenCTM()
    return matrix ? point.matrixTransform(matrix.inverse()) : { x: clientX, y: clientY }
  }

  function handlePointerDown(event: React.PointerEvent, step: StepInput, x: number, y: number) {
    onSelectStep?.(step.stepKey)
    if (!editable || !onMoveStep) return
    event.currentTarget.setPointerCapture(event.pointerId)
    const point = toSvgPoint(event.clientX, event.clientY)
    setDragging({ stepKey: step.stepKey, offsetX: point.x - x, offsetY: point.y - y })
  }

  function handlePointerMove(event: React.PointerEvent<SVGSVGElement>) {
    if (!dragging || !editable || !onMoveStep) return
    const point = toSvgPoint(event.clientX, event.clientY)
    onMoveStep(
      dragging.stepKey,
      Math.max(20, Math.round(point.x - dragging.offsetX)),
      Math.max(20, Math.round(point.y - dragging.offsetY)),
    )
  }

  function handlePointerUp() {
    setDragging(null)
  }

  return (
    <section className="workflow-canvas-shell">
      <div className="canvas-toolbar">
        <span>{steps.length} steps · {transitions.length} transitions</span>
        <div className="zoom-controls">
          <button type="button" onClick={() => setZoom((value) => Math.max(0.55, value - 0.1))}>−</button>
          <span>{Math.round(zoom * 100)}%</span>
          <button type="button" onClick={() => setZoom((value) => Math.min(1.6, value + 0.1))}>+</button>
          <button type="button" onClick={() => setZoom(1)}>Reset</button>
        </div>
      </div>
      <div className="workflow-canvas-scroll">
        <svg
          ref={svgRef}
          className="workflow-canvas"
          width={contentSize.width * zoom}
          height={contentSize.height * zoom}
          viewBox={`0 0 ${contentSize.width} ${contentSize.height}`}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onClick={() => {
            onSelectStep?.('')
            onSelectTransition?.('')
          }}
        >
          <defs>
            <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
              <path d="M 24 0 L 0 0 0 24" fill="none" className="grid-line" strokeWidth="1" />
            </pattern>
            <marker id="arrow-default" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" className="arrow-default" />
            </marker>
            <marker id="arrow-reject" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" className="arrow-reject" />
            </marker>
          </defs>

          <rect width="100%" height="100%" className="canvas-bg" />
          <rect width="100%" height="100%" fill="url(#grid)" />

          {sortedLanes.map((lane, index) => {
            const y = 28 + index * 170
            return (
              <g key={lane.laneKey} className="lane-band">
                <rect x="18" y={y} width={contentSize.width - 36} height="150" rx="12" />
                <text x="34" y={y + 28}>{lane.laneName}</text>
              </g>
            )
          })}

          <g className="transition-layer">
            {transitions.map((transition) => {
              const source = stepMap.get(transition.sourceStepKey)
              const target = stepMap.get(transition.targetStepKey)
              if (!source || !target) return null

              const startX = source.x + source.width
              const startY = source.y + source.height / 2
              const endX = target.x
              const endY = target.y + target.height / 2
              const distance = Math.max(60, Math.abs(endX - startX) * 0.45)
              const control1X = startX + (endX >= startX ? distance : 70)
              const control2X = endX - (endX >= startX ? distance : 70)
              const path = `M ${startX} ${startY} C ${control1X} ${startY}, ${control2X} ${endY}, ${endX} ${endY}`
              const label = transitionLabel(transition)
              const labelX = (startX + endX) / 2
              const labelY = (startY + endY) / 2 - 9
              const selected = selectedTransitionKey === transition.transitionKey
              const reject = transition.transitionType === 'REJECT'

              return (
                <g
                  key={transition.transitionKey}
                  className={`transition ${selected ? 'selected' : ''} ${reject ? 'reject' : ''}`}
                  onClick={(event) => {
                    event.stopPropagation()
                    onSelectTransition?.(transition.transitionKey)
                  }}
                >
                  <path
                    d={path}
                    markerEnd={reject ? 'url(#arrow-reject)' : 'url(#arrow-default)'}
                  />
                  {label && (
                    <g className="transition-label">
                      <rect x={labelX - 42} y={labelY - 13} width="84" height="22" rx="8" />
                      <text x={labelX} y={labelY + 2}>{label}</text>
                    </g>
                  )}
                </g>
              )
            })}
          </g>

          <g className="node-layer">
            {positionedSteps.map(({ step, x, y, width, height }) => {
              const isDiamond = ['DECISION', 'PARALLEL_SPLIT', 'PARALLEL_JOIN'].includes(step.stepType)
              const lines = wrapLabel(step.stepName, isDiamond ? 15 : 22)
              const selected = selectedStepKey === step.stepKey
              const runtimeStatus = runtimeStatuses[step.stepKey]
              const taskCount = activeTaskIdsByStepKey[step.stepKey]?.length ?? 0

              return (
                <g
                  key={step.stepKey}
                  className={`workflow-node node-${step.stepType.toLowerCase()} ${selected ? 'selected' : ''}${statusClass(runtimeStatus)}`}
                  transform={`translate(${x}, ${y})`}
                  onPointerDown={(event) => handlePointerDown(event, step, x, y)}
                  onClick={(event) => {
                    event.stopPropagation()
                    onSelectStep?.(step.stepKey)
                  }}
                  style={{ cursor: editable ? (dragging?.stepKey === step.stepKey ? 'grabbing' : 'grab') : 'pointer' }}
                >
                  {isDiamond ? (
                    <polygon points={`${width / 2},0 ${width},${height / 2} ${width / 2},${height} 0,${height / 2}`} />
                  ) : (
                    <rect width={width} height={height} rx={step.stepType === 'START' || step.stepType === 'END' ? height / 2 : 12} />
                  )}
                  <text x={width / 2} y={height / 2 - ((lines.length - 1) * 8)} textAnchor="middle">
                    {lines.map((line, lineIndex) => (
                      <tspan key={`${line}-${lineIndex}`} x={width / 2} dy={lineIndex === 0 ? 0 : 17}>
                        {line}
                      </tspan>
                    ))}
                  </text>
                  <text className="node-type-label" x={width / 2} y={height + 18} textAnchor="middle">
                    {step.stepType.replaceAll('_', ' ')}
                  </text>
                  {runtimeStatus && (
                    <g className="runtime-pill" transform={`translate(${Math.max(6, width - 74)}, -13)`}>
                      <rect width="70" height="23" rx="11" />
                      <text x="35" y="15" textAnchor="middle">{runtimeStatus.replaceAll('_', ' ')}</text>
                    </g>
                  )}
                  {taskCount > 0 && (
                    <g className="task-count" transform={`translate(${width - 11}, ${height - 11})`}>
                      <circle r="13" />
                      <text y="4" textAnchor="middle">{taskCount}</text>
                    </g>
                  )}
                </g>
              )
            })}
          </g>
        </svg>
      </div>
      <div className="canvas-legend">
        <span><i className="legend-dot active" />Active</span>
        <span><i className="legend-dot waiting" />Waiting for information</span>
        <span><i className="legend-dot completed" />Completed</span>
        <span><i className="legend-dot cancelled" />Cancelled</span>
      </div>
    </section>
  )
}

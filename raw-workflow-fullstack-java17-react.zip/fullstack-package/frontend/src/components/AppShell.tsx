import type { ReactNode } from 'react'

export type PageKey = 'designer' | 'start' | 'tasks' | 'instance'

interface AppShellProps {
  page: PageKey
  onPageChange: (page: PageKey) => void
  userId: string
  onUserIdChange: (value: string) => void
  children: ReactNode
}

const navigation: Array<{ key: PageKey; label: string; short: string }> = [
  { key: 'designer', label: 'Workflow Designer', short: 'Designer' },
  { key: 'start', label: 'Start Request', short: 'Start' },
  { key: 'tasks', label: 'My Tasks', short: 'Tasks' },
  { key: 'instance', label: 'Instance Viewer', short: 'Instance' },
]

export function AppShell({
  page,
  onPageChange,
  userId,
  onUserIdChange,
  children,
}: AppShellProps) {
  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" type="button" onClick={() => onPageChange('designer')}>
          <span className="brand-mark">WF</span>
          <span>
            <strong>Raw Workflow</strong>
            <small>React administration UI</small>
          </span>
        </button>

        <nav className="main-nav" aria-label="Main navigation">
          {navigation.map((item) => (
            <button
              key={item.key}
              type="button"
              className={page === item.key ? 'nav-item active' : 'nav-item'}
              onClick={() => onPageChange(item.key)}
            >
              <span className="nav-full">{item.label}</span>
              <span className="nav-short">{item.short}</span>
            </button>
          ))}
        </nav>

        <label className="user-switcher">
          <span>Acting user</span>
          <input
            value={userId}
            onChange={(event) => onUserIdChange(event.target.value)}
            placeholder="EMPUSER1"
            spellCheck={false}
          />
        </label>
      </header>
      <main className="page-container">{children}</main>
    </div>
  )
}

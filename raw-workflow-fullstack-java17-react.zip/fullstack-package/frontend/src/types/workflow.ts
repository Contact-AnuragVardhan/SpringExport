export type WorkflowVersionStatus = 'DRAFT' | 'PUBLISHED' | 'ARCHIVED'

export type StepType =
  | 'START'
  | 'END'
  | 'APPROVAL'
  | 'DECISION'
  | 'PARALLEL_SPLIT'
  | 'PARALLEL_JOIN'
  | 'AUTOMATIC_ACTION'

export type AssignmentType =
  | 'NONE'
  | 'REQUESTER'
  | 'REQUESTER_SUPERVISOR'
  | 'GROUP'
  | 'SPECIFIC_USER'

export type TransitionType = 'DEFAULT' | 'CONDITIONAL' | 'APPROVE' | 'REJECT'
export type EndStatus = 'APPROVED' | 'REJECTED' | 'CANCELLED' | 'COMPLETED'
export type InstanceStatus = 'RUNNING' | 'APPROVED' | 'REJECTED' | 'COMPLETED' | 'CANCELLED' | 'FAILED'
export type TaskType = 'APPROVAL' | 'EMPLOYEE_INFORMATION'
export type TaskStatus = 'OPEN' | 'WAITING_FOR_INFORMATION' | 'COMPLETED' | 'CANCELLED'
export type TaskOutcome =
  | 'APPROVED'
  | 'REJECTED'
  | 'INFORMATION_REQUESTED'
  | 'INFORMATION_SUBMITTED'
  | 'CANCELLED'

export interface LaneInput {
  laneKey: string
  laneName: string
  sortOrder: number
}

export interface StepInput {
  stepKey: string
  stepName: string
  stepType: StepType
  assignmentType: AssignmentType
  assignmentGroupId?: string | null
  assignmentUserId?: string | null
  allowRequestInformation?: boolean
  parallelJoinStepKey?: string | null
  endStatus?: EndStatus | null
  configuration?: Record<string, unknown> | null
  displayX?: number | null
  displayY?: number | null
  displayWidth?: number | null
  displayHeight?: number | null
  laneKey?: string | null
  sortOrder?: number
}

export interface TransitionInput {
  transitionKey: string
  transitionName?: string | null
  sourceStepKey: string
  targetStepKey: string
  transitionType: TransitionType
  condition?: Record<string, unknown> | null
  branchKey?: string | null
  sortOrder?: number
}

export interface WorkflowDraftPayload {
  workflowName: string
  description?: string
  layout?: Record<string, unknown>
  lanes: LaneInput[]
  steps: StepInput[]
  transitions: TransitionInput[]
}

export interface CreateWorkflowPayload extends WorkflowDraftPayload {
  workflowKey: string
}

export interface LaneView extends LaneInput {
  id: string
}

export interface StepView extends StepInput {
  id: string
  allowRequestInformation: boolean
  sortOrder: number
}

export interface TransitionView extends TransitionInput {
  id: string
  sortOrder: number
}

export interface WorkflowGraphResponse {
  workflowDefinitionId: string
  workflowKey: string
  workflowName: string
  description?: string | null
  workflowVersionId: string
  versionNumber: number
  versionStatus: WorkflowVersionStatus
  layout?: Record<string, unknown> | null
  lanes: LaneView[]
  steps: StepView[]
  transitions: TransitionView[]
}

export interface RuntimeGraphResponse {
  workflowInstanceId: string
  instanceStatus: InstanceStatus
  graph: WorkflowGraphResponse
  activeStepKeys: string[]
  waitingForInformationStepKeys: string[]
  completedStepKeys: string[]
  cancelledStepKeys: string[]
  activeTaskIdsByStepKey: Record<string, string[]>
}

export interface WorkflowCreatedResponse {
  workflowDefinitionId: string
  draftVersionId: string
  draftVersionNumber: number
}

export interface WorkflowPublishedResponse {
  workflowDefinitionId: string
  publishedVersionId: string
  publishedVersionNumber: number
  nextDraftVersionId: string
  nextDraftVersionNumber: number
}

export interface ValidationResponse {
  valid: boolean
  errors: string[]
}

export interface WorkflowVersion {
  id: string
  workflowDefinitionId: string
  versionNumber: number
  status: WorkflowVersionStatus
  layoutJson?: string | null
  createdBy: string
  createdAt: string
  publishedBy?: string | null
  publishedAt?: string | null
}

export interface StartWorkflowPayload {
  workflowKey: string
  businessType: string
  businessId: string
  requesterUserId: string
  requesterEmployeeId?: string
  variables: Record<string, unknown>
}

export interface WorkflowStartedResponse {
  workflowInstanceId: string
}

export interface WorkflowInstance {
  id: string
  workflowVersionId: string
  businessType: string
  businessId: string
  requesterUserId: string
  requesterEmployeeId?: string | null
  status: InstanceStatus
  startedBy: string
  startedAt: string
  completedAt?: string | null
}

export interface WorkflowTask {
  id: string
  workflowInstanceId: string
  workflowTokenId: string
  workflowStepId: string
  parentTaskId?: string | null
  taskType: TaskType
  status: TaskStatus
  assigneeUserId?: string | null
  candidateGroupId?: string | null
  informationRoundNumber?: number | null
  outcome?: TaskOutcome | null
  taskPayloadJson?: string | null
  createdAt: string
  completedByUserId?: string | null
  completedAt?: string | null
}

export interface AuditEvent {
  id: number
  workflowInstanceId: string
  workflowTokenId?: string | null
  workflowTaskId?: string | null
  fromStepId?: string | null
  toStepId?: string | null
  eventType: string
  outcome?: string | null
  performedByUserId?: string | null
  performedForGroupId?: string | null
  comments?: string | null
  eventDataJson?: string | null
  createdAt: string
}

export interface InformationTaskCreatedResponse {
  informationTaskId: string
  roundNumber: number
}

export interface ApiErrorBody {
  timestamp?: string
  status?: number
  error?: string
  message?: string
  details?: string[]
  path?: string
}

export type RuntimeStepStatus =
  | 'NOT_STARTED'
  | 'ACTIVE'
  | 'WAITING_FOR_INFORMATION'
  | 'COMPLETED'
  | 'CANCELLED'

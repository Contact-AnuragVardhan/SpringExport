import { useEffect, useState } from 'react'
import { AppShell, type PageKey } from './components/AppShell'
import { useLocalStorage } from './hooks/useLocalStorage'
import { InstanceViewerPage } from './pages/InstanceViewerPage'
import { StartRequestPage } from './pages/StartRequestPage'
import { TasksPage } from './pages/TasksPage'
import { WorkflowDesignerPage } from './pages/WorkflowDesignerPage'

function routeFromHash(): PageKey {
  const route = window.location.hash.replace(/^#\/?/, '') as PageKey
  return ['designer', 'start', 'tasks', 'instance'].includes(route) ? route : 'designer'
}

function App() {
  const [page, setPage] = useState<PageKey>(routeFromHash)
  const [userId, setUserId] = useLocalStorage('workflow.userId', 'EMPUSER1')
  const [instanceId, setInstanceId] = useLocalStorage('workflow.instanceId', '')

  useEffect(() => {
    const listener = () => setPage(routeFromHash())
    window.addEventListener('hashchange', listener)
    return () => window.removeEventListener('hashchange', listener)
  }, [])

  function navigate(nextPage: PageKey) {
    window.location.hash = nextPage
    setPage(nextPage)
  }

  function openInstance(id: string) {
    setInstanceId(id)
    navigate('instance')
  }

  return (
    <AppShell page={page} onPageChange={navigate} userId={userId} onUserIdChange={setUserId}>
      {page === 'designer' && <WorkflowDesignerPage userId={userId} />}
      {page === 'start' && <StartRequestPage userId={userId} onOpenInstance={openInstance} />}
      {page === 'tasks' && <TasksPage userId={userId} onOpenInstance={openInstance} />}
      {page === 'instance' && <InstanceViewerPage initialInstanceId={instanceId} />}
    </AppShell>
  )
}

export default App

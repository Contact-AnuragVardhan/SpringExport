import { useState } from 'react'
import { getErrorMessage } from '../api/http'
import { workflowApi } from '../api/workflowApi'
import { Alert } from '../components/Feedback'

const DEFAULT_VARIABLES = `{
  "ytdTotal": 250,
  "giftValue": 100,
  "providerPoliticalPerson": false
}`

export function StartRequestPage({
  userId,
  onOpenInstance,
}: {
  userId: string
  onOpenInstance: (instanceId: string) => void
}) {
  const [workflowKey, setWorkflowKey] = useState('GIFT_APPROVAL')
  const [businessType, setBusinessType] = useState('GIFT_REQUEST')
  const [businessId, setBusinessId] = useState(`GIFT-${Date.now().toString().slice(-6)}`)
  const [requesterUserId, setRequesterUserId] = useState('EMPUSER1')
  const [requesterEmployeeId, setRequesterEmployeeId] = useState('EMP001')
  const [variablesText, setVariablesText] = useState(DEFAULT_VARIABLES)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<{ tone: 'success' | 'danger' | 'info'; text: string } | null>(null)
  const [createdInstanceId, setCreatedInstanceId] = useState('')

  async function startRequest(event: React.FormEvent) {
    event.preventDefault()
    let variables: Record<string, unknown>
    try {
      variables = variablesText.trim() ? JSON.parse(variablesText) : {}
    } catch {
      setMessage({ tone: 'danger', text: 'Variables must be valid JSON.' })
      return
    }

    setBusy(true)
    setMessage(null)
    try {
      const result = await workflowApi.startWorkflow(
        {
          workflowKey,
          businessType,
          businessId,
          requesterUserId,
          requesterEmployeeId: requesterEmployeeId || undefined,
          variables,
        },
        userId,
      )
      setCreatedInstanceId(result.workflowInstanceId)
      setMessage({ tone: 'success', text: 'The workflow instance was started successfully.' })
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="narrow-page">
      <section className="page-heading">
        <div>
          <span className="eyebrow">Runtime</span>
          <h1>Start a request</h1>
          <p>The backend selects the latest published workflow version. Existing requests remain on their original version.</p>
        </div>
      </section>

      {message && <Alert tone={message.tone}>{message.text}</Alert>}

      <form className="panel form-card" onSubmit={startRequest}>
        <div className="form-section">
          <h2>Workflow</h2>
          <div className="field-grid two-columns">
            <label className="field">
              <span>Workflow key</span>
              <input required value={workflowKey} onChange={(event) => setWorkflowKey(event.target.value)} />
            </label>
            <label className="field">
              <span>Business type</span>
              <input required value={businessType} onChange={(event) => setBusinessType(event.target.value)} />
            </label>
          </div>
          <label className="field">
            <span>Business ID</span>
            <input required value={businessId} onChange={(event) => setBusinessId(event.target.value)} />
          </label>
        </div>

        <div className="form-section">
          <h2>Requester</h2>
          <div className="field-grid two-columns">
            <label className="field">
              <span>Requester user ID</span>
              <input required value={requesterUserId} onChange={(event) => setRequesterUserId(event.target.value)} />
            </label>
            <label className="field">
              <span>Requester employee ID</span>
              <input value={requesterEmployeeId} onChange={(event) => setRequesterEmployeeId(event.target.value)} />
              <small>Used to resolve REQUESTER_SUPERVISOR tasks.</small>
            </label>
          </div>
        </div>

        <div className="form-section">
          <h2>Workflow variables</h2>
          <label className="field">
            <span>JSON object</span>
            <textarea
              className="code-editor"
              rows={12}
              value={variablesText}
              onChange={(event) => setVariablesText(event.target.value)}
              spellCheck={false}
            />
          </label>
        </div>

        <div className="form-actions">
          <button className="button primary" type="submit" disabled={busy}>
            {busy ? 'Starting…' : 'Start workflow'}
          </button>
        </div>
      </form>

      {createdInstanceId && (
        <section className="panel result-card">
          <div>
            <span className="eyebrow">Created instance</span>
            <h2>{createdInstanceId}</h2>
          </div>
          <button className="button accent" type="button" onClick={() => onOpenInstance(createdInstanceId)}>
            Open instance viewer
          </button>
        </section>
      )}
    </div>
  )
}

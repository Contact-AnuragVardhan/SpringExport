import { useMemo, useState } from 'react'
import { getErrorMessage } from '../api/http'
import { workflowApi } from '../api/workflowApi'
import { Alert, EmptyState, LoadingBlock } from '../components/Feedback'
import { WorkflowCanvas } from '../components/WorkflowCanvas'
import type { AuditEvent, RuntimeGraphResponse, RuntimeStepStatus, WorkflowInstance } from '../types/workflow'

function formatEventName(value: string) {
  return value.replaceAll('_', ' ').toLowerCase().replace(/^./, (letter) => letter.toUpperCase())
}

function parseEventData(value?: string | null) {
  if (!value) return null
  try {
    return JSON.stringify(JSON.parse(value), null, 2)
  } catch {
    return value
  }
}

export function InstanceViewerPage({
  initialInstanceId,
}: {
  initialInstanceId: string
}) {
  const [instanceId, setInstanceId] = useState(initialInstanceId)
  const [instance, setInstance] = useState<WorkflowInstance | null>(null)
  const [runtimeGraph, setRuntimeGraph] = useState<RuntimeGraphResponse | null>(null)
  const [audit, setAudit] = useState<AuditEvent[]>([])
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<{ tone: 'danger' | 'info' | 'success'; text: string } | null>(null)
  const [selectedEvent, setSelectedEvent] = useState<AuditEvent | null>(null)

  const runtimeStatuses = useMemo(() => {
    if (!runtimeGraph) return {}
    const result: Record<string, RuntimeStepStatus> = {}
    runtimeGraph.completedStepKeys.forEach((key) => { result[key] = 'COMPLETED' })
    runtimeGraph.cancelledStepKeys.forEach((key) => { result[key] = 'CANCELLED' })
    runtimeGraph.activeStepKeys.forEach((key) => { result[key] = 'ACTIVE' })
    runtimeGraph.waitingForInformationStepKeys.forEach((key) => { result[key] = 'WAITING_FOR_INFORMATION' })
    return result
  }, [runtimeGraph])

  async function loadInstance() {
    if (!instanceId.trim()) {
      setMessage({ tone: 'danger', text: 'Enter a workflow instance ID.' })
      return
    }
    setBusy(true)
    setMessage(null)
    try {
      const [instanceResult, graphResult, auditResult] = await Promise.all([
        workflowApi.getInstance(instanceId.trim()),
        workflowApi.getRuntimeGraph(instanceId.trim()),
        workflowApi.getAudit(instanceId.trim()),
      ])
      setInstance(instanceResult)
      setRuntimeGraph(graphResult)
      setAudit(auditResult)
      setMessage({ tone: 'success', text: 'Workflow instance loaded.' })
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <section className="page-heading compact">
        <div>
          <span className="eyebrow">Monitoring</span>
          <h1>Workflow instance viewer</h1>
          <p>See active branches, completed steps, cancelled work, and the full audit trail.</p>
        </div>
      </section>

      <section className="panel instance-loader">
        <label className="field grow">
          <span>Workflow instance ID</span>
          <input
            value={instanceId}
            onChange={(event) => setInstanceId(event.target.value)}
            placeholder="Paste workflow instance UUID"
            onKeyDown={(event) => {
              if (event.key === 'Enter') void loadInstance()
            }}
          />
        </label>
        <button className="button primary" type="button" disabled={busy} onClick={loadInstance}>Load instance</button>
      </section>

      {message && <Alert tone={message.tone}>{message.text}</Alert>}
      {busy && <LoadingBlock label="Loading instance, graph, and audit history…" />}

      {!busy && !instance && (
        <EmptyState title="No instance loaded" description="Enter an instance ID created from the Start Request page." />
      )}

      {instance && runtimeGraph && (
        <>
          <section className="metrics-grid">
            <article className="metric-card"><span>Status</span><strong className={`status-text status-${instance.status.toLowerCase()}`}>{instance.status}</strong></article>
            <article className="metric-card"><span>Business request</span><strong>{instance.businessType}</strong><small>{instance.businessId}</small></article>
            <article className="metric-card"><span>Requester</span><strong>{instance.requesterUserId}</strong><small>{instance.requesterEmployeeId || 'No employee ID'}</small></article>
            <article className="metric-card"><span>Started</span><strong>{new Date(instance.startedAt).toLocaleDateString()}</strong><small>{new Date(instance.startedAt).toLocaleTimeString()}</small></article>
          </section>

          <section className="runtime-section">
            <div className="section-title-row">
              <div><span className="eyebrow">Live diagram</span><h2>{runtimeGraph.graph.workflowName}</h2></div>
              <span className="status-badge status-published">Version {runtimeGraph.graph.versionNumber}</span>
            </div>
            <WorkflowCanvas
              lanes={runtimeGraph.graph.lanes}
              steps={runtimeGraph.graph.steps}
              transitions={runtimeGraph.graph.transitions}
              runtimeStatuses={runtimeStatuses}
              activeTaskIdsByStepKey={runtimeGraph.activeTaskIdsByStepKey}
            />
          </section>

          <section className="audit-layout">
            <div className="panel audit-list-panel">
              <div className="section-title-row"><h2>Audit history</h2><span>{audit.length} events</span></div>
              <div className="audit-list">
                {audit.map((event) => (
                  <button
                    key={event.id}
                    type="button"
                    className={selectedEvent?.id === event.id ? 'audit-event selected' : 'audit-event'}
                    onClick={() => setSelectedEvent(event)}
                  >
                    <span className="audit-marker" />
                    <span className="audit-content">
                      <strong>{formatEventName(event.eventType)}</strong>
                      <small>{new Date(event.createdAt).toLocaleString()}</small>
                      <span>{event.performedByUserId || 'System'}{event.performedForGroupId ? ` · ${event.performedForGroupId}` : ''}</span>
                      {event.comments && <em>“{event.comments}”</em>}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <aside className="panel audit-details">
              {!selectedEvent ? (
                <EmptyState title="Select an audit event" description="Detailed IDs, outcome, comments, and event data will appear here." />
              ) : (
                <>
                  <span className="eyebrow">Event #{selectedEvent.id}</span>
                  <h2>{formatEventName(selectedEvent.eventType)}</h2>
                  <dl className="detail-list">
                    <div><dt>Created</dt><dd>{new Date(selectedEvent.createdAt).toLocaleString()}</dd></div>
                    <div><dt>Outcome</dt><dd>{selectedEvent.outcome || '—'}</dd></div>
                    <div><dt>Performed by</dt><dd>{selectedEvent.performedByUserId || 'System'}</dd></div>
                    <div><dt>For group</dt><dd>{selectedEvent.performedForGroupId || '—'}</dd></div>
                    <div><dt>Task ID</dt><dd>{selectedEvent.workflowTaskId || '—'}</dd></div>
                    <div><dt>Token ID</dt><dd>{selectedEvent.workflowTokenId || '—'}</dd></div>
                  </dl>
                  {selectedEvent.comments && <Alert tone="info" title="Comments">{selectedEvent.comments}</Alert>}
                  {selectedEvent.eventDataJson && (
                    <label className="field">
                      <span>Event data</span>
                      <pre className="json-viewer">{parseEventData(selectedEvent.eventDataJson)}</pre>
                    </label>
                  )}
                </>
              )}
            </aside>
          </section>
        </>
      )}
    </div>
  )
}

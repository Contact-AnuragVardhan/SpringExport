import { useMemo, useState } from 'react'
import { workflowApi } from '../api/workflowApi'
import { getErrorMessage } from '../api/http'
import { Alert, EmptyState, LoadingBlock } from '../components/Feedback'
import { WorkflowCanvas } from '../components/WorkflowCanvas'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { createGiftWorkflowSample } from '../sampleWorkflow'
import type {
  AssignmentType,
  CreateWorkflowPayload,
  EndStatus,
  LaneInput,
  StepInput,
  StepType,
  TransitionInput,
  TransitionType,
  ValidationResponse,
  WorkflowVersion,
} from '../types/workflow'

const STEP_TYPES: StepType[] = [
  'START',
  'APPROVAL',
  'DECISION',
  'PARALLEL_SPLIT',
  'PARALLEL_JOIN',
  'AUTOMATIC_ACTION',
  'END',
]

const ASSIGNMENT_TYPES: AssignmentType[] = [
  'NONE',
  'REQUESTER',
  'REQUESTER_SUPERVISOR',
  'GROUP',
  'SPECIFIC_USER',
]

const TRANSITION_TYPES: TransitionType[] = ['DEFAULT', 'CONDITIONAL', 'APPROVE', 'REJECT']
const END_STATUSES: EndStatus[] = ['APPROVED', 'REJECTED', 'CANCELLED', 'COMPLETED']

function cleanKey(value: string) {
  return value
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '')
}

function createEmptyWorkflow(): CreateWorkflowPayload {
  return {
    workflowKey: '',
    workflowName: '',
    description: '',
    layout: { direction: 'LEFT_TO_RIGHT' },
    lanes: [],
    steps: [],
    transitions: [],
  }
}

function toDraft(graph: Awaited<ReturnType<typeof workflowApi.getDraft>>): CreateWorkflowPayload {
  return {
    workflowKey: graph.workflowKey,
    workflowName: graph.workflowName,
    description: graph.description ?? '',
    layout: graph.layout ?? { direction: 'LEFT_TO_RIGHT' },
    lanes: graph.lanes.map(({ laneKey, laneName, sortOrder }) => ({ laneKey, laneName, sortOrder })),
    steps: graph.steps.map(({ id: _id, ...step }) => step),
    transitions: graph.transitions.map(({ id: _id, ...transition }) => transition),
  }
}

export function WorkflowDesignerPage({ userId }: { userId: string }) {
  const [definitionId, setDefinitionId] = useLocalStorage('workflow.definitionId', '')
  const [definitionIdInput, setDefinitionIdInput] = useState(definitionId)
  const [workflow, setWorkflow] = useState<CreateWorkflowPayload>(() => createGiftWorkflowSample())
  const [selectedStepKey, setSelectedStepKey] = useState<string | null>(null)
  const [selectedTransitionKey, setSelectedTransitionKey] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<{ tone: 'success' | 'danger' | 'warning' | 'info'; text: string } | null>(null)
  const [validation, setValidation] = useState<ValidationResponse | null>(null)
  const [versions, setVersions] = useState<WorkflowVersion[]>([])

  const selectedStep = useMemo(
    () => workflow.steps.find((step) => step.stepKey === selectedStepKey) ?? null,
    [workflow.steps, selectedStepKey],
  )
  const selectedTransition = useMemo(
    () =>
      workflow.transitions.find((transition) => transition.transitionKey === selectedTransitionKey) ?? null,
    [workflow.transitions, selectedTransitionKey],
  )

  function updateWorkflow(patch: Partial<CreateWorkflowPayload>) {
    setWorkflow((current) => ({ ...current, ...patch }))
    setValidation(null)
  }

  function updateStep(stepKey: string, patch: Partial<StepInput>) {
    updateWorkflow({
      steps: workflow.steps.map((step) => (step.stepKey === stepKey ? { ...step, ...patch } : step)),
    })
  }

  function updateTransition(transitionKey: string, patch: Partial<TransitionInput>) {
    updateWorkflow({
      transitions: workflow.transitions.map((transition) =>
        transition.transitionKey === transitionKey ? { ...transition, ...patch } : transition,
      ),
    })
  }

  function loadSample() {
    setWorkflow(createGiftWorkflowSample())
    setDefinitionId('')
    setDefinitionIdInput('')
    setSelectedStepKey(null)
    setSelectedTransitionKey(null)
    setVersions([])
    setValidation(null)
    setMessage({ tone: 'info', text: 'Loaded the gift approval sample. Create it to persist it.' })
  }

  function newBlank() {
    setWorkflow(createEmptyWorkflow())
    setDefinitionId('')
    setDefinitionIdInput('')
    setSelectedStepKey(null)
    setSelectedTransitionKey(null)
    setVersions([])
    setValidation(null)
  }

  async function loadDraft(id = definitionIdInput) {
    if (!id.trim()) {
      setMessage({ tone: 'warning', text: 'Enter a workflow definition ID.' })
      return
    }
    setBusy(true)
    setMessage(null)
    try {
      const graph = await workflowApi.getDraft(id.trim())
      setWorkflow(toDraft(graph))
      setDefinitionId(graph.workflowDefinitionId)
      setDefinitionIdInput(graph.workflowDefinitionId)
      setSelectedStepKey(null)
      setSelectedTransitionKey(null)
      setMessage({ tone: 'success', text: `Loaded draft version ${graph.versionNumber}.` })
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  async function createWorkflow() {
    setBusy(true)
    setMessage(null)
    try {
      const result = await workflowApi.createWorkflow(workflow, userId)
      setDefinitionId(result.workflowDefinitionId)
      setDefinitionIdInput(result.workflowDefinitionId)
      setMessage({
        tone: 'success',
        text: `Workflow created. Draft version ${result.draftVersionNumber} is ready.`,
      })
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  async function saveDraft() {
    if (!definitionId) {
      await createWorkflow()
      return
    }
    setBusy(true)
    setMessage(null)
    try {
      const { workflowKey: _key, ...payload } = workflow
      const graph = await workflowApi.saveDraft(definitionId, payload, userId)
      setWorkflow(toDraft(graph))
      setMessage({ tone: 'success', text: `Draft version ${graph.versionNumber} saved.` })
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  async function validateDraft() {
    if (!definitionId) {
      setMessage({ tone: 'warning', text: 'Create or load the workflow before validation.' })
      return
    }
    setBusy(true)
    try {
      const result = await workflowApi.validateDraft(definitionId)
      setValidation(result)
      setMessage({
        tone: result.valid ? 'success' : 'danger',
        text: result.valid ? 'The draft is valid and can be published.' : 'The draft has validation errors.',
      })
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  async function publishWorkflow() {
    if (!definitionId) {
      setMessage({ tone: 'warning', text: 'Create or load the workflow before publishing.' })
      return
    }
    setBusy(true)
    setMessage(null)
    try {
      const result = await workflowApi.publishWorkflow(definitionId, userId)
      setMessage({
        tone: 'success',
        text: `Published version ${result.publishedVersionNumber}. Draft version ${result.nextDraftVersionNumber} was created.`,
      })
      await loadDraft(definitionId)
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  async function loadVersions() {
    if (!definitionId) return
    setBusy(true)
    try {
      setVersions(await workflowApi.getVersions(definitionId))
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setBusy(false)
    }
  }

  function addLane() {
    const next = workflow.lanes.length + 1
    const lane: LaneInput = {
      laneKey: `GROUP_${next}`,
      laneName: `Approval Group ${next}`,
      sortOrder: next,
    }
    updateWorkflow({ lanes: [...workflow.lanes, lane] })
  }

  function addStep(stepType: StepType = 'APPROVAL') {
    const number = workflow.steps.length + 1
    const stepKey = `step-${number}`
    const isDiamond = ['DECISION', 'PARALLEL_SPLIT', 'PARALLEL_JOIN'].includes(stepType)
    const step: StepInput = {
      stepKey,
      stepName: stepType.replaceAll('_', ' ').toLowerCase().replace(/^./, (value) => value.toUpperCase()),
      stepType,
      assignmentType: stepType === 'APPROVAL' ? 'GROUP' : 'NONE',
      allowRequestInformation: stepType === 'APPROVAL',
      displayX: 90 + (workflow.steps.length % 5) * 220,
      displayY: 80 + Math.floor(workflow.steps.length / 5) * 150,
      displayWidth: isDiamond ? 94 : 160,
      displayHeight: isDiamond ? 94 : 72,
      sortOrder: number,
    }
    updateWorkflow({ steps: [...workflow.steps, step] })
    setSelectedStepKey(stepKey)
    setSelectedTransitionKey(null)
  }

  function addTransition() {
    if (workflow.steps.length < 2) {
      setMessage({ tone: 'warning', text: 'Add at least two steps before adding a transition.' })
      return
    }
    const number = workflow.transitions.length + 1
    const transition: TransitionInput = {
      transitionKey: `transition-${number}`,
      transitionName: '',
      sourceStepKey: workflow.steps[0].stepKey,
      targetStepKey: workflow.steps[1].stepKey,
      transitionType: 'DEFAULT',
      sortOrder: number,
    }
    updateWorkflow({ transitions: [...workflow.transitions, transition] })
    setSelectedTransitionKey(transition.transitionKey)
    setSelectedStepKey(null)
  }

  function removeSelected() {
    if (selectedStep) {
      updateWorkflow({
        steps: workflow.steps.filter((step) => step.stepKey !== selectedStep.stepKey),
        transitions: workflow.transitions.filter(
          (transition) =>
            transition.sourceStepKey !== selectedStep.stepKey &&
            transition.targetStepKey !== selectedStep.stepKey,
        ),
      })
      setSelectedStepKey(null)
      return
    }
    if (selectedTransition) {
      updateWorkflow({
        transitions: workflow.transitions.filter(
          (transition) => transition.transitionKey !== selectedTransition.transitionKey,
        ),
      })
      setSelectedTransitionKey(null)
    }
  }

  return (
    <div className="designer-page">
      <section className="page-heading compact">
        <div>
          <span className="eyebrow">Configuration</span>
          <h1>Workflow Designer</h1>
          <p>Build sequential and parallel approval flows without a workflow library.</p>
        </div>
        <div className="heading-actions">
          <button className="button secondary" type="button" onClick={newBlank}>New blank</button>
          <button className="button secondary" type="button" onClick={loadSample}>Load sample</button>
          <button className="button primary" type="button" disabled={busy} onClick={saveDraft}>
            {definitionId ? 'Save draft' : 'Create workflow'}
          </button>
        </div>
      </section>

      {message && <Alert tone={message.tone}>{message.text}</Alert>}
      {busy && <LoadingBlock label="Working with the workflow API…" />}

      <section className="definition-loader panel slim-panel">
        <label className="field grow">
          <span>Workflow definition ID</span>
          <input
            value={definitionIdInput}
            onChange={(event) => setDefinitionIdInput(event.target.value)}
            placeholder="Paste an existing UUID to load its draft"
          />
        </label>
        <button className="button secondary" type="button" disabled={busy} onClick={() => loadDraft()}>
          Load draft
        </button>
        <button className="button secondary" type="button" disabled={!definitionId || busy} onClick={validateDraft}>
          Validate
        </button>
        <button className="button accent" type="button" disabled={!definitionId || busy} onClick={publishWorkflow}>
          Publish
        </button>
        <button className="button ghost" type="button" disabled={!definitionId || busy} onClick={loadVersions}>
          Versions
        </button>
      </section>

      {validation && !validation.valid && (
        <Alert tone="danger" title="Validation errors">
          <ul className="compact-list">
            {validation.errors.map((error) => <li key={error}>{error}</li>)}
          </ul>
        </Alert>
      )}

      {versions.length > 0 && (
        <section className="panel version-strip">
          {versions.map((version) => (
            <div className="version-chip" key={version.id}>
              <strong>v{version.versionNumber}</strong>
              <span className={`status-badge status-${version.status.toLowerCase()}`}>{version.status}</span>
              <small>{version.publishedAt ? new Date(version.publishedAt).toLocaleString() : 'Draft'}</small>
            </div>
          ))}
        </section>
      )}

      <div className="designer-layout">
        <aside className="designer-sidebar panel">
          <section>
            <div className="section-title-row">
              <h2>Workflow</h2>
            </div>
            <label className="field">
              <span>Key</span>
              <input
                value={workflow.workflowKey}
                disabled={Boolean(definitionId)}
                onChange={(event) => updateWorkflow({ workflowKey: cleanKey(event.target.value) })}
                placeholder="GIFT_APPROVAL"
              />
            </label>
            <label className="field">
              <span>Name</span>
              <input
                value={workflow.workflowName}
                onChange={(event) => updateWorkflow({ workflowName: event.target.value })}
              />
            </label>
            <label className="field">
              <span>Description</span>
              <textarea
                rows={3}
                value={workflow.description ?? ''}
                onChange={(event) => updateWorkflow({ description: event.target.value })}
              />
            </label>
          </section>

          <section>
            <div className="section-title-row">
              <h2>Lanes / visual groups</h2>
              <button type="button" className="mini-button" onClick={addLane}>+ Lane</button>
            </div>
            <div className="lane-list">
              {workflow.lanes.map((lane, index) => (
                <div className="lane-row" key={`${lane.laneKey}-${index}`}>
                  <input
                    value={lane.laneName}
                    aria-label="Lane name"
                    onChange={(event) => {
                      const lanes = workflow.lanes.map((current, laneIndex) =>
                        laneIndex === index
                          ? {
                              ...current,
                              laneName: event.target.value,
                              laneKey: current.laneKey.startsWith('GROUP_')
                                ? cleanKey(event.target.value) || current.laneKey
                                : current.laneKey,
                            }
                          : current,
                      )
                      updateWorkflow({ lanes })
                    }}
                  />
                  <button
                    type="button"
                    className="icon-button danger"
                    aria-label={`Remove ${lane.laneName}`}
                    onClick={() => updateWorkflow({
                      lanes: workflow.lanes.filter((_, laneIndex) => laneIndex !== index),
                      steps: workflow.steps.map((step) =>
                        step.laneKey === lane.laneKey ? { ...step, laneKey: null } : step,
                      ),
                    })}
                  >×</button>
                </div>
              ))}
              {workflow.lanes.length === 0 && <small>No lanes. Nodes can still be created.</small>}
            </div>
          </section>

          <section>
            <div className="section-title-row"><h2>Add step</h2></div>
            <div className="palette-grid">
              {STEP_TYPES.map((type) => (
                <button key={type} type="button" onClick={() => addStep(type)}>
                  {type.replaceAll('_', ' ')}
                </button>
              ))}
            </div>
            <button className="button secondary full-width" type="button" onClick={addTransition}>
              + Add transition
            </button>
          </section>
        </aside>

        <WorkflowCanvas
          lanes={workflow.lanes}
          steps={workflow.steps}
          transitions={workflow.transitions}
          editable
          selectedStepKey={selectedStepKey}
          selectedTransitionKey={selectedTransitionKey}
          onSelectStep={(key) => {
            setSelectedStepKey(key || null)
            if (key) setSelectedTransitionKey(null)
          }}
          onSelectTransition={(key) => {
            setSelectedTransitionKey(key || null)
            if (key) setSelectedStepKey(null)
          }}
          onMoveStep={(stepKey, x, y) => updateStep(stepKey, { displayX: x, displayY: y })}
        />

        <aside className="inspector panel">
          {!selectedStep && !selectedTransition && (
            <EmptyState
              title="Select an element"
              description="Select a node or transition on the canvas to edit its workflow properties."
            />
          )}

          {selectedStep && (
            <>
              <div className="section-title-row">
                <div>
                  <span className="eyebrow">Step</span>
                  <h2>{selectedStep.stepName}</h2>
                </div>
                <button type="button" className="icon-button danger" onClick={removeSelected}>×</button>
              </div>
              <label className="field">
                <span>Stable key</span>
                <input
                  value={selectedStep.stepKey}
                  onChange={(event) => {
                    const nextKey = event.target.value
                    const previousKey = selectedStep.stepKey
                    setWorkflow((current) => ({
                      ...current,
                      steps: current.steps.map((step) =>
                        step.stepKey === previousKey ? { ...step, stepKey: nextKey } : step,
                      ),
                      transitions: current.transitions.map((transition) => ({
                        ...transition,
                        sourceStepKey: transition.sourceStepKey === previousKey ? nextKey : transition.sourceStepKey,
                        targetStepKey: transition.targetStepKey === previousKey ? nextKey : transition.targetStepKey,
                      })),
                    }))
                    setSelectedStepKey(nextKey)
                  }}
                />
              </label>
              <label className="field">
                <span>Name</span>
                <input value={selectedStep.stepName} onChange={(event) => updateStep(selectedStep.stepKey, { stepName: event.target.value })} />
              </label>
              <label className="field">
                <span>Type</span>
                <select value={selectedStep.stepType} onChange={(event) => updateStep(selectedStep.stepKey, { stepType: event.target.value as StepType })}>
                  {STEP_TYPES.map((type) => <option key={type}>{type}</option>)}
                </select>
              </label>
              <label className="field">
                <span>Lane</span>
                <select value={selectedStep.laneKey ?? ''} onChange={(event) => updateStep(selectedStep.stepKey, { laneKey: event.target.value || null })}>
                  <option value="">No lane</option>
                  {workflow.lanes.map((lane) => <option key={lane.laneKey} value={lane.laneKey}>{lane.laneName}</option>)}
                </select>
              </label>
              <label className="field">
                <span>Assignment</span>
                <select value={selectedStep.assignmentType} onChange={(event) => updateStep(selectedStep.stepKey, { assignmentType: event.target.value as AssignmentType, assignmentGroupId: null, assignmentUserId: null })}>
                  {ASSIGNMENT_TYPES.map((type) => <option key={type}>{type}</option>)}
                </select>
              </label>
              {selectedStep.assignmentType === 'GROUP' && (
                <label className="field">
                  <span>NM_GROUP.GROUP_ID</span>
                  <input value={selectedStep.assignmentGroupId ?? ''} onChange={(event) => updateStep(selectedStep.stepKey, { assignmentGroupId: event.target.value })} placeholder="COMPLIANCE" />
                </label>
              )}
              {selectedStep.assignmentType === 'SPECIFIC_USER' && (
                <label className="field">
                  <span>User ID</span>
                  <input value={selectedStep.assignmentUserId ?? ''} onChange={(event) => updateStep(selectedStep.stepKey, { assignmentUserId: event.target.value })} />
                </label>
              )}
              {selectedStep.stepType === 'APPROVAL' && (
                <label className="check-field">
                  <input type="checkbox" checked={Boolean(selectedStep.allowRequestInformation)} onChange={(event) => updateStep(selectedStep.stepKey, { allowRequestInformation: event.target.checked })} />
                  <span>Allow request more information</span>
                </label>
              )}
              {selectedStep.stepType === 'PARALLEL_SPLIT' && (
                <label className="field">
                  <span>Matching join step</span>
                  <select value={selectedStep.parallelJoinStepKey ?? ''} onChange={(event) => updateStep(selectedStep.stepKey, { parallelJoinStepKey: event.target.value || null })}>
                    <option value="">Select join</option>
                    {workflow.steps.filter((step) => step.stepType === 'PARALLEL_JOIN').map((step) => <option key={step.stepKey} value={step.stepKey}>{step.stepName}</option>)}
                  </select>
                </label>
              )}
              {selectedStep.stepType === 'END' && (
                <label className="field">
                  <span>End status</span>
                  <select value={selectedStep.endStatus ?? 'COMPLETED'} onChange={(event) => updateStep(selectedStep.stepKey, { endStatus: event.target.value as EndStatus })}>
                    {END_STATUSES.map((status) => <option key={status}>{status}</option>)}
                  </select>
                </label>
              )}
              <div className="field-grid two-columns">
                <label className="field"><span>X</span><input type="number" value={selectedStep.displayX ?? 0} onChange={(event) => updateStep(selectedStep.stepKey, { displayX: Number(event.target.value) })} /></label>
                <label className="field"><span>Y</span><input type="number" value={selectedStep.displayY ?? 0} onChange={(event) => updateStep(selectedStep.stepKey, { displayY: Number(event.target.value) })} /></label>
              </div>
              <label className="field">
                <span>Configuration JSON</span>
                <textarea
                  rows={5}
                  value={selectedStep.configuration ? JSON.stringify(selectedStep.configuration, null, 2) : ''}
                  onChange={(event) => {
                    try {
                      updateStep(selectedStep.stepKey, { configuration: event.target.value.trim() ? JSON.parse(event.target.value) : null })
                    } catch {
                      // Keep the last valid JSON while the user is typing.
                    }
                  }}
                  placeholder='{"action":"SEND_EMAIL"}'
                />
              </label>
            </>
          )}

          {selectedTransition && (
            <>
              <div className="section-title-row">
                <div><span className="eyebrow">Transition</span><h2>{selectedTransition.transitionKey}</h2></div>
                <button type="button" className="icon-button danger" onClick={removeSelected}>×</button>
              </div>
              <label className="field"><span>Key</span><input value={selectedTransition.transitionKey} onChange={(event) => {
                const previousKey = selectedTransition.transitionKey
                const nextKey = event.target.value
                setWorkflow((current) => ({ ...current, transitions: current.transitions.map((transition) => transition.transitionKey === previousKey ? { ...transition, transitionKey: nextKey } : transition) }))
                setSelectedTransitionKey(nextKey)
              }} /></label>
              <label className="field"><span>Label</span><input value={selectedTransition.transitionName ?? ''} onChange={(event) => updateTransition(selectedTransition.transitionKey, { transitionName: event.target.value })} /></label>
              <label className="field"><span>Source</span><select value={selectedTransition.sourceStepKey} onChange={(event) => updateTransition(selectedTransition.transitionKey, { sourceStepKey: event.target.value })}>{workflow.steps.map((step) => <option key={step.stepKey} value={step.stepKey}>{step.stepName}</option>)}</select></label>
              <label className="field"><span>Target</span><select value={selectedTransition.targetStepKey} onChange={(event) => updateTransition(selectedTransition.transitionKey, { targetStepKey: event.target.value })}>{workflow.steps.map((step) => <option key={step.stepKey} value={step.stepKey}>{step.stepName}</option>)}</select></label>
              <label className="field"><span>Type</span><select value={selectedTransition.transitionType} onChange={(event) => updateTransition(selectedTransition.transitionKey, { transitionType: event.target.value as TransitionType })}>{TRANSITION_TYPES.map((type) => <option key={type}>{type}</option>)}</select></label>
              <label className="field"><span>Parallel branch key</span><input value={selectedTransition.branchKey ?? ''} onChange={(event) => updateTransition(selectedTransition.transitionKey, { branchKey: event.target.value || null })} placeholder="COMPLIANCE" /></label>
              <label className="field">
                <span>Condition JSON</span>
                <textarea
                  rows={7}
                  defaultValue={selectedTransition.condition ? JSON.stringify(selectedTransition.condition, null, 2) : ''}
                  key={selectedTransition.transitionKey}
                  onBlur={(event) => {
                    try {
                      updateTransition(selectedTransition.transitionKey, { condition: event.target.value.trim() ? JSON.parse(event.target.value) : null })
                    } catch {
                      setMessage({ tone: 'danger', text: 'Condition JSON is invalid.' })
                    }
                  }}
                  placeholder={'{"field":"ytdTotal","operator":"GT","value":300}'}
                />
              </label>
            </>
          )}
        </aside>
      </div>
    </div>
  )
}

import { useEffect, useMemo, useState } from 'react'
import { getErrorMessage } from '../api/http'
import { workflowApi } from '../api/workflowApi'
import { Alert, EmptyState, LoadingBlock } from '../components/Feedback'
import { Modal } from '../components/Modal'
import type { WorkflowTask } from '../types/workflow'

type TaskAction = 'approve' | 'reject' | 'request-information' | 'submit-information'

function actionTitle(action: TaskAction) {
  switch (action) {
    case 'approve': return 'Approve task'
    case 'reject': return 'Reject task'
    case 'request-information': return 'Request more information'
    case 'submit-information': return 'Submit requested information'
  }
}

export function TasksPage({ userId, onOpenInstance }: { userId: string; onOpenInstance: (id: string) => void }) {
  const [tasks, setTasks] = useState<WorkflowTask[]>([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<{ tone: 'success' | 'danger' | 'info'; text: string } | null>(null)
  const [selectedTask, setSelectedTask] = useState<WorkflowTask | null>(null)
  const [action, setAction] = useState<TaskAction | null>(null)
  const [comments, setComments] = useState('')
  const [updatedValues, setUpdatedValues] = useState('{}')
  const [submitting, setSubmitting] = useState(false)

  const approvalTasks = useMemo(() => tasks.filter((task) => task.taskType === 'APPROVAL'), [tasks])
  const informationTasks = useMemo(
    () => tasks.filter((task) => task.taskType === 'EMPLOYEE_INFORMATION'),
    [tasks],
  )

  async function loadTasks() {
    if (!userId.trim()) return
    setLoading(true)
    setMessage(null)
    try {
      setTasks(await workflowApi.getMyTasks(userId))
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void loadTasks()
    // Intentional: refresh when the acting user changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId])

  function openAction(task: WorkflowTask, nextAction: TaskAction) {
    setSelectedTask(task)
    setAction(nextAction)
    setComments('')
    setUpdatedValues('{}')
  }

  function closeAction() {
    if (submitting) return
    setSelectedTask(null)
    setAction(null)
  }

  async function performAction() {
    if (!selectedTask || !action) return
    if ((action === 'reject' || action === 'request-information' || action === 'submit-information') && !comments.trim()) {
      setMessage({ tone: 'danger', text: 'Comments are required for this action.' })
      return
    }

    let parsedValues: Record<string, unknown> = {}
    if (action === 'submit-information') {
      try {
        parsedValues = updatedValues.trim() ? JSON.parse(updatedValues) : {}
      } catch {
        setMessage({ tone: 'danger', text: 'Updated request values must be valid JSON.' })
        return
      }
    }

    setSubmitting(true)
    setMessage(null)
    try {
      if (action === 'approve') {
        await workflowApi.approveTask(selectedTask.id, userId, comments)
      } else if (action === 'reject') {
        await workflowApi.rejectTask(selectedTask.id, userId, comments)
      } else if (action === 'request-information') {
        const result = await workflowApi.requestInformation(selectedTask.id, userId, comments)
        setMessage({ tone: 'success', text: `Information task created for round ${result.roundNumber}.` })
      } else {
        await workflowApi.submitInformation(selectedTask.id, userId, comments, parsedValues)
      }

      if (action !== 'request-information') {
        setMessage({ tone: 'success', text: `${actionTitle(action)} completed.` })
      }
      closeAction()
      await loadTasks()
    } catch (error) {
      setMessage({ tone: 'danger', text: getErrorMessage(error) })
    } finally {
      setSubmitting(false)
    }
  }

  function TaskCard({ task }: { task: WorkflowTask }) {
    const isInformation = task.taskType === 'EMPLOYEE_INFORMATION'
    return (
      <article className="task-card">
        <header>
          <div>
            <span className={`task-type task-type-${task.taskType.toLowerCase().replaceAll('_', '-')}`}>
              {task.taskType.replaceAll('_', ' ')}
            </span>
            <h3>{isInformation ? `Information round ${task.informationRoundNumber ?? ''}` : 'Approval task'}</h3>
          </div>
          <span className="status-badge status-open">{task.status}</span>
        </header>
        <dl className="task-details">
          <div><dt>Instance</dt><dd>{task.workflowInstanceId}</dd></div>
          <div><dt>Assigned to</dt><dd>{task.assigneeUserId || `Group: ${task.candidateGroupId}`}</dd></div>
          <div><dt>Created</dt><dd>{new Date(task.createdAt).toLocaleString()}</dd></div>
        </dl>
        <div className="task-actions">
          <button className="button ghost" type="button" onClick={() => onOpenInstance(task.workflowInstanceId)}>View request</button>
          {isInformation ? (
            <button className="button primary" type="button" onClick={() => openAction(task, 'submit-information')}>Submit information</button>
          ) : (
            <>
              <button className="button secondary" type="button" onClick={() => openAction(task, 'request-information')}>Request info</button>
              <button className="button danger" type="button" onClick={() => openAction(task, 'reject')}>Reject</button>
              <button className="button primary" type="button" onClick={() => openAction(task, 'approve')}>Approve</button>
            </>
          )}
        </div>
      </article>
    )
  }

  return (
    <div>
      <section className="page-heading compact">
        <div>
          <span className="eyebrow">Inbox</span>
          <h1>My workflow tasks</h1>
          <p>Direct assignments and group tasks available to <strong>{userId || 'the acting user'}</strong>.</p>
        </div>
        <button className="button secondary" type="button" disabled={loading} onClick={loadTasks}>Refresh</button>
      </section>

      {message && <Alert tone={message.tone}>{message.text}</Alert>}
      {loading && <LoadingBlock label="Loading available tasks…" />}

      {!loading && tasks.length === 0 && (
        <EmptyState title="No open tasks" description="There are no direct or active-group tasks for the selected user." />
      )}

      {approvalTasks.length > 0 && (
        <section className="task-section">
          <div className="section-title-row"><h2>Approvals</h2><span>{approvalTasks.length}</span></div>
          <div className="task-grid">{approvalTasks.map((task) => <TaskCard key={task.id} task={task} />)}</div>
        </section>
      )}

      {informationTasks.length > 0 && (
        <section className="task-section">
          <div className="section-title-row"><h2>Information requested</h2><span>{informationTasks.length}</span></div>
          <div className="task-grid">{informationTasks.map((task) => <TaskCard key={task.id} task={task} />)}</div>
        </section>
      )}

      <Modal
        open={Boolean(selectedTask && action)}
        title={action ? actionTitle(action) : 'Task action'}
        onClose={closeAction}
        footer={
          <>
            <button className="button secondary" type="button" onClick={closeAction} disabled={submitting}>Cancel</button>
            <button className={action === 'reject' ? 'button danger' : 'button primary'} type="button" onClick={performAction} disabled={submitting}>
              {submitting ? 'Submitting…' : 'Confirm'}
            </button>
          </>
        }
      >
        <label className="field">
          <span>Comments {action === 'approve' ? '(optional)' : '(required)'}</span>
          <textarea rows={5} value={comments} onChange={(event) => setComments(event.target.value)} autoFocus />
        </label>
        {action === 'submit-information' && (
          <label className="field">
            <span>Updated request values (JSON)</span>
            <textarea className="code-editor" rows={8} value={updatedValues} onChange={(event) => setUpdatedValues(event.target.value)} spellCheck={false} />
          </label>
        )}
      </Modal>
    </div>
  )
}

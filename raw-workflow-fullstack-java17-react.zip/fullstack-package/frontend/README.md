# Raw Workflow Engine UI

React + TypeScript administration UI for the Java 17 Spring Boot raw workflow engine.

The project uses React and Vite, but no workflow, diagram, routing, state-management, or UI-component library. The workflow diagram is rendered and edited with native SVG and React.

## Included screens

- **Workflow Designer**
  - Create a workflow or load an existing draft
  - Add/remove visual lanes
  - Add sequential, decision, approval, parallel split, parallel join, automatic, and end steps
  - Drag steps on the SVG canvas
  - Add/edit/remove transitions
  - Configure `REQUESTER_SUPERVISOR`, `GROUP`, and specific-user assignments
  - Configure `NM_GROUP.GROUP_ID` for group tasks
  - Configure request-more-information, conditions, and parallel split/join relationships
  - Save, validate, publish, and view workflow versions
- **Start Request**
  - Start the latest published workflow by workflow key
  - Supply requester identity and JSON variables
- **My Tasks**
  - View direct and active-group tasks for `X-User-Id`
  - Approve, reject, request information, and submit information
  - Send comments and updated request values
- **Instance Viewer**
  - Show the live runtime graph
  - Highlight active, waiting, completed, and cancelled steps
  - Display task counts by step
  - Display every audit event and comment

## Requirements

- Node.js 20.19+ or 22.12+
- npm
- The Spring Boot API running on port 8080 by default

## Run locally

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

The Vite development server proxies `/api` to `http://localhost:8080`, so the Spring Boot project does not need a development-only CORS configuration.

To use another backend URL, create `.env.local`:

```text
VITE_DEV_BACKEND_URL=http://localhost:9090
```

## Production build

```bash
npm run build
```

The deployable static files are created in `dist/`.

When the UI and API are served from the same domain, leave `VITE_API_BASE_URL` unset. When the API is on another origin, build with:

```text
VITE_API_BASE_URL=https://workflow-api.example.com
```

The Spring Boot API must then allow that UI origin through its production CORS/security configuration.

## Temporary identity handling

The current Spring Boot starter expects an `X-User-Id` header. The UI exposes an **Acting user** field in the header and sends its value on all user-specific requests.

Replace this later with the JWT/session identity used by your application. The main integration point is:

```text
src/api/http.ts
```

## API mapping

The UI calls the API paths included in the Spring Boot starter:

```text
POST /api/workflows
GET  /api/workflows/{workflowDefinitionId}/draft
PUT  /api/workflows/{workflowDefinitionId}/draft
POST /api/workflows/{workflowDefinitionId}/validate
POST /api/workflows/{workflowDefinitionId}/publish
GET  /api/workflows/{workflowDefinitionId}/versions

POST /api/workflow-instances
GET  /api/workflow-instances/{instanceId}
GET  /api/workflow-instances/{instanceId}/graph
GET  /api/workflow-instances/{instanceId}/audit

GET  /api/workflow-tasks/my
POST /api/workflow-tasks/{taskId}/approve
POST /api/workflow-tasks/{taskId}/reject
POST /api/workflow-tasks/{taskId}/request-information
POST /api/workflow-tasks/{taskId}/submit-information
```

## Suggested first run

1. Run the SQL scripts and Spring Boot backend.
2. Open **Workflow Designer**.
3. Keep the preloaded Gift Approval sample and click **Create workflow**.
4. Click **Validate**, then **Publish**.
5. Open **Start Request** and start a request.
6. Switch the acting user to the demo supervisor or group member configured by the backend SQL scripts.
7. Open **My Tasks** and act on the task.
8. Open **Instance Viewer** to inspect the diagram and audit history.
